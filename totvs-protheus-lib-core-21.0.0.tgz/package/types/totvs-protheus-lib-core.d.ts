import * as i0 from '@angular/core';
import { Injector, EventEmitter, OnInit, OnDestroy, AfterViewInit, ElementRef } from '@angular/core';
import * as i4 from '@po-ui/ng-components';
import { PoLookupFilter, PoLookupFilteredItemsParams, PoLookupColumn, PoLookupComponent, PoLanguage, PoNotificationService, PoI18nService, PoTheme, PoThemeService, PoThemeTypeEnum, PoLanguageService, PoSelectOption } from '@po-ui/ng-components';
import { Observable, Subscription } from 'rxjs';
import { HttpClient, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpParams } from '@angular/common/http';
import * as i1 from '@angular/common';
import * as i3 from '@angular/forms';
import { UntypedFormGroup, UntypedFormBuilder, UntypedFormControl, ValidationErrors } from '@angular/forms';
import * as i4$1 from '@angular/router';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, Route, ActivatedRoute, Data } from '@angular/router';
import * as i3$1 from '@po-ui/ng-templates';
import { PoPageLoginLiterals, PoPageLogin } from '@po-ui/ng-templates';

/**
 * @description
 *
 * Interface que representa as informações da filial
 * no Protheus TFace
 */
interface ProBranch {
    BillingState?: string;
    BillingAddress?: string;
    Street?: string;
    ZipCode?: string;
    CompanyCode?: string;
    Phone?: string;
    BillingCity?: string;
    CityCode?: string;
    BillingZipCode?: string;
    EnterpriseGroup?: string;
    Cgc?: string;
    Complement?: string;
    NatureCode?: string;
    SubscriptionType?: string;
    StateRegistration?: string;
    Suframa?: string;
    BillingComplement?: string;
    NIRE?: string;
    DTRE?: string;
    ParentCode?: string;
    Code?: string;
    Title?: string;
    UnitOfBusiness?: string;
    State?: string;
    Neighborhood?: string;
    BillingNeighborhood?: string;
    City?: string;
    CNAECode?: string;
    Description?: string;
    CommercialName?: string;
}
interface ProBranchList {
    items?: Array<ProBranch>;
    hasNext?: boolean;
}

/**
 * @description
 *
 * Interface que representa o objeto de configuração de um observable
 * de um envio de mensagem via jsToAdvpl
 */
interface ProJsToAdvpl {
    sendInfo?: SendInfo;
    receiveId?: string;
    autoDestruct: boolean;
}
interface SendInfo {
    type: string;
    content?: string;
}

declare class ProJsToAdvplService {
    constructor();
    hasDialog(): boolean;
    hasWebChannel(): boolean;
    getWebChannel(): any;
    jsToAdvpl(type: string, content: string): boolean;
    /**
     * @description Método responsável por fechar app na camada advpl
     *
     * @param {string} value Valor que será enviado a camada advpl, sendo vazia ou force
     */
    AdvplCloseApp(value?: string): void;
    buildListener(id: string, callBack: any): void;
    buildObservable<T>(callBack: any, options: ProJsToAdvpl): Observable<T>;
    /**
     * @description Remove e apaga o evento
     * @param id ID do evento
     * @param callBack callback do evento
     * @returns
     */
    private buildAutoDestruct;
    protheusConnected(): boolean;
    connectedJsToAdvpl(type: string, value: string, retryCounter?: number, timeout?: number): void;
    generateEventId(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProJsToAdvplService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProJsToAdvplService>;
}

declare class ProJsToAdvplModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProJsToAdvplModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProJsToAdvplModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProJsToAdvplModule>;
}

/**
 * @description
 *
 * Interface que representa as informações do grupo de empresa
 * no Protheus TFace
 */
interface ProCompany {
    Code?: string;
    InternalId?: string;
    CorporateName?: string;
    Layout?: string;
    CompanyLength?: string;
    FirstBranchCode?: string;
    FirstBranchDescription?: string;
}
interface ProCompanyList {
    hasNext: boolean;
    items: Array<ProCompany>;
}

declare class ProTenantModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProTenantModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProTenantModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProTenantModule>;
}

/**
 * @description
 *
 * Interface que representa as informações do modulos do sistema
 * no Protheus TFace
 */
interface ProSystemModules {
    id?: string;
    name?: string;
    description?: string;
}
interface ProSystemModulesList {
    hasNext: boolean;
    items: Array<ProSystemModules>;
}

declare class ProSystemModuleService {
    private http;
    private advplService;
    private sessionInfoService;
    private url;
    private useHTTP;
    EVENT_SET_LIST: string;
    EVENT_GET_LIST: string;
    EVENT_SET_ONE: string;
    EVENT_GET_ONE: string;
    constructor(http: HttpClient, advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService);
    getListOfSystemModules(description?: string, page?: number, _pageSize?: number): Observable<ProSystemModulesList>;
    private getListOfSystemModulesFromApi;
    private getListOfSystemModulesFromAdvpl;
    getSystemModule(systemModuleId: string): Observable<ProSystemModules>;
    private getSystemModuleFromAPI;
    private getSystemModuleFromAdvpl;
    /**
     * @description Retorna as informações do módulo logado.
     * @returns ProSystemModules
     */
    get systemModule(): ProSystemModules;
    set systemModule(systemModule: ProSystemModules);
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemModuleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSystemModuleService>;
}

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o módulo.
 */
declare class ProSystemModulesInteceptor implements HttpInterceptor {
    private injector;
    private sessionInfoService;
    constructor(injector: Injector, sessionInfoService: ProSessionInfoService);
    /**
     * @description Intercept http para tratamento do módulo do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do módulo caso o ERP seja Protheus
     */
    intercept(original_request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private appendModuleToRequest;
    /**
     * @description Retorno o módulo logado
     * @returns string
     */
    private getModule;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemModulesInteceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSystemModulesInteceptor>;
}

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o database.
 */
declare class ProSystemDatabaseInterceptor implements HttpInterceptor {
    private injector;
    private sessionInfoService;
    constructor(injector: Injector, sessionInfoService: ProSessionInfoService);
    /**
     * @description Intercept http para tratamento do database do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do database caso o ERP seja Protheus
     */
    intercept(original_request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    /**
     * @description Adiciona o header da database na requisição caso exista
     * @param request Objeto HttpRequest da requisição
     * @returns HttpRequest da requisição com a database ou apenas um cópia
     */
    private appendDataBaseToRequest;
    /**
     * @description Verifica o valor da database no SessionStorage
     * @returns Retorna o valor da database no SessionStorage, podendo não ter valor algum
     */
    private getDatabase;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemDatabaseInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSystemDatabaseInterceptor>;
}

declare class ProSystemInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProSystemInfoModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProSystemInfoModule>;
}

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere o endereço e o header que define o erro padrão do Protheus.
 */
declare class ProAppConfigInteceptor implements HttpInterceptor {
    private injector;
    private sessionInfoService;
    constructor(injector: Injector, sessionInfoService: ProSessionInfoService);
    intercept(original_request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    /**
     * @description Altera a URL da requisição para acesso aos assets do app
     * @param request Requisição HTTP original
     * @returns Requisição HTTP com a alteração do path, somente para assets
     */
    private appendPathNameToUrl;
    /**
     * @description Inclui o nome do ambiente na URL da requisição que acessa os assets do app
     * @param location Localização atual do app
     * @param appName Nome do app atual
     * @param newUrl URL base montada
     * @param requestUrl URL da requisição original (caminho do /assets)
     * @returns URL alterada com o nome do ambiente
    */
    private appendEnvironmentToUrl;
    /**
     * @description Altera da URL da requisição conforme regras
     * @param request Requisição HTTP Original
     * @returns Requisição HTTP, podendo ter sua URL alterada
     */
    private appendDomainToUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAppConfigInteceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAppConfigInteceptor>;
}

/**
 * @description
 *
 * Interface que representa as informações do usuário utilizado
 * no Protheus TFace
 */
interface ProAppConfig {
    name?: string;
    version?: string;
    serverBackend?: string;
    restEntryPoint?: string;
    versionAPI?: string;
    productLine?: string;
    api_baseUrl?: string;
}

declare class ProAuthorizationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAuthorizationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProAuthorizationModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProAuthorizationModule>;
}

/**
 * @description
 *
 * Interface que representa o token de identificação
 */
interface ProAuthToken {
    access_token?: string;
    refresh_token?: string;
    scope?: string;
    token_type?: string;
    expires_in?: number;
    hasMFA?: boolean;
}
interface ProAccessToken {
    iss: string;
    sub: string;
    iat: number;
    userid: string;
    exp: number;
    restrictedto: Array<string>;
}

/**
 * @description
 *
 * Interface que representa as informações do usuário e senha
 */
interface ProUser {
    readonly username: string;
    readonly username_when?: boolean;
    readonly password: string;
    readonly remember_user?: boolean;
    readonly show_remember_user?: boolean;
    readonly singleSignOnRequired?: boolean;
}

/**
 * @description
 *
 * Interface que representa as informações do usuário
 * no Protheus TFace
 */
interface ProUserInfo {
    id?: string;
    name?: Name;
    complete_name?: string;
    userName?: string;
    displayName?: string;
    meta?: Meta;
    externalId?: string;
    phoneNumbers?: Array<any>;
    emails?: Array<Email>;
    active?: boolean;
    groups?: Array<any>;
    roles?: Array<any>;
    title?: string;
    department?: string;
}
interface Name {
    formatted: string;
    givenName: string;
    familyName: string;
}
interface Meta {
    resourceType: string;
    created: string;
    lastModified: string;
}
interface Email {
    value: string;
    type: string;
    primary: boolean;
}
interface ProUserList {
    hasNext: boolean;
    schemas: Array<string>;
    items: Array<ProUserInfo>;
}

/**
 * @description
 * Interface base para o retorno da API /api/framework/v1/basicProtheusServices/pswret
 */
interface ProUserPswretInterface {
    user_id: string;
    user_name: string;
    user_full_name: string;
    expiration_date: string;
    number_of_days_to_expire: number;
    authorization_to_change_the_password: boolean;
    change_password_at_next_logon: boolean;
    groups_array: string[];
    superiors: string;
    department: string;
    position: string;
    email: string;
    number_of_simultaneous_accesses: number;
    date_of_last_change: string;
    user_blocked: boolean;
    number_of_digits_for_the_year: number;
    listener_for_calls: boolean;
    extension: string;
    operation_log: string;
    company_branch_and_registration: string;
    allow_changing_system_database: boolean;
    days_to_go_back: number;
    days_to_go_forward: number;
    date_of_inclusion_in_the_system: string;
    global_field_level: number;
    access_times: string[];
    path_for_disk_printing: string;
    driver_for_direct_port_printing: string;
    accesses: string;
    companies_array: string[];
    pe_useracs: string;
    print_type: number;
    page_format: number;
    environment_type: number;
    prioritize_group_configuration: boolean;
    print_option: string;
    access_other_print_directories: boolean;
    modules_array: string[];
}

/**
 * Essa classe corresponde ao serviço de busca de informações do usuário
 */
declare class ProUserInfoService {
    private http;
    private advplService;
    private useHTTP;
    readonly EVENT_GET_ID = "getUserInfo";
    readonly EVENT_SET_ID = "setUserInfo";
    private readonly URL_PSWRET;
    constructor(http: HttpClient, advplService: ProJsToAdvplService);
    /**
     * @description Retorna informações do usuário
     * @param userId string, id do usuário
     * @param isUseHttp boolean, indica se utiliza requisição http
     * @returns Observable de ProUserInfo, dados do usuário
     */
    get(userId: string, isUseHttp?: boolean): Observable<ProUserInfo>;
    private getFromApi;
    private getFromAdvpl;
    removeFromStorage(): void;
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    /**
     * efetua um get na api referente a função PswRet do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @returns Observable com o retorno da api
     */
    pswRet(): Observable<ProUserPswretInterface>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProUserInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProUserInfoService>;
}

/**
 * @description
 * Interface base para o retorno da API /api/framework/mfa/hasSecret
 */
interface ProMfaHasSecretInterface {
    hasSecret: boolean;
}
/**
 * @description
 * Interface base para o retorno da API /api/framework/mfa/TOTPURI
 */
interface ProMfaQrCodeInterface {
    cQrCode: string;
}
/**
 * @description
 * Interface base para o retorno da API /api/framework/mfa/tok
 */
interface ProMfaValidCodeInterface {
    tok: number;
}

declare class ProMfaService {
    private http;
    private advplService;
    private isHTTP;
    private hasMFA;
    private isValidToken;
    private isSigaCfg;
    constructor(http: HttpClient, advplService: ProJsToAdvplService);
    /**
     * @description Atribui valor para hasMFA.
     * @param hasMFA boolean, indica se o usuário possui MFA habilitado.
     */
    setHasMFA(hasMFA: boolean): void;
    /**
     * @description Retorna o atributo hasMFA.
     * @returns boolean, indica se o usuário possui MFA habilitado.
     */
    getHasMFA(): boolean;
    /**
     * @description Atribui valor para isValidToken.
     * @param isValid boolean, indica se o token MFA é válido.
     */
    setIsValidToken(isValid: boolean): void;
    /**
     * @description Retorna o atributo isValidToken.
     * @returns boolean, indica se o token MFA é válido.
     */
    getIsValidToken(): boolean;
    /**
     * @description Atribui valor para isSigaCfg.
     * @param isCfg boolean, indica se o login está sendo feito no módulo SIGACFG.
     */
    setIsSigaCfg(isCfg: boolean): void;
    /**
     * @description Retorna o atributo isSigaCfg.
     * @returns boolean, indica se o login está sendo feito no módulo SIGACFG.
     */
    getIsSigaCfg(): boolean;
    /**
     * @description
     * Serviço que verifica se o usuário já possui MFA registrado.
     * @return Json da interface ProMfaHasSecretInterface
     */
    userHasMfaSecurity(): Observable<ProMfaHasSecretInterface>;
    /**
     * @description
     * Serviço que retorna os dados para geração do Qr Code
     * @return Json da interface ProMfaQrCodeInterface
     */
    getMfaQrCode(): Observable<ProMfaQrCodeInterface>;
    /**
     * @description
     * Serviço que valida o token informado.
     * @param tokenMfa, token informado pelo usuário
     * @return Json da interface ProMfaValidCodeInterface
     */
    getMfaValid(tokenMfa: string): Observable<ProMfaValidCodeInterface>;
    /**
     * @description Valida se está no módulo SIGACFG.
     * @return Observable boolean
     */
    isSIGACFG(): Observable<boolean>;
    /**
     * @description Metodo apenas para apoio nos testes automatizados
     * @return Informa se se o Http esta ativo
     */
    isChannelHTTP(): boolean;
    /**
     * @description Muda o parametro de environment para Http
     * @param value, indica o valor a ser atribuido
     */
    setChannelAsHTTP(value: boolean): void;
    /**
     * @description Validação do response e disparo do evento de erro
     * @param protheusResponse, Response do JsToAdvpl
     * @param subscriber, Subscriber do JsToAdvpl
     * @return Indica se a resposta foi validada
     */
    private validResponse;
    /**
     * @description Retorna o objeto sender
     * @param type, Tipo do Sender
     * @param content, Conteudo a ser enviado
     * @param receiveId, Id do evento
     * @param autoDestruct, Indica se realiza a eliminação automatica do objeto
     * @return Objeto Sender
     */
    private getJsToAdvplSend;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProMfaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProMfaService>;
}

declare class ProAuthService {
    private http;
    private proUserInfoService;
    private advplService;
    private sessionInfoService;
    private proMfaService;
    redirectUrl: string;
    private _token;
    private _ProUserInfo;
    constructor(http: HttpClient, proUserInfoService: ProUserInfoService, advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService, proMfaService: ProMfaService);
    requestLoginDefaults(): Observable<ProUser>;
    requestToken(user: ProUser): Observable<ProAuthToken>;
    refreshToken(refresh_token: string): Observable<ProAuthToken>;
    login(user: ProUser): Observable<ProAuthToken>;
    passwordRecovery(user: string): void;
    saveToken(token: ProAuthToken): void;
    saveUserInfo(userId: string): void;
    isTokenValid(now?: number): boolean;
    updateToken(): Promise<void>;
    get userInfo(): ProUserInfo;
    /**
     * @description Retorna o token de autenticação gerado.
     */
    get token(): ProAuthToken;
    get isUserAuthenticate(): boolean;
    /**
     * @description Realiza a limpeza do token ao realizar o logout.
     */
    logout(): void;
    getTokenPayload(token?: string): ProAccessToken;
    get userId(): string;
    /**
     * @description
     * Exibir a mensagem de confirmação de Autenticação.
     */
    showLoginMessage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAuthService>;
}

type canActivateReturn = Observable<boolean> | Promise<boolean> | boolean;
declare class ProAuthGuard {
    private proAuthService;
    private router;
    constructor(proAuthService: ProAuthService, router: Router);
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): canActivateReturn;
    checkLogin(url: string): canActivateReturn;
    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): canActivateReturn;
    canLoad(route: Route): canActivateReturn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAuthGuard>;
}

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o token.
 */
declare class ProAuthInteceptor implements HttpInterceptor {
    private injector;
    private advplService;
    constructor(injector: Injector, advplService: ProJsToAdvplService);
    intercept(original_request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private isAuthError;
    doIHaveAToken(): boolean;
    callTokenFromADVPL(request: HttpRequest<any>): HttpRequest<any>;
    appendTokenToRequest(request: HttpRequest<any>): HttpRequest<any>;
    appendTokenOnError(request: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>>;
    private cloneAuthRequest;
    isUrlNeedsProAuth(url: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAuthInteceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAuthInteceptor>;
}

/**
 * @description
 * Interface base para o retorno da API /api/framework/v1/basicProtheusServices/pswret
 */
interface ProUserAccessInterface {
    access: boolean;
    message: string;
}

declare class ProUserAccessService {
    private http;
    private readonly URL_ALIAS;
    private readonly URL_FUNCTION;
    constructor(http: HttpClient);
    /**
     * efetua um get na api referente a função MpUserHasAccess do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @param cRotina Nome da rotina a ser pesquisada
     * @param nOpc parametro opcional, numero da rotina no menudef a ser pesquisada
     * caso não seja passada a pesquisa será com base apenas na função
     * @returns Observable com o retorno da api
     */
    userHasAccess(cRotina: string, nOpc?: number): Observable<ProUserAccessInterface>;
    /**
     * efetua um get na api referente a função FWChkTblAccess do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @param cTabela Tabela a ser pesquisada
     * @param nOpc parametro opcional, numero da rotina no menudef a ser pesquisada
     * caso não seja passada a pesquisa será com base apenas na função
     * @returns Observable com o retorno da api
     */
    aliasHasAccess(cTabela: string, nOpc?: number): Observable<ProUserAccessInterface>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProUserAccessService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProUserAccessService>;
}

declare class ProAppConfigService {
    private http;
    private advplService;
    private sessionInfoService;
    private proAuthService;
    private _ProAppConfig;
    readyEmitter: EventEmitter<any>;
    constructor(http: HttpClient, advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService, proAuthService: ProAuthService);
    /**
     * @description Realiza o carregamento do appConfig.json e adiciona as informações de contexto.
     * @returns Promise, ProAppConfig
     */
    loadAppConfig(): Promise<object>;
    /**
     * @description Método para encerrar o aplicativo
     * @param ask Boolean que indica se o sistema deve perguntar antes de fechar o app
     */
    callAppClose(ask?: boolean): void;
    insideProtheus(): boolean;
    /**
     * @description Retorna as informações do appConfig.json (ProAppConfig)
     */
    get proAppConfig(): ProAppConfig;
    get nameApp(): string;
    get serverWithApiUrl(): string;
    /**
     * @description Retorna a linha de produto que está sendo utilizada.
     * @returns string
     */
    get productLine(): string;
    get isProtheusRender(): boolean;
    freeAppConfig(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAppConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAppConfigService>;
}

declare class ProAppConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAppConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProAppConfigModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProAppConfigModule>;
}

/**
 * @description
 *
 * Interface que representa as informações do papel de trabalho
 * no Protheus TFace
 */
interface ProRole {
    Code: string;
    Description: string;
}
interface ProRoleList {
    hasNext: boolean;
    items: Array<ProRole>;
}

declare class ProRoleService {
    private advplService;
    private sessionInfoService;
    constructor(advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService);
    getListofRoles(description?: string, page?: number, pageSize?: number): Observable<ProRoleList>;
    getRoleByCode(roleCode: string): Observable<ProRole>;
    /**
     * @description Retorna as informações de papel de trabalho do usuário.
     */
    get role(): ProRole;
    set role(role: ProRole);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProRoleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProRoleService>;
}

/**
 * @description Interface para informações gerais da sessão.
 */
interface ProSessionInfo {
    proCompany: ProCompany;
    proBranch: ProBranch;
    proModule: string;
    appName: string;
    proSystemModule: ProSystemModules;
    proDatabase: string;
    remoteRype: number;
    socketPort: number;
    proAppConfig: ProAppConfig | object;
    proIdiom: string;
    proRole: ProRole | object;
    token: ProAuthToken | object;
    erpAppConfig: ProAppConfig | object;
    proUser: ProUser | object;
    erpToken: ProAuthToken | object;
}

/**
 * @description Interface para configuração do tema.
 */
interface ProThemeConfiguration {
    Configuration: number;
    Description: string;
}

/**
 * @description Serviço para salvar as informações de sessão após login.
 */
declare class ProSessionInfoService {
    private proAppConfig;
    private appName;
    private proCompany;
    private proIdiom;
    private proBranch;
    private proDataBase;
    private remoteType;
    private socketPort;
    private proSystemModule;
    private proRole;
    private proModule;
    private token;
    private erpAppConfig;
    private proUser;
    private erpToken;
    private theme;
    /**
     * @description Atribui as informações de sessão.
     */
    setSessionInfo(): void;
    /**
     * @description Retorna o nome do ambiente a partir da URL.
     * @returns string com o nome do ambiente
     */
    getLocationPathNameEnvironment(): string;
    /**
     * @description Retorna objeto com informações gerais da sessão.
     * @returns ProSessionInfo
     */
    getSessionInfo(): ProSessionInfo;
    /**
     * @description Retorna as informações da empresa.
     * @returns ProCompany
     */
    getCompany(): ProCompany;
    /**
     * @description Retorna as informações da filial.
     * @returns ProBranch
     */
    getBranch(): ProBranch;
    /**
     * @description Retorna o módulo.
     * @returns string
     */
    getModule(): string;
    /**
     * @description Retorna as informações o nome do app.
     * @returns string
     */
    getAppName(): string;
    /**
     * @description Retorna as informações do módulo.
     * @returns ProSystemModules
     */
    getSystemModule(): ProSystemModules;
    /**
     * @description Retorna a database.
     * @returns string
     */
    getDataBase(): string;
    /**
     * @description Retorna tipo do remote.
     * @returns number
     */
    getRemoteType(): number;
    /**
     * @description Retorna porta de conexão do socket.
     * @returns number
     */
    getSocketPort(): number;
    /**
     * @description Retorna as informações do app.
     * @returns ProAppConfig
     */
    getAppConfig(): ProAppConfig;
    /**
     * @description Retorna idioma.
     * @returns string
     */
    getIdiom(): string;
    /**
     * @description Retorna as informações de papel de usuário.
     * @returns ProRole
     */
    getRole(): ProRole;
    /**
     * @description Retorna as do token do usuário.
     * @returns ProAuthToken
     */
    getToken(): ProAuthToken;
    /**
     * @description Retorna as informações do app.
     * @returns ProAppConfig
     */
    getErpAppConfig(): ProAppConfig;
    /**
     * @description Retorna as informações do usuário.
     * @returns ProUser
     */
    getUser(): ProUser;
    /**
     * @description Retorna as informações do token do usuário.
     * @returns ProAuthToken
     */
    getErpToken(): ProAuthToken;
    /**
    * @description Retorna o tema selecionado.
    * @returns ProThemeConfiguration
    */
    getTheme(): ProThemeConfiguration;
    /**
     * @description Atribui as informações da empresa.
     */
    private setCompany;
    /**
     * @description Atribui as informações da filial.
     */
    private setBranch;
    /**
     * @description Atribui o módulo.
     */
    private setModule;
    /**
     * @description Atribui o nome do app.
     */
    private setAppName;
    /**
     * @description Atribui as informações do módulo.
     */
    private setSystemModule;
    /**
     * @description Atribui a database.
     */
    private setDataBase;
    /**
     * @description Atribui o tipo de remote.
     */
    private setRemoteType;
    /**
     * @description Atribui a porta de conexão do socket.
     */
    private setSocketPort;
    /**
     * @description Atribui as informações do app.
     */
    private setAppConfig;
    /**
     * @description Atribui o idioma.
     */
    setIdiom(idiom: string): void;
    /**
     * @description Atribui as informações do papel de usuário.
     */
    private setRole;
    /**
     * @description Atribui as informações dao token do usuário.
     */
    private setToken;
    /**
     * @description Atribui as informações do app.
     */
    setErpAppConfig(appConfig: ProAppConfig): void;
    /**
     * @description Atribui as informações do usuário.
     */
    private setUser;
    /**
     * @description Atribui as informações do token do usuário.
     */
    setErpToken(erpToken: ProAuthToken): void;
    /**
    * @description Atribui o tema utilizado
    */
    setTheme(theme: ProThemeConfiguration): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSessionInfoService>;
}

declare class ProCompanyService {
    private http;
    private advplService;
    private sessionInfoService;
    private url;
    private useHTTP;
    readonly EVENT_GET_LIST_ID = "getCompaniesList";
    readonly EVENT_SET_LIST_ID = "setCompaniesList";
    readonly EVENT_GET_ONE_ID = "getCompanyInfo";
    readonly EVENT_SET_ONE_ID = "setCompanyInfo";
    constructor(http: HttpClient, advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService);
    getListOfCompanies(CorporateName?: string, page?: number, _pageSize?: number): Observable<ProCompanyList>;
    /**
     * @description Retorna as empresas do usuário
     * @param corporateName string, nome da empresa
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @returns ProCompanyList, lista de empresas do usuário
     */
    getUserCompanies(corporateName?: string, page?: number, pageSize?: number): Observable<ProCompanyList>;
    private getListOfCompaniesFromApi;
    private getListOfCompaniesFromAdvpl;
    getCompany(company: string): Observable<ProCompany>;
    private getCompanyFromApi;
    private getCompanyFromAdvpl;
    /**
     * @description Retorna a empresa logada.
     * @returns ProCompany
     */
    get company(): ProCompany;
    set company(company: ProCompany);
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProCompanyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProCompanyService>;
}

declare class ProBranchService {
    private http;
    private advplService;
    private proCompanyService;
    private sessionInfoService;
    private url;
    private useHTTP;
    readonly EVENT_SET_LIST_ID = "setBranchesList";
    readonly EVENT_GET_LIST_ID = "getBranchesList";
    readonly EVENT_SET_ONE_ID = "setBranchInfo";
    readonly EVENT_GET_ONE_ID = "getBranchInfo";
    constructor(http: HttpClient, advplService: ProJsToAdvplService, proCompanyService: ProCompanyService, sessionInfoService: ProSessionInfoService);
    getListOfBranches(Description?: string, page?: number, _pageSize?: number): Observable<ProBranchList>;
    /**
     * @description Retorna as filiais do usuário
     * @param description string, descrição da filial
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @returns ProBranchList, lista de filiais do usuário
     */
    getUserBranches(description?: string, page?: number, pageSize?: number): Observable<ProBranchList>;
    /**
     * @description Retorna as filiais do usuário via requisição http
     * @param description string, descrição da filial
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @param isToFilterEnterpriseGroup boolean, indica se as filiais devem ser filtradas por empresa
     * @returns ProBranchList, lista de filiais do usuário
     */
    private getListOfBranchesFromApi;
    private getListOfBranchesFromAdvpl;
    getBranch(branch: string, company?: string): Observable<ProBranch>;
    private getBranchFromApi;
    private getBranchFromAdvpl;
    /**
     * @description Retorna a filial logada.
     * @returns ProBranch
     */
    get branch(): ProBranch;
    set branch(branch: ProBranch);
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBranchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProBranchService>;
}

declare class ProBranchLookupService implements PoLookupFilter {
    private proBranchService;
    private useHTTP;
    constructor(proBranchService: ProBranchService);
    getFilteredItems(params: PoLookupFilteredItemsParams): Observable<any>;
    getObjectByValue(value: string): Observable<any>;
    setBranch(branch: ProBranch): void;
    setChannelAsHTTP(value: boolean): void;
    isChannelHTTP(): boolean;
    private changeServiceChannel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBranchLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProBranchLookupService>;
}

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será branch_code
 */
declare class ProBranchLookupComponent {
    service: ProBranchLookupService;
    /** Formulário pai do componente. Para formulários template-driven passe o ngModel.  */
    parent: any;
    branchSetted: EventEmitter<ProBranch>;
    pLabel?: string;
    pHint?: string;
    columns?: Array<PoLookupColumn>;
    lookup: PoLookupComponent;
    constructor(service: ProBranchLookupService);
    fieldFormat(value: ProBranch): string;
    /**
     * @description metodo para setar o foco no lookup de branch
     */
    setBranchFocus(): void;
    setBranch(branch: ProBranch): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBranchLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProBranchLookupComponent, "pro-branch-lookup", never, { "parent": { "alias": "parent"; "required": false; }; "pLabel": { "alias": "p-label"; "required": false; }; "pHint": { "alias": "p-hint"; "required": false; }; "columns": { "alias": "pro-columns"; "required": false; }; }, { "branchSetted": "branchSetted"; }, never, never, false, never>;
}

declare class ProBranchLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBranchLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProBranchLookupModule, [typeof ProBranchLookupComponent], [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PoFieldModule, typeof i4.PoTooltipModule], [typeof ProBranchLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProBranchLookupModule>;
}

declare class ProCompanyLookupService implements PoLookupFilter {
    private proCompanyService;
    private useHTTP;
    constructor(proCompanyService: ProCompanyService);
    getFilteredItems(params: PoLookupFilteredItemsParams): Observable<any>;
    getObjectByValue(value: string): Observable<any>;
    setCompany(company: ProCompany): void;
    setChannelAsHTTP(value: boolean): void;
    isChannelHTTP(): boolean;
    private changeServiceChannel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProCompanyLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProCompanyLookupService>;
}

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será company_code
 */
declare class ProCompanyLookupComponent {
    service: ProCompanyLookupService;
    /** Formulário pai do componente. Para formulários template-driven passe o ngModel.  */
    parent: any;
    companySetted: EventEmitter<ProCompany>;
    branchSetted: EventEmitter<void>;
    pLabel?: string;
    pHint?: string;
    columns?: Array<PoLookupColumn>;
    lookup: PoLookupComponent;
    private started;
    firstPass: boolean;
    /**
     * @description Construtor da classe
     * @param service Serviço de Lookup do grupo de empresas
     */
    constructor(service: ProCompanyLookupService);
    fieldFormat(value: ProCompany): string;
    setCompanyFocus(): void;
    setStarted(started: boolean): void;
    /**
     * @description Efetua o set do grupo de empresas para o serviço, atualiza o parent e disparada o evento
     * @param company Objeto do grupo de empresas
     */
    setCompany(company: ProCompany): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProCompanyLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProCompanyLookupComponent, "pro-company-lookup", never, { "parent": { "alias": "parent"; "required": false; }; "pLabel": { "alias": "p-label"; "required": false; }; "pHint": { "alias": "p-hint"; "required": false; }; "columns": { "alias": "pro-columns"; "required": false; }; }, { "companySetted": "companySetted"; "branchSetted": "branchSetted"; }, never, never, false, never>;
}

declare class ProCompanyLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProCompanyLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProCompanyLookupModule, [typeof ProCompanyLookupComponent], [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PoFieldModule, typeof i4.PoTooltipModule], [typeof ProCompanyLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProCompanyLookupModule>;
}

declare class ProRoleLookupService implements PoLookupFilter {
    private proRoleService;
    constructor(proRoleService: ProRoleService);
    getFilteredItems(params: PoLookupFilteredItemsParams): Observable<any>;
    getObjectByValue(code: string): Observable<any>;
    setRole(role: ProRole): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProRoleLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProRoleLookupService>;
}

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será role_code
 */
declare class ProRoleLookupComponent {
    service: ProRoleLookupService;
    /** Formulário pai do componente. Para formulários template-driven passe o ngModel.  */
    parent: any;
    roleSetted: EventEmitter<ProRole>;
    pLabel?: string;
    pHint?: string;
    columns?: Array<PoLookupColumn>;
    pDisabled?: string;
    constructor(service: ProRoleLookupService);
    fieldFormat(value: ProRole): string;
    setRole(role: ProRole): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProRoleLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProRoleLookupComponent, "pro-role-lookup", never, { "parent": { "alias": "parent"; "required": false; }; "pLabel": { "alias": "p-label"; "required": false; }; "pHint": { "alias": "p-hint"; "required": false; }; "columns": { "alias": "pro-columns"; "required": false; }; "pDisabled": { "alias": "p-disabled"; "required": false; }; }, { "roleSetted": "roleSetted"; }, never, never, false, never>;
}

declare class ProRoleLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProRoleLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProRoleLookupModule, [typeof ProRoleLookupComponent], [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PoFieldModule, typeof i4.PoTooltipModule], [typeof ProRoleLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProRoleLookupModule>;
}

declare class ProSystemModuleLookupService implements PoLookupFilter {
    private proSystemModuleService;
    private useHTTP;
    constructor(proSystemModuleService: ProSystemModuleService);
    getFilteredItems(params: PoLookupFilteredItemsParams): Observable<any>;
    getObjectByValue(moduleId: string): Observable<any>;
    setSystemModule(systemModule: ProSystemModules): void;
    setChannelAsHTTP(value: boolean): void;
    isChannelHTTP(): boolean;
    private changeServiceChannel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemModuleLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSystemModuleLookupService>;
}

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será company_code
 */
declare class ProSystemModuleLookupComponent {
    service: ProSystemModuleLookupService;
    /** Formulário pai do componente. Para formulários template-driven passe o ngModel.  */
    parent: any;
    systeModuleSetted: EventEmitter<ProSystemModules>;
    pLabel?: string;
    pDisabled?: string;
    pHint?: string;
    columns?: Array<PoLookupColumn>;
    constructor(service: ProSystemModuleLookupService);
    fieldFormat(value: ProSystemModules): string;
    setSystemModule(systemModule: ProSystemModules): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemModuleLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProSystemModuleLookupComponent, "pro-system-module-lookup", never, { "parent": { "alias": "parent"; "required": false; }; "pLabel": { "alias": "p-label"; "required": false; }; "pDisabled": { "alias": "p-disabled"; "required": false; }; "pHint": { "alias": "p-hint"; "required": false; }; "columns": { "alias": "pro-columns"; "required": false; }; }, { "systeModuleSetted": "systeModuleSetted"; }, never, never, false, never>;
}

declare class ProSystemModuleLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemModuleLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProSystemModuleLookupModule, [typeof ProSystemModuleLookupComponent], [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PoFieldModule, typeof i4.PoTooltipModule], [typeof ProSystemModuleLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProSystemModuleLookupModule>;
}

declare class ProFieldsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProFieldsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProFieldsModule, never, [typeof ProCompanyLookupModule, typeof ProBranchLookupModule, typeof ProRoleLookupModule, typeof ProSystemModuleLookupModule], [typeof ProCompanyLookupModule, typeof ProBranchLookupModule, typeof ProRoleLookupModule, typeof ProSystemModuleLookupModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProFieldsModule>;
}

declare class ProHomeComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProHomeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProHomeComponent, "pro-home", never, {}, {}, never, never, false, never>;
}

declare class ProHomeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProHomeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProHomeModule, [typeof ProHomeComponent], [typeof i1.CommonModule], [typeof ProHomeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProHomeModule>;
}

declare class ProLoginDefaultsResolver {
    private proAuthService;
    constructor(proAuthService: ProAuthService);
    resolve(_route?: ActivatedRouteSnapshot, _state?: RouterStateSnapshot): Observable<ProUser>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProLoginDefaultsResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProLoginDefaultsResolver>;
}

/**
 * @description
 * Tipagem de dados da API de tradução (i18n)
 */
type ProI18N = any;

declare class ProBrandService {
    private http;
    private advplService;
    private proAppConfigService;
    private url;
    private useHTTP;
    private EVENT_GET_BRANDCONTEXT;
    private EVENT_SET_BRANDCONTEXT;
    constructor(http: HttpClient, advplService: ProJsToAdvplService, proAppConfigService: ProAppConfigService);
    getERPBrand(): Observable<string>;
    /**
     * @description Cria um observable para a comunicação com o ADVPL
     * @returns Observable de string sobre a marca do ambiente
     */
    private getAdvplBrandContext;
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBrandService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProBrandService>;
}

/**
 * @description
 *
 * Interface que representa a lista de idiomas
 * no Protheus TFace
 */
interface ProLanguageList extends Array<PoLanguage> {
}

declare class ProLanguageService {
    private http;
    private advplService;
    private proAppConfigService;
    private url;
    private useHTTP;
    private EVENT_GET_LANGUAGES;
    private EVENT_SET_LANGUAGES;
    constructor(http: HttpClient, advplService: ProJsToAdvplService, proAppConfigService: ProAppConfigService);
    getListOfLanguages(): Observable<ProLanguageList>;
    private getAdvplLanguages;
    private advplNotPrepared;
    isChannelHTTP(): boolean;
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProLanguageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProLanguageService>;
}

declare class ProMessageService {
    private poNotificationService;
    private advplService;
    constructor(poNotificationService: PoNotificationService, advplService: ProJsToAdvplService);
    showOneMessage(message: string, type?: number): void;
    /**
     * @description Exibe uma mensagem via notificação
     * @param message Mensagem
     * @param type Tipo da mensage, como erro, informação etc
     */
    showMessage(message: string, type?: number): void;
    /**
     * @description Executa a mudança do idioma no Protheus via Observable do advplService
     * @param language idioma escolhido via po-select
     * @returns Observable de boolean da confirmação da troca do idioma no BackEnd
     */
    changeLanguage(language: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProMessageService>;
}

/**
 * @description
 *
 * Interface que representa as informações das configurações da sessão
 * no Protheus TFace
 */
interface ProSessionSettings {
    base_date?: string | Date;
    company_code?: string;
    company_description?: string;
    branch_code?: string;
    branch_description?: string;
    environment_code?: string | number;
    environment_description?: string;
    environment_when?: boolean;
    role_code?: string;
    role_description?: string;
    role_when?: boolean;
    show_mdi_menu_info?: boolean;
    mdi_menu_info?: boolean;
    show_go_emp_fil?: boolean;
    go_emp_fil?: boolean;
    disable_back_button?: boolean;
}

declare class ProSessionSettingsService {
    private http;
    private advplService;
    private sessionInfoService;
    constructor(http: HttpClient, advplService: ProJsToAdvplService, sessionInfoService: ProSessionInfoService);
    requestSettingsDefaults(): Observable<ProSessionSettings>;
    /**
     * @description Realiza a limpeza das informações adicionadas na tela de sessão.
     */
    clearSettingsDefaults(): void;
    saveSettingsDefaults(session: ProSessionSettings): Observable<ProSessionSettings>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionSettingsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSessionSettingsService>;
}

declare class ProSessionSettingsDefaultsResolver {
    private sessionSettingsService;
    constructor(sessionSettingsService: ProSessionSettingsService);
    resolve(_route?: ActivatedRouteSnapshot, _state?: RouterStateSnapshot): Observable<ProSessionSettings>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionSettingsDefaultsResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSessionSettingsDefaultsResolver>;
}

declare class ProSessionSettingsUserInfoResolver {
    private proUserInfoService;
    private proAuthService;
    constructor(proUserInfoService: ProUserInfoService, proAuthService: ProAuthService);
    resolve(_route?: ActivatedRouteSnapshot, _state?: RouterStateSnapshot): Observable<ProUserInfo>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionSettingsUserInfoResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSessionSettingsUserInfoResolver>;
}

declare class ProDateService {
    private advplService;
    readonly EVENT_SET_FORMAT: string;
    readonly EVENT_GET_FORMAT: string;
    /**
     * @description Metodo construtor da classe
     * @param advplService Serviço ProJsToAdvplService para comunicação via jsToAdvpl
     */
    constructor(advplService: ProJsToAdvplService);
    /**
     * @description Retorna o formato da data do sistema protheus com base no idioma.
     * @param language string codigo do idioma.
     * @returns Observable de string
     */
    getDateFormat(language?: string): Observable<string>;
    /**
     * @description Retorna um erro da conexão jstoadvpl
     * @returns Observable de exceção
     */
    private advplNotPrepared;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProDateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProDateService>;
}

declare class ProI18nService {
    /**
     * @description
     * Efetua a transformação de um texto de tradução com tokens,
     * os tokens são iniciados com # e um número de 1 a 99.
     * Os valores são convertidos para string via função String do JS,
     * não possuindo um padrão de conversão
     *
     * @param str Texto de internacionalização
     * @param values Lista de tokens, podendo ter de 0 a 99 itens
     * @returns Texto original com a substituição dos tokens (#)
     */
    static getTranslateTokenString(str: string, values?: Array<any>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProI18nService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProI18nService>;
}

/**
 * @description Classe para consumo de traduções de resource presentes no RPO do Protheus
 */
declare class ProTranslateStringService {
    private http;
    private advplService;
    private proAppConfigService;
    private url;
    private useHTTP;
    private EVENT_GET_TRANSLATES;
    private EVENT_SET_TRANSLATES;
    /**
     * @description Construtor da classe
     * @param http Objeto HttpClient para efetuar as requisições REST
     * @param advplService Serviço ProJsToAdvplService para comunicação via jsToAdvpl
     * @param proAppConfigService Serviço ProAppConfigService para verificação de estado (Advpl/Http)
     */
    constructor(http: HttpClient, advplService: ProJsToAdvplService, proAppConfigService: ProAppConfigService);
    /**
     * @description Retorna todas as string de um resource de tradução do Protheus
     * @param cTRES string contendo o nome do resource (CH)
     * @returns Retorna um json que pode conter nenhuma ou várias chaves de string, normalmente enumeradas de str0001 até str9999
     */
    getStrList(cTRES: string): Observable<ProI18N>;
    /**
     * @description Retorna as traduções do resource via ADVPL (jstoadvpl)
     * @returns Observable das traduções do resource do Protheus
     */
    private getAdvplLanguages;
    /**
     * @description Retorna um erro da conexão jstoadvpl
     * @returns Observable de exceção
     */
    private advplNotPrepared;
    /**
     * @description Indica o consumo de API via HTTP ou jstoadvpl
     * @returns Informa se a classe fará a requisição via HTTP
     */
    isChannelHTTP(): boolean;
    /**
     * @description Permite dizer se a requisição será efetuada via HTTP ou jstoadvpl, sempre usar como HTTP, apenas pequenas exceções como jstoadvpl
     * @param value Uso de HTTP para requisição
     */
    setChannelAsHTTP(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProTranslateStringService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProTranslateStringService>;
}

/**
 * @description
 * Módulo para concentrar todas as strings e serviços de tradução
 * que envolvem o PoI18nConfig e o PoI18nModule
 */
declare class ProI18nConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProI18nConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProI18nConfigModule, never, [typeof i4.PoI18nModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProI18nConfigModule>;
}

declare class ProMessagesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProMessagesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProMessagesModule, never, [typeof i1.CommonModule, typeof i4.PoNotificationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProMessagesModule>;
}

/**
 * @description Módulo de idioma, contendo os serviços e interceptor
 */
declare class ProLanguageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProLanguageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProLanguageModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProLanguageModule>;
}

declare class ProThemeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProThemeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProThemeModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProThemeModule>;
}

declare class ProBrandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProBrandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProBrandModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProBrandModule>;
}

/**
 * @description Módulo com as classes que retornam informações da thread do Protheus
 */
declare class ProThreadInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProThreadInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProThreadInfoModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProThreadInfoModule>;
}

/**
 * @description Módulo contendo as classes para consumo de traduções do Protheus, traduções presentes no RPO do Protheus como resources
 */
declare class ProTranslateStringModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProTranslateStringModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProTranslateStringModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProTranslateStringModule>;
}

declare class ProUserProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProUserProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProUserProfileModule, never, [typeof i1.CommonModule, typeof ProI18nConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProUserProfileModule>;
}

declare class ProDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProDateModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProDateModule>;
}

/**
 * @description Módulo contendo os serviços do protheus-lib-core
 */
declare class ProServicesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProServicesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProServicesModule, never, [typeof i1.CommonModule, typeof ProAppConfigModule, typeof ProAuthorizationModule, typeof ProJsToAdvplModule, typeof ProMessagesModule, typeof ProTenantModule, typeof ProSystemInfoModule, typeof ProLanguageModule, typeof ProThemeModule, typeof ProBrandModule, typeof ProThreadInfoModule, typeof ProTranslateStringModule, typeof ProUserProfileModule, typeof ProDateModule], [typeof ProAppConfigModule, typeof ProAuthorizationModule, typeof ProJsToAdvplModule, typeof ProMessagesModule, typeof ProTenantModule, typeof ProSystemInfoModule, typeof ProLanguageModule, typeof ProBrandModule, typeof ProThreadInfoModule, typeof ProTranslateStringModule, typeof ProUserProfileModule, typeof ProDateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProServicesModule>;
}

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header do idioma.
 */
declare class ProSystemIdiomInteceptor implements HttpInterceptor {
    private injector;
    private sessionInfoService;
    constructor(injector: Injector, sessionInfoService: ProSessionInfoService);
    /**
     * @description Intercept http para tratamento do módulo do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do módulo caso o ERP seja Protheus
     */
    intercept(original_request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    /**
     * @description Efetua a validação e adição do header de idioma
     * @param request Requisição HTTP Original
     * @returns HttpRequest, podendo ser alterada com a inclusão do idioma conforme o Protheus
     */
    private appendLanguageToRequest;
    /**
     * @description Retorna o idioma presente no storage do navegador
     * @returns string contendo o valor de idioma do Protheus
     */
    private getLanguage;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSystemIdiomInteceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProSystemIdiomInteceptor>;
}

/**
 * @description Interface das informações da thread do Protheus
 */
interface ProThreadInfo {
    userId?: string;
    userName?: string;
}

/***
 * @description Classe com métodos para recuperar informações da thread do Protheus, thread a qual abriu o app via FWCallApp
 */
declare class ProThreadInfoService {
    private proAuthService;
    private proUserInfoService;
    constructor(proAuthService: ProAuthService, proUserInfoService: ProUserInfoService);
    /**
     * @description Retorna um objeto contendo informações do usuário logado no app e na thread do Protheus
     * @returns ProThreadInfo = {userId, userName}
     * userId = ID do usuário
     * userName = Nome (login) do usuário
     */
    get proThreadInfo(): ProThreadInfo;
    /**
     * @description Recupera o ID do usuário logado no app e no Protheus
     * @returns ID do usuário
     */
    get userId(): string | null;
    /**
     * @description Recupera o nome (login) do usuário logado no app e no Protheus
     * @returns Nome do usuário (login)
     */
    get userName(): string | null;
    /**
     * @description Retorna informações do usuário logado (id, nome de usuário, nome e emails)
     * @returns ProUserInfo = {id, userName, displayName, emails}
     */
    getUserInfoThread(): Observable<ProUserInfo>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProThreadInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProThreadInfoService>;
}

declare class ProAdapterBaseV2Service {
    /**
     * @description Retorna parâmetros no formato HttpParams para ser enviado na requisição HTTP.
     *
     * @param page number, número da página
     * @param pageSize number, quantidade de registros da página
     * @param filter string, filtro a ser utilizado na requisição
     * @param fields string, campos a serem retornados pela requisição
     * @param order string, ordenação a ser utilizada no retorno da requisição
     *
     * @return HttpParams, parâmetros
    */
    getHttpParams(page?: number, pageSize?: number, filter?: string, fields?: string, order?: string): HttpParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProAdapterBaseV2Service, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProAdapterBaseV2Service>;
}

/**
 * @description
 * Interface base para o request da API /api/framework/v1/profileService
 */
interface ProUserProfileRequestInterface {
    programName: string;
    task: string;
    type: string;
    value: string;
}

declare class ProUserProfileService {
    private http;
    private poI18nService;
    private readonly URL_PROFILE;
    programName: string;
    task: string;
    type: string;
    isReady: boolean;
    literals: any;
    constructor(http: HttpClient, poI18nService: PoI18nService);
    /**
     * Metodo para definir o profile a ser utilizado
     * antes de utilizar qualquer metodo de CRUD é necessário definir o profile por esse metodo.
     * @param programName Nome do programa a ser usado no profile
     * @param task Nome da tarefa a ser utilizado no profile
     * @param type Tipo a ser utilizado no profile
     */
    setProfile(programName: string, task: string, type: string): void;
    /**
     * Cria um novo registro no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    create(value: string): Observable<any>;
    /**
     * Busca o valor de uma chave salva no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param defaultValue Valor padrão a ser retornado caso não exista o profile na base
     * @param respType tipo a ser retornado, podendo ser apenas json ou text
     * @returns Observable com o retorno da api
     */
    read(defaultValue?: string, respType?: any): Observable<any>;
    /**
     * Atualiza um registro no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    update(value: string): Observable<any>;
    /**
     * Deleta um registro no profile
     * @returns Observable com o retorno da api
     */
    delete(): Observable<any>;
    /**
     * Deleta e cria um registro no profile
     * esse metodo pode substituir o uso do metodo create e update em alguns casos
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    deleteThenCreate(value: string): Observable<any>;
    /**
     * Observable para apresentar um erro para o usuário caso utilize algum metodo de CRUD
     * sem utilizar o setProfile antes
     * @returns Observable com erro
     */
    private profileNotReady;
    /**
     * retorna a composição da url da api, com os path param necessários
     * @returns url completa da api
     */
    getUrlApi(): string;
    /**
     * body para ser utilizado no post e update da api de profile
     * @param value Valor a ser gravado no profile
     * @returns o body a ser utilizado
     */
    getRequisitionBody(value: string): ProUserProfileRequestInterface;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProUserProfileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProUserProfileService>;
}

/**
 * @description
 *
 * Interface base para o retorno de APIs que utilizam a classe FwAdapterBaseV2.
 * O T indica o tipo dos registros a serem retornados na propriedade items.
 *
 */
interface ProAdapterBaseV2<T> {
    items: Array<T>;
    hasNext: boolean;
    remainingRecords: number;
}

/**
 * @description
 * Interface base para os parametros da API /api/framework/v1/genericList
 */
interface ProAdapterListInterface {
    alias: string;
    filialFilter?: boolean;
    deletedFilter?: boolean;
    page?: number;
    pageSize?: number;
    filter?: string;
    fields?: string;
    order?: string;
    quickSearch?: string;
    [key: string]: any;
}
/**
 * @description
 * Interface base para os parametros da API /api/framework/v1/genericQuery
 */
interface ProAdapterQueryInterface {
    tables: string;
    where?: string;
    fromQry?: string;
    filialFilter?: boolean;
    deletedFilter?: boolean;
    page?: number;
    pageSize?: number;
    filter?: string;
    fields?: string;
    order?: string;
    quickSearch?: string;
    [key: string]: any;
}

declare class ProGenericAdapterService {
    private http;
    private readonly URL_LIST;
    private readonly URL_QUERY;
    constructor(http: HttpClient);
    /**
     * Metodo para devolver uma listagem de registro baseado na api genericList
     * @param searchParams parametros da interface ProAdapterListInterface a ser enviado
     * para api genericList
     * @returns Observable de ProAdapterBaseV2 a ser utilizado em um po-table
     */
    list<T>(searchParams: ProAdapterListInterface): Observable<ProAdapterBaseV2<T>>;
    /**
     * Metodo para devolver uma listagem de registro baseado na api genericQuery
     * @param searchParams parametros da interface ProAdapterQueryInterface a ser enviado
     * para api genericQuery
     * @returns Observable de ProAdapterBaseV2 a ser utilizado em um po-table
     */
    query<T>(searchParams: ProAdapterQueryInterface): Observable<ProAdapterBaseV2<T>>;
    /**
     * converte uma interface para httpParams
     * cada propriedade vira um parametro http
     * @param searchParams parametro a ser convetido
     * @returns httpParams a ser utilizado em uma requisição
     */
    private convertSearchParamsToHttpParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProGenericAdapterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProGenericAdapterService>;
}

declare class ProThemeService {
    private poTheme;
    private proJsToAdvplService;
    private proUserProfileService;
    private proSessionInfoService;
    theme: PoTheme;
    /** Definição para atributo theme */
    private readonly themeConfigMap;
    constructor(poTheme: PoThemeService, proJsToAdvplService: ProJsToAdvplService, proUserProfileService: ProUserProfileService, proSessionInfoService: ProSessionInfoService);
    /**
     * @description Método para configurar o tema do aplicativo com base
     * na configuração da localStorage - ProTheme
     * @param theme ProThemeEnum, tema a ser aplicado
     * @param type PoThemeTypeEnum, tipo do tema
     */
    setTheme(theme?: PoTheme, type?: PoThemeTypeEnum): void;
    private getProtheusConfig;
    /**
     * @description Retorna se o usuário pode habilitar o tema dark.
     * @returns Observable de boolean
    */
    canUseDarkTheme(): Observable<boolean>;
    /**
     * @description Consulta se pode utilizar o tema dark fazendo a conexão direta com advpl.
     * @returns Observable de boolean
     */
    private checkDarkFromAdvpl;
    /**
     * @description Salva no profile do usuário se ele ativou ou desativou o tema dark.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    setThemeProfile(value: string): Observable<boolean>;
    /**
     * @description Salva no profile fazendo a comunicação direta com o Protheus via JsToAdvpl.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    private setThemeProfileFromAdvpl;
    /**
     * @description Salva no profile via api.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    private setThemeProfileFromApi;
    /**
     * @description Retorna o profile do usuário indicando se ele ativou/desativou o tema dark.
     * @returns Observable de boolean
     */
    getThemeProfile(): Observable<boolean>;
    /**
     * @description Retorna o profile realização a comunicação direta com o Protheus via JsToAdvpl.
     * @returns Observable de boolean
     */
    private getThemeProfileFromAdvpl;
    /**
     * @description Renotar o profile do usuário via api.
     * @returns Observable de boolean
     */
    private getThemeProfileFromApi;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProThemeService>;
}

declare class ProSessionSettingsComponent implements OnInit, OnDestroy {
    private formBuilder;
    private router;
    private messageService;
    private route;
    private proSessionSettingsService;
    private proCompanyService;
    private proRoleService;
    private proBranchService;
    private poI18nService;
    private proTranslateStringService;
    private proBrandService;
    private proSystemModuleService;
    private proThemeService;
    private proDateService;
    private proAuthService;
    private proJsToAdvplService;
    displayName: string;
    settingForm: UntypedFormGroup;
    isLoading: boolean;
    logo: string;
    secondaryLogo: string;
    productName: string;
    brand: string;
    literals: any;
    fixedModule: boolean;
    fixedRole: boolean;
    disableBackButton: boolean;
    showMDIMenuInfo: boolean;
    showGoEmpFil: boolean;
    useHTTP: boolean;
    darkSwitchValue: boolean;
    isDarkAllowed: boolean;
    isLoadingDark: boolean;
    dateFormat: string;
    isTokenValid: boolean;
    private _ProSessionSettingsDefaults;
    private subs;
    private cnpjTitle;
    private poI18nPipe;
    private darkTheme;
    private brandSubscription;
    /** Insere uma Tag com o ambiente em execuação. */
    environment?: string;
    /** Insere uma imagem de destaque ao lado direito do container. */
    background?: string;
    /** Designa se o logotipo deve desaparecer em resoluções menores. */
    hideLogo?: boolean;
    /** Texto de destaque sobreposto à imagem de destaque. Essa opção é utilizada em conjunto com o atributo `p-background`. */
    highlightInfo?: string;
    proBranchLookupComponent: ProBranchLookupComponent;
    proCompanyLookupComponent: ProCompanyLookupComponent;
    readonly companyColumns: Array<PoLookupColumn>;
    branchColumns: Array<PoLookupColumn>;
    readonly moduleColumns: Array<PoLookupColumn>;
    readonly roleColumns: Array<PoLookupColumn>;
    /**
     * @description metodo chamado na mudança do combox de idioma da tela de parametros da sessão
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    onSelectedLanguage(language: string): void;
    /**
     * @description Atualiza as strings traduzíveis da interface
     * @param literals Objeto de literais, contendo as traduções da interface
     */
    updLiterals(literals: any): void;
    /**
     * @description Atualiza as strings de tradução as colunas do Lookup de filial
     */
    updateBranchLiterals(): void;
    activateSupport(url?: string): void;
    /**
     * @description Método para obter o link de suporte
     * @returns Retorna uma string contendo o link de suporte do ERP
     */
    getSupportLink(): string;
    /**
     * @description Efetua o redirect conforme a URL recebida
     * @param url URL que será verificada, podendo abrir uma janela ou mudar a rota
     */
    private setUrlRedirect;
    /**
     * @description Construtor da classe
     * @param formBuilder Objeto FormBuilder para controle do formulário
     * @param router Objeto Router para controle da rota
     * @param messageService Serviço ProMessageService para exibição de notificações
     * @param route Objeto ActivatedRoute para controle da rota atual
     * @param proSessionSettingsService Serviço ProSessionSettingsService para obter os dados de login salvos
     * @param proCompanyService Serviço ProCompanyService para obter dados do grupo de empresas
     * @param proRoleService Serviço ProRoleService para obter dados de papel de trabalho
     * @param proBranchService Serviço ProBranchService para obter dados da filial
     * @param poI18nService Serviço PoI18nService para tradução da interface via dados locais
     * @param proTranslateStringService Serviço ProTranslateStringService para tradução da interface via API do Protheus
     * @param proBrandService Serviço para identificação da marca, MA3 na russia
     * @param proAuthService Serviço para Autenticação
     */
    constructor(formBuilder: UntypedFormBuilder, router: Router, messageService: ProMessageService, route: ActivatedRoute, proSessionSettingsService: ProSessionSettingsService, proCompanyService: ProCompanyService, proRoleService: ProRoleService, proBranchService: ProBranchService, poI18nService: PoI18nService, proTranslateStringService: ProTranslateStringService, proBrandService: ProBrandService, proSystemModuleService: ProSystemModuleService, proThemeService: ProThemeService, proDateService: ProDateService, proAuthService: ProAuthService, proJsToAdvplService: ProJsToAdvplService);
    /**
     * @description Lista de colunas do Lookup de filiais
     * @returns Retorna uma lista de PoLookupColumn, contendo as colunas padrões do Lookup de filiais
     */
    getDefaultBranchColumns(): Array<PoLookupColumn>;
    /**
     * @description metodo disparado a partir de um evento no lookup de company
     * utilizado para forçar o foco no lookup de branch
     */
    branchSettedEvent(): void;
    /**
     * @description Método disparado via o evento de troca de grupo de empresas
     * @param event Evento do formulário
     */
    changeBranchColumns(event: any): void;
    /**
     * @description Método do ciclo de vida do Angular, esse método é chamado após o construtor da classe
     */
    ngOnInit(): void;
    /**
     * @description Responda depois que o Angular inicializar as visualizações do componente e as visualizações filhas ou a visualização que contém a diretiva.
     * utilizado aqui para setar o foco no componente de grupo de empresa na abertura da tela
     * e definir a variavel started para true do componente company
     */
    ngAfterViewInit(): void;
    /**
     * @description Atribui configurações para o tema dark.
     */
    setDarkThemeConfiguration(): void;
    /**
     * @description Atualiza o título da coluna de CNPJ da consulta de filiais conforme API
     */
    updateCnpjTitle(): void;
    /**
     * @description Atualiza o título da coluna de CNPJ no objeto da coluna da interface já criada
     */
    updateCnpjTitleColumn(): void;
    /**
     * @description Atualiza a descrição do modulo selecionado
     */
    updateModuleDescription(): void;
    /**
     * @description Cria e retorna o dados de controle de formulário das configurações de login
     * @returns Retorna o FormGroup do formulário de dados de login
     */
    private buildForm;
    moduleValidator(control: UntypedFormControl): ValidationErrors;
    private subscribeToResolver;
    validateResolverData(resolveData: Data): void;
    set sessionSettingsDefaults(defaults: ProSessionSettings);
    get sessionSettingsDefaults(): ProSessionSettings;
    convertDateforPoDatePicker(base_date: any): any;
    private loadSettingForm;
    onSessionSettingBack(): void;
    onSessionSettingSubmit(): void;
    submitForm(): void;
    ngOnDestroy(): void;
    private onErrorSubmit;
    private saveSettings;
    setChannelAsHTTP(value: boolean): void;
    isChannelHTTP(): boolean;
    /**
     * @description Atualiza o Canal de comunicação
     * dos serviços utilizados pelo componente
     * @returns void
     */
    private changeServicesChannel;
    /**
     * @description Atualiza as variaveis a partir da marca
     * ma3 na russia e protheus nas demais
     * @returns void
     */
    updateResourceByBrand(): void;
    /**
     * @description atualiza a variavel productName.
     * quando não for MA3 precisa atualziar com a literals cada vez que muda o idioma
     * @returns void
     */
    updateProductName(): void;
    /**
     * @description atualiza a variavel de marca
     * @returns void
     */
    updateBrand(): void;
    /**
     * @description atualiza o formato de data do po-datepicker
     * @param language string codigo do idioma.
     * @returns void
     */
    updateDateFormat(language: string): void;
    /**
     * @description Retorna ícone a ser utilizado no botão de ativar/desativar o dark.
     * @returns string
     */
    getDarkSwitchClass(): string;
    /**
     * @description Retorna o texto de apoio a ser utilizado no botão de ativar/desativar o dark.
     * @returns string
     */
    getDarkTooltipValue(): string;
    /**
     * @description Executa ação ao ativar/desativar o dark.
     * @param value boolean
     */
    onChangeDarkSwitchValue(value: boolean): void;
    /**
     * @description Consulta se mostra ou não o botão de ativar/desativar o dark.
     */
    canUseDarkTheme(): void;
    /**
     * @description Consulta valor do profile para saber se usuário está com o dark habilitado.
     * @param isDarkAllowed boolean, indica se o usuário pode ativar/desativar o dark.
     * @returns Observable de string
     */
    getProfileValue(isDarkAllowed: boolean): Observable<boolean>;
    /**
     * @description
     * Notificar o usuário que a autenticação foi bem sucessidade. Utilizada em casos que a página de Autenticação é igorada
     */
    showLoginMessage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionSettingsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProSessionSettingsComponent, "pro-session-settings", never, { "environment": { "alias": "p-environment"; "required": false; }; "background": { "alias": "p-background"; "required": false; }; "hideLogo": { "alias": "p-hide-logo"; "required": false; }; "highlightInfo": { "alias": "p-highlight-info"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProPageBackgroundComponent implements OnInit {
    poLanguageService: PoLanguageService;
    private proLanguageService;
    private _logo?;
    private _secondaryLogo?;
    private _showSelectLanguage?;
    selectedLanguageOption: string;
    selectLanguageOptions: Array<PoSelectOption>;
    /** Insere uma imagem de destaque ao lado direito do container. */
    background?: string;
    /** Designa se o logotipo deve desaparecer em resoluções menores. */
    hideLogo?: boolean;
    /** Texto de destaque sobreposto à imagem de destaque. Essa opção é utilizada em conjunto com o atributo `p-background`. */
    highlightInfo?: string;
    /** Caminho para a logomarca localizada na parte superior. */
    set logo(value: any);
    get logo(): any;
    /**
     * @optional
     *
     * @description
     *
     * Caminho para a logomarca localizada no rodapé.
     */
    set secondaryLogo(value: any);
    get secondaryLogo(): any;
    /** Define se o seletor de idiomas deve ser exibido. */
    set showSelectLanguage(showSelectLanguage: boolean);
    get showSelectLanguage(): boolean;
    /**
     * Evento disparado ao selecionar alguma opção no seletor de idiomas.
     * Para este evento será passado como parâmetro o valor de idioma selecionado.
     */
    selectedLanguage?: EventEmitter<any>;
    /**
     * @description Construtor do componente
     * @param poLanguageService Serviço de idioma do PO UI
     * @param proLanguageService Serviço de idiomas do Protheus
     */
    constructor(poLanguageService: PoLanguageService, proLanguageService: ProLanguageService);
    /**
     * @description Atualiza os idiomas disponíveis
     */
    updateLangs(): void;
    ngOnInit(): void;
    onChangeLanguage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProPageBackgroundComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProPageBackgroundComponent, "pro-page-background", never, { "background": { "alias": "p-background"; "required": false; }; "hideLogo": { "alias": "p-hide-logo"; "required": false; }; "highlightInfo": { "alias": "p-highlight-info"; "required": false; }; "logo": { "alias": "p-logo"; "required": false; }; "secondaryLogo": { "alias": "p-secondary-logo"; "required": false; }; "showSelectLanguage": { "alias": "p-show-select-language"; "required": false; }; }, { "selectedLanguage": "p-selected-language"; }, never, ["*"], false, never>;
}

/**
 * @description
 *
 * Módulo do template do pro-page-background.
 */
declare class ProPageBackgroundModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProPageBackgroundModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProPageBackgroundModule, [typeof ProPageBackgroundComponent], [typeof i1.CommonModule, typeof i3.FormsModule, typeof i4$1.RouterModule, typeof i4.PoDividerModule, typeof i4.PoFieldModule], [typeof ProPageBackgroundComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProPageBackgroundModule>;
}

declare class ProSessionSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProSessionSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProSessionSettingsModule, [typeof ProSessionSettingsComponent], [typeof i1.CommonModule, typeof i4.PoButtonModule, typeof i4.PoFieldModule, typeof ProPageBackgroundModule, typeof i4.PoModule, typeof i4.PoTagModule, typeof i4.PoTooltipModule, typeof ProFieldsModule, typeof i3.ReactiveFormsModule], [typeof ProSessionSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProSessionSettingsModule>;
}

declare class ProLoginComponent implements OnInit, OnDestroy, AfterViewInit {
    private router;
    private route;
    private authService;
    private messageService;
    private poI18nService;
    private elRef;
    private proLanguageService;
    private proBrandService;
    private proMfaService;
    private proSessionSettingsService;
    private proJsToAdvplService;
    private _nextRoute;
    private _ProUserDefaults;
    private subs;
    isLoading: boolean;
    literals: any;
    productLine: string;
    brand: string;
    customLiterals: PoPageLoginLiterals;
    hideRememberUser: boolean;
    loginValue: string;
    inputFocus: string;
    languages: Array<PoLanguage>;
    logo: string;
    productName: string;
    set nextRoute(value: string);
    get nextRoute(): string;
    constructor(router: Router, route: ActivatedRoute, authService: ProAuthService, messageService: ProMessageService, poI18nService: PoI18nService, elRef: ElementRef, proLanguageService: ProLanguageService, proBrandService: ProBrandService, proMfaService: ProMfaService, proSessionSettingsService: ProSessionSettingsService, proJsToAdvplService: ProJsToAdvplService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    setFocusToInput(name: string): void;
    private subscribeToResolver;
    /**
     * @description Metodo que realiza o login no protheus
     * @returns Subscription
     */
    subscribeToLogin(user: ProUser): Subscription;
    /**
     * @description metodo que efetua o tratamento de erros.
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    private errorLogin;
    resetLoading(navigatePromise: any): void;
    validateResolverData(resolveData: Data): void;
    set userDefaults(defaults: ProUser);
    get userDefaults(): ProUser;
    onLoginSubmit(formData: PoPageLogin): void;
    /**
     * @description metodo chamado na mudança do combox de idioma da tela de login
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    onLanguageChange({ language }: {
        language: any;
    }): void;
    /**
     * @description Métodode atualização das traduções
     * @param objeto das traduções
     */
    updLiterals(literals: ProI18N): void;
    onLoginChange(login: string): void;
    callRecoverPassword(): void;
    /**
     * @description Método para obter o link de suporte e abrir em nova guia
     */
    supportLink(language?: string): void;
    private login;
    parseErrorMessage(error: any): string;
    /**
     * @description Atualiza os idiomas disponíveis
     */
    updateLangs(): void;
    /**
     * @description Atualiza as variaveis a partir da marca
     * ma3 na russia e protheus nas demais
     * @returns void
     */
    updateResourceByBrand(): void;
    /**
     * @description atualiza a variavel productName.
     * quando não for MA3 precisa atualziar com a literals cada vez que muda o idioma
     * @returns void
     */
    updateProductName(): void;
    /**
     * @description atualiza a variavel de marca
     * @returns void
     */
    updateBrand(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProLoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProLoginComponent, "pro-login", never, { "nextRoute": { "alias": "pro-next-route"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ProLoginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProLoginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProLoginModule, [typeof ProLoginComponent], [typeof i1.CommonModule, typeof i3$1.PoComponentsModule, typeof i3.ReactiveFormsModule], [typeof ProLoginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProLoginModule>;
}

declare class ProPagesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProPagesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProPagesModule, never, [typeof ProI18nConfigModule, typeof ProHomeModule, typeof i4.PoModule, typeof ProLoginModule, typeof ProPageBackgroundModule, typeof ProSessionSettingsModule], [typeof ProHomeModule, typeof ProLoginModule, typeof ProPageBackgroundModule, typeof ProSessionSettingsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProPagesModule>;
}

declare class ProComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProComponentsModule, never, [typeof ProFieldsModule, typeof ProPagesModule], [typeof ProFieldsModule, typeof ProPagesModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProComponentsModule>;
}

declare class ProtheusLibCoreModule {
    private themeService;
    constructor(themeService: ProThemeService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProtheusLibCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProtheusLibCoreModule, never, [typeof ProComponentsModule, typeof ProServicesModule], [typeof ProComponentsModule, typeof ProServicesModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProtheusLibCoreModule>;
}

declare function valueIsNull(value: any): boolean;
declare function convertToBoolean(val: any): boolean;
declare function isTypeof(object: any, type: any): boolean;
declare function isExternalLink(url: any): boolean;
declare function generateRandomId(): number;
/**
 * @description Função para bloquear a ação de "voltar" do navegador.
 * @param url string, indica a url a ser inserida como a url de entrada do histórico atual da sessão do navegador.
 * @param name string, indica o nome da rota a ser idetinficado no log enviado para o Protheus.
 * @param proJsToAdvpl ProJsToAdvplService, instância do serviço ProJsToAdvplService.
 */
declare function blockBackAction(url: string, name: string, proJsToAdvpl: ProJsToAdvplService): void;

export { ProAdapterBaseV2Service, ProAppConfigInteceptor, ProAppConfigModule, ProAppConfigService, ProAuthGuard, ProAuthInteceptor, ProAuthService, ProAuthorizationModule, ProBranchLookupComponent, ProBranchLookupModule, ProBranchLookupService, ProBranchService, ProBrandModule, ProBrandService, ProCompanyLookupComponent, ProCompanyLookupModule, ProCompanyLookupService, ProCompanyService, ProComponentsModule, ProDateModule, ProDateService, ProFieldsModule, ProGenericAdapterService, ProHomeComponent, ProHomeModule, ProI18nConfigModule, ProI18nService, ProJsToAdvplModule, ProJsToAdvplService, ProLanguageModule, ProLanguageService, ProLoginComponent, ProLoginDefaultsResolver, ProLoginModule, ProMessageService, ProMessagesModule, ProPageBackgroundComponent, ProPageBackgroundModule, ProPagesModule, ProRoleLookupComponent, ProRoleLookupModule, ProRoleLookupService, ProServicesModule, ProSessionInfoService, ProSessionSettingsComponent, ProSessionSettingsDefaultsResolver, ProSessionSettingsModule, ProSessionSettingsService, ProSessionSettingsUserInfoResolver, ProSystemDatabaseInterceptor, ProSystemIdiomInteceptor, ProSystemInfoModule, ProSystemModuleLookupComponent, ProSystemModuleLookupModule, ProSystemModuleLookupService, ProSystemModuleService, ProSystemModulesInteceptor, ProTenantModule, ProThreadInfoModule, ProThreadInfoService, ProTranslateStringModule, ProTranslateStringService, ProUserAccessService, ProUserInfoService, ProUserProfileModule, ProUserProfileService, ProtheusLibCoreModule, blockBackAction, convertToBoolean, generateRandomId, isExternalLink, isTypeof, valueIsNull };
export type { Email, Meta, Name, ProAccessToken, ProAdapterBaseV2, ProAdapterListInterface, ProAdapterQueryInterface, ProAppConfig, ProAuthToken, ProBranch, ProBranchList, ProCompany, ProCompanyList, ProI18N, ProJsToAdvpl, ProSessionSettings, ProSystemModules, ProSystemModulesList, ProThreadInfo, ProUser, ProUserAccessInterface, ProUserInfo, ProUserList, ProUserPswretInterface };
