import * as i0 from '@angular/core';
import { Injectable, NgModule, EventEmitter, ViewChild, Input, Output, Component } from '@angular/core';
import * as i3 from '@po-ui/ng-components';
import { PoLookupComponent, PoFieldModule, PoTooltipModule, PoToasterOrientation, PoI18nModule, PoThemeTypeEnum, PoThemeA11yEnum, PoNotificationModule, PoI18nPipe, PoDividerModule, PoButtonModule, PoModule, PoTagModule } from '@po-ui/ng-components';
import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders, HTTP_INTERCEPTORS, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, Subject, from, catchError as catchError$1, switchMap, map as map$1, tap as tap$1, concatMap } from 'rxjs';
import * as i3$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { map, tap, catchError, delay, retry, finalize, take, switchMap as switchMap$1 } from 'rxjs/operators';
import { SubSink } from 'subsink';
import * as i2$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i10 from '@po-ui/ng-templates';
import { PoComponentsModule } from '@po-ui/ng-templates';

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    useHTTP: false // Alterar apenas para DESENVOLVIMENTO!
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

function valueIsNull(value) {
    return value === null || value === undefined;
}
function convertToBoolean(val) {
    if (typeof val === 'string') {
        val = val.toLowerCase().trim();
        return val === 'true' || val === 'on' || val === '';
    }
    if (typeof val === 'number') {
        return val === 1;
    }
    return !!val;
}
function isTypeof(object, type) {
    return typeof object === type;
}
function isExternalLink(url) {
    return url ? url.startsWith('http') : false;
}
function generateRandomId() {
    return Math.floor(Math.random() * 100000 * new Date().getMilliseconds());
}
/**
 * @description Função para bloquear a ação de "voltar" do navegador.
 * @param url string, indica a url a ser inserida como a url de entrada do histórico atual da sessão do navegador.
 * @param name string, indica o nome da rota a ser idetinficado no log enviado para o Protheus.
 * @param proJsToAdvpl ProJsToAdvplService, instância do serviço ProJsToAdvplService.
 */
function blockBackAction(url, name, proJsToAdvpl) {
    const location = window.location.href;
    window.history.pushState(null, url, location);
    window.onpopstate = function () {
        proJsToAdvpl.jsToAdvpl('sendLogRedirect', name);
        window.history.pushState(null, url, location);
    };
}

class ProJsToAdvplService {
    constructor() { }
    hasDialog() {
        return (typeof dialog !== 'undefined' && typeof dialog.jsToAdvpl === 'function');
    }
    hasWebChannel() {
        return (typeof twebchannel !== 'undefined' &&
            typeof twebchannel.jsToAdvpl === 'function');
    }
    getWebChannel() {
        if (this.hasWebChannel()) {
            return twebchannel;
        }
        if (this.hasDialog()) {
            return dialog;
        }
    }
    jsToAdvpl(type, content) {
        const webChannel = this.getWebChannel();
        if (valueIsNull(webChannel)) {
            return false;
        }
        else {
            webChannel.jsToAdvpl(type, content);
            return true;
        }
    }
    /**
     * @description Método responsável por fechar app na camada advpl
     *
     * @param {string} value Valor que será enviado a camada advpl, sendo vazia ou force
     */
    AdvplCloseApp(value = '') {
        this.jsToAdvpl('close', value);
    }
    buildListener(id, callBack) {
        const webChannel = this.getWebChannel();
        if (webChannel && webChannel['eventTarget']) {
            webChannel['eventTarget'].addEventListener(id, callBack);
        }
    }
    buildObservable(callBack, options) {
        if (!options.receiveId && options.sendInfo && !options.sendInfo.content) {
            options.receiveId = options.sendInfo.type + '-' + this.generateEventId();
        }
        const buildedObservable = new Observable(subscriber => {
            const webChannel = this.getWebChannel();
            webChannel[options.receiveId] = {};
            webChannel[options.receiveId]['subscriber'] = subscriber;
            if (options.autoDestruct) {
                webChannel[options.receiveId]['autoDestruct'] = this.buildAutoDestruct(options.receiveId, callBack);
                webChannel['eventTarget'].addEventListener(options.receiveId, webChannel[options.receiveId]['autoDestruct']);
            }
            else {
                webChannel['eventTarget'].addEventListener(options.receiveId, callBack);
            }
        });
        if (options.sendInfo) {
            this.connectedJsToAdvpl(options.sendInfo.type, options.sendInfo.content ? options.sendInfo.content : options.receiveId);
        }
        return buildedObservable;
    }
    /**
     * @description Remove e apaga o evento
     * @param id ID do evento
     * @param callBack callback do evento
     * @returns
     */
    buildAutoDestruct(id, callBack) {
        return ({ protheusResponse, subscriber }) => {
            const webChannel = this.getWebChannel();
            callBack({ protheusResponse, subscriber });
            if (webChannel[id]) {
                webChannel['eventTarget'].removeEventListener(id, webChannel[id]['autoDestruct']);
                delete webChannel[id];
            }
        };
    }
    protheusConnected() {
        const webChannel = this.getWebChannel();
        return !valueIsNull(webChannel) && webChannel['gotConnection'];
    }
    connectedJsToAdvpl(type, value, retryCounter = 99, timeout = 50) {
        if (this.protheusConnected()) {
            this.jsToAdvpl(type, value);
        }
        else {
            if (retryCounter > 0) {
                retryCounter--;
                setTimeout(() => {
                    this.connectedJsToAdvpl(type, value, retryCounter, timeout);
                }, timeout);
            }
            else {
                console.log('jsToAdvpl type ' + type + ' not executed!');
            }
        }
    }
    generateEventId() {
        return generateRandomId();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class ProJsToAdvplModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProJsToAdvplModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule]
                }]
        }] });

/**
 * @description Serviço para salvar as informações de sessão após login.
 */
class ProSessionInfoService {
    /**Quando utilizado o ProtheusLibTHF desabilita a definição de tema */
    static { this.canSetTheme = true; }
    /**
     * @description Atribui as informações de sessão.
     */
    setSessionInfo() {
        this.setCompany(JSON.parse(sessionStorage['ProCompany']));
        this.setBranch(JSON.parse(sessionStorage['ProBranch']));
        this.setModule(sessionStorage['ProModule']);
        this.setAppName(sessionStorage['appName']);
        this.setSystemModule(sessionStorage['ProSystemModule']);
        this.setDataBase(sessionStorage['ProDatabase']);
        this.setRemoteType(parseInt(sessionStorage['RemoteType']));
        this.setSocketPort(parseInt(sessionStorage['SocketPort']));
        this.setAppConfig(JSON.parse(sessionStorage['ProAppConfig']));
        this.setIdiom(sessionStorage['ProIdiom']);
        this.setRole(sessionStorage['ProRole']);
        this.setToken(JSON.parse(sessionStorage['TOKEN']));
        this.setErpAppConfig(JSON.parse(sessionStorage['ERPAPPCONFIG']));
        this.setUser(sessionStorage['ProUser']);
        this.setErpToken(JSON.parse(sessionStorage['ERPTOKEN']));
        this.setTheme(JSON.parse(localStorage.getItem('ProTheme')));
        this.handleThemeType();
    }
    /**
     * @description Retorna o nome do ambiente a partir da URL.
     * @returns string com o nome do ambiente
     */
    getLocationPathNameEnvironment() {
        return location.pathname.split('/')[2];
    }
    /**
     * @description Retorna objeto com informações gerais da sessão.
     * @returns ProSessionInfo
     */
    getSessionInfo() {
        return {
            proCompany: this.getCompany(),
            proBranch: this.getBranch(),
            proModule: this.getModule(),
            appName: this.getAppName(),
            proSystemModule: this.getSystemModule(),
            proDatabase: this.getDataBase(),
            remoteRype: this.getRemoteType(),
            socketPort: this.getSocketPort(),
            proAppConfig: this.getAppConfig(),
            proIdiom: this.getIdiom(),
            proRole: this.getRole(),
            token: this.getToken(),
            erpAppConfig: this.getErpAppConfig(),
            proUser: this.getUser(),
            erpToken: this.getErpToken()
        };
    }
    /**
     * @description Retorna as informações da empresa.
     * @returns ProCompany
     */
    getCompany() {
        const session = sessionStorage['ProCompany'];
        let company;
        if (session) {
            company = JSON.parse(session);
        }
        ;
        return this.proCompany ?? company;
    }
    /**
     * @description Retorna as informações da filial.
     * @returns ProBranch
     */
    getBranch() {
        const session = sessionStorage['ProBranch'];
        let branch;
        if (session) {
            branch = JSON.parse(session);
        }
        ;
        return this.proBranch ?? branch;
    }
    /**
     * @description Retorna o módulo.
     * @returns string
     */
    getModule() {
        return this.proModule ?? sessionStorage['ProModule'];
    }
    /**
     * @description Retorna as informações o nome do app.
     * @returns string
     */
    getAppName() {
        return this.appName ?? sessionStorage['appName'];
    }
    /**
     * @description Retorna as informações do módulo.
     * @returns ProSystemModules
     */
    getSystemModule() {
        const session = sessionStorage['ProSystemModule'];
        let systemModule;
        if (session) {
            systemModule = JSON.parse(session);
        }
        ;
        return this.proSystemModule ?? systemModule;
    }
    /**
     * @description Retorna a database.
     * @returns string
     */
    getDataBase() {
        return this.proDataBase ?? sessionStorage['ProDatabase'];
        ;
    }
    /**
     * @description Retorna tipo do remote.
     * @returns number
     */
    getRemoteType() {
        const session = sessionStorage['RemoteType'];
        let remoteType;
        if (session) {
            remoteType = parseInt(session);
        }
        ;
        return this.remoteType ?? remoteType;
    }
    /**
     * @description Retorna porta de conexão do socket.
     * @returns number
     */
    getSocketPort() {
        const session = sessionStorage['SocketPort'];
        let socketPort;
        if (session) {
            socketPort = parseInt(session);
        }
        ;
        return this.socketPort ?? socketPort;
    }
    /**
     * @description Retorna as informações do app.
     * @returns ProAppConfig
     */
    getAppConfig() {
        const session = sessionStorage['ProAppConfig'];
        let appConfig;
        if (session) {
            appConfig = JSON.parse(session);
        }
        ;
        return this.proAppConfig ?? appConfig;
    }
    /**
     * @description Retorna idioma.
     * @returns string
     */
    getIdiom() {
        return this.proIdiom ?? sessionStorage['ProIdiom'];
    }
    /**
     * @description Retorna as informações de papel de usuário.
     * @returns ProRole
     */
    getRole() {
        const session = sessionStorage['ProRole'];
        let role;
        if (session) {
            role = JSON.parse(session);
        }
        ;
        return this.proRole ?? role;
    }
    /**
     * @description Retorna as do token do usuário.
     * @returns ProAuthToken
     */
    getToken() {
        const session = sessionStorage['TOKEN'];
        let token;
        if (session) {
            token = JSON.parse(session);
        }
        ;
        return this.token ?? token;
    }
    /**
     * @description Retorna as informações do app.
     * @returns ProAppConfig
     */
    getErpAppConfig() {
        const session = sessionStorage['ERPAPPCONFIG'];
        let appConfig;
        if (session) {
            appConfig = JSON.parse(session);
        }
        ;
        return this.erpAppConfig ?? appConfig;
    }
    /**
     * @description Retorna as informações do usuário.
     * @returns ProUser
     */
    getUser() {
        const session = sessionStorage['ProUser'];
        let user;
        if (session) {
            user = JSON.parse(session);
        }
        ;
        return this.proUser ?? user;
    }
    /**
     * @description Retorna as informações do token do usuário.
     * @returns ProAuthToken
     */
    getErpToken() {
        const session = sessionStorage['ERPTOKEN'];
        let token;
        if (session) {
            token = JSON.parse(session);
        }
        ;
        return this.erpToken ?? token;
    }
    /**
    * @description Retorna o tema selecionado.
    * @returns ProThemeConfiguration
    */
    getTheme() {
        const session = localStorage.getItem('ProTheme');
        let theme;
        if (session) {
            theme = JSON.parse(session);
        }
        ;
        return this.theme ?? theme;
    }
    /**
     * @description Atribui as informações da empresa.
     */
    setCompany(company) {
        this.proCompany = company;
    }
    /**
     * @description Atribui as informações da filial.
     */
    setBranch(branch) {
        this.proBranch = branch;
    }
    /**
     * @description Atribui o módulo.
     */
    setModule(module) {
        this.proModule = module;
    }
    /**
     * @description Atribui o nome do app.
     */
    setAppName(appName) {
        this.appName = appName;
    }
    /**
     * @description Atribui as informações do módulo.
     */
    setSystemModule(systemModule) {
        if (systemModule) {
            this.proSystemModule = JSON.parse(systemModule);
        }
    }
    /**
     * @description Atribui a database.
     */
    setDataBase(dataBase) {
        this.proDataBase = dataBase;
    }
    /**
     * @description Atribui o tipo de remote.
     */
    setRemoteType(remoteType) {
        this.remoteType = remoteType;
    }
    /**
     * @description Atribui a porta de conexão do socket.
     */
    setSocketPort(socketPort) {
        this.socketPort = socketPort;
    }
    /**
     * @description Atribui as informações do app.
     */
    setAppConfig(appConfig) {
        this.proAppConfig = appConfig;
    }
    /**
     * @description Atribui o idioma.
     */
    setIdiom(idiom) {
        this.proIdiom = idiom;
    }
    /**
     * @description Atribui as informações do papel de usuário.
     */
    setRole(role) {
        if (role) {
            this.proRole = JSON.parse(role);
        }
    }
    /**
     * @description Atribui as informações dao token do usuário.
     */
    setToken(token) {
        this.token = token;
    }
    /**
     * @description Atribui as informações do app.
     */
    setErpAppConfig(appConfig) {
        this.erpAppConfig = appConfig;
    }
    /**
     * @description Atribui as informações do usuário.
     */
    setUser(user) {
        if (user) {
            this.proUser = JSON.parse(user);
        }
    }
    /**
     * @description Atribui as informações do token do usuário.
     */
    setErpToken(erpToken) {
        this.erpToken = erpToken;
    }
    /**
    * @description Atribui o tema utilizado
    */
    setTheme(theme) {
        this.theme = theme;
    }
    /**
     * @description Retorna a informação do programa inicial
     * @returns ProStartProgram
     */
    getProgramStart() {
        const session = sessionStorage['ProStartProgram'];
        let startProgram;
        if (session) {
            startProgram = JSON.parse(session);
        }
        ;
        return startProgram;
    }
    /**
    * @description Retorna a informação da home a ser utilizada.
    * Antiga home em advpl ou nova home em smart-ui
    * @returns ProNewHome
    */
    getNewHome() {
        const session = sessionStorage['ProNewHome'];
        let newHome;
        if (session) {
            newHome = JSON.parse(session);
        }
        ;
        return newHome;
    }
    /**
     * @description Lida com o tipo de Tema a ser aplicado
     * A partir do release 12.1.2610 o tema não será mais definido pelo ProtheusLibCore, podendo ser aplicado apenas se for utilizado na ProtheusLibThf.
     * @private
     */
    handleThemeType() {
        const storedValue = sessionStorage.getItem('ProThemeType') ?? 'poui';
        this.themeType = storedValue;
    }
    /**
     * @description Obter o tipo de tema que será aplicado. poui ou thf (A partir do release 12.1.2610)
     * A partir do release 12.1.2610 o tema não será mais definido pelo ProtheusLibCore, podendo ser aplicado apenas se for utilizado na ProtheusLibThf.
     * @returns { string } indica qual tema será utilizado
     */
    getThemeType() {
        if (this.themeType === undefined) {
            this.handleThemeType();
        }
        return this.themeType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionInfoService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionInfoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionInfoService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

const CACHE_KEY$4 = 'ProCompany';
class ProCompanyService {
    constructor(http, advplService, sessionInfoService) {
        this.http = http;
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
        this.url = '/api/framework/environment/v1/companies';
        this.useHTTP = true;
        this.EVENT_GET_LIST_ID = 'getCompaniesList';
        this.EVENT_SET_LIST_ID = 'setCompaniesList';
        this.EVENT_GET_ONE_ID = 'getCompanyInfo';
        this.EVENT_SET_ONE_ID = 'setCompanyInfo';
    }
    getListOfCompanies(CorporateName = '', page = 1, _pageSize = 100) {
        const pageSize = 100;
        if (this.useHTTP) {
            return this.getListOfCompaniesFromApi(CorporateName, page, pageSize);
        }
        return this.getListOfCompaniesFromAdvpl(CorporateName, page, pageSize);
    }
    /**
     * @description Retorna as empresas do usuário
     * @param corporateName string, nome da empresa
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @returns ProCompanyList, lista de empresas do usuário
     */
    getUserCompanies(corporateName = '', page = 1, pageSize = 10) {
        return this.getListOfCompaniesFromApi(corporateName, page, pageSize);
    }
    getListOfCompaniesFromApi(CorporateName, page, pageSize) {
        let params = new HttpParams()
            .append('page', page.toString())
            .append('pageSize', pageSize.toString()); // Alterado o tamanho da página para melhorar a experiência do usuário.
        if (CorporateName !== '') {
            params = params.append('CorporateName', CorporateName);
        }
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(this.url, {
            headers,
            params
        });
    }
    getListOfCompaniesFromAdvpl(CorporateName, page, pageSize) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        const stringContent = JSON.stringify({
            CorporateName,
            page,
            pageSize
        });
        const observableParameters = {
            sendInfo: {
                type: this.EVENT_GET_LIST_ID,
                content: stringContent
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_LIST_ID
        };
        const observableCallback = ({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `company ${CorporateName} could not be found`
                });
            }
            else {
                const companiesData = JSON.parse(protheusResponse);
                subscriber.next(companiesData);
            }
            subscriber.complete();
        };
        return this.advplService.buildObservable(observableCallback, observableParameters);
    }
    getCompany(company) {
        if (this.useHTTP) {
            return this.getCompanyFromApi(company);
        }
        return this.getCompanyFromAdvpl(company);
    }
    getCompanyFromApi(company) {
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(`${this.url}/${company}`, { headers });
    }
    getCompanyFromAdvpl(company) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `company ${company} could not be found`
                });
            }
            else {
                const companyData = JSON.parse(protheusResponse);
                subscriber.next(companyData);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_ONE_ID,
                content: company
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_ONE_ID
        });
    }
    /**
     * @description Retorna a empresa logada.
     * @returns ProCompany
     */
    get company() {
        const company = this.sessionInfoService.getCompany();
        if (company) {
            return company;
        }
        else {
            return { Code: '', CorporateName: '', InternalId: '' };
        }
    }
    set company(company) {
        sessionStorage[CACHE_KEY$4] = JSON.stringify(company);
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProCompanyService'
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProSessionInfoService }] });

const CACHE_KEY$3 = 'ProBranch';
class ProBranchService {
    constructor(http, advplService, proCompanyService, sessionInfoService) {
        this.http = http;
        this.advplService = advplService;
        this.proCompanyService = proCompanyService;
        this.sessionInfoService = sessionInfoService;
        this.url = '/api/framework/environment/v1/branches';
        this.useHTTP = true;
        this.EVENT_SET_LIST_ID = 'setBranchesList';
        this.EVENT_GET_LIST_ID = 'getBranchesList';
        this.EVENT_SET_ONE_ID = 'setBranchInfo';
        this.EVENT_GET_ONE_ID = 'getBranchInfo';
    }
    getListOfBranches(Description = '', page = 1, _pageSize = 100) {
        const pageSize = 100;
        if (this.useHTTP) {
            return this.getListOfBranchesFromApi(Description, page, pageSize);
        }
        return this.getListOfBranchesFromAdvpl(Description, page, pageSize);
    }
    /**
     * @description Retorna as filiais do usuário
     * @param description string, descrição da filial
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @returns ProBranchList, lista de filiais do usuário
     */
    getUserBranches(description = '', page = 1, pageSize = 10) {
        return this.getListOfBranchesFromApi(description, page, pageSize, false);
    }
    /**
     * @description Retorna as filiais do usuário via requisição http
     * @param description string, descrição da filial
     * @param page number, número da página
     * @param pageSize number, número de registros da página
     * @param isToFilterEnterpriseGroup boolean, indica se as filiais devem ser filtradas por empresa
     * @returns ProBranchList, lista de filiais do usuário
     */
    getListOfBranchesFromApi(Description, page, pageSize, isToFilterEnterpriseGroup = true) {
        let params = new HttpParams()
            .append('page', page.toString())
            .append('pageSize', pageSize.toString()); // Alterado o tamanho da página para melhorar a experiência do usuário.
        const company = this.proCompanyService.company;
        if (Description !== '') {
            params = params.append('Description', Description);
        }
        if (isToFilterEnterpriseGroup) {
            params = params.append('EnterpriseGroup', company.Code);
        }
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(this.url, {
            headers,
            params
        });
    }
    getListOfBranchesFromAdvpl(Description, page, pageSize) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        const company = this.proCompanyService.company;
        const stringContent = JSON.stringify({
            Description,
            EnterpriseGroup: company.Code,
            page,
            pageSize
        });
        const observableParams = {
            sendInfo: {
                type: this.EVENT_GET_LIST_ID,
                content: stringContent
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_LIST_ID
        };
        const observableCallback = ({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `branch ${Description} could not be found`
                });
            }
            else {
                const branchesData = JSON.parse(protheusResponse);
                subscriber.next(branchesData);
            }
            subscriber.complete();
        };
        return this.advplService.buildObservable(observableCallback, observableParams);
    }
    getBranch(branch, company = '') {
        if (this.useHTTP) {
            return this.getBranchFromApi(branch, company);
        }
        return this.getBranchFromAdvpl(branch, company);
    }
    getBranchFromApi(branch, company) {
        if (company === '') {
            company = this.proCompanyService.company.Code;
        }
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(`${this.url}/${company}|${branch}`, {
            headers
        });
    }
    getBranchFromAdvpl(branch, company) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        if (company === '') {
            company = this.proCompanyService.company.Code;
        }
        const stringContent = JSON.stringify({
            branch,
            company
        });
        const observableParams = {
            sendInfo: {
                type: this.EVENT_GET_ONE_ID,
                content: stringContent
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_ONE_ID
        };
        const observableCallback = ({ protheusResponse, subscriber }) => {
            let isOk = (protheusResponse.length > 0);
            const response = (isOk ? JSON.parse(protheusResponse) : {});
            isOk = (isOk && response && response.success);
            if (!isOk) {
                subscriber.error({
                    status: 400,
                    description: `branch ${branch} could not be found`
                });
            }
            else {
                const branchData = JSON.parse(response.payload);
                subscriber.next(branchData);
            }
            subscriber.complete();
        };
        return this.advplService.buildObservable(observableCallback, observableParams);
    }
    /**
     * @description Retorna a filial logada.
     * @returns ProBranch
     */
    get branch() {
        const branch = this.sessionInfoService.getBranch();
        if (branch) {
            return branch;
        }
        else {
            return { Code: '', EnterpriseGroup: '', Description: '' };
        }
    }
    set branch(branch) {
        sessionStorage[CACHE_KEY$3] = JSON.stringify(branch);
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProBranchService'
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProCompanyService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProCompanyService }, { type: ProSessionInfoService }] });

class ProBranchLookupService {
    constructor(proBranchService) {
        this.proBranchService = proBranchService;
        this.useHTTP = environment.useHTTP;
        this.changeServiceChannel();
    }
    getFilteredItems(params) {
        return this.proBranchService.getListOfBranches(params.filter, params.page, params.pageSize);
    }
    getObjectByValue(value) {
        return this.proBranchService.getBranch(value);
    }
    setBranch(branch) {
        this.proBranchService.branch = branch;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
        this.changeServiceChannel();
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    changeServiceChannel() {
        this.proBranchService.setChannelAsHTTP(this.useHTTP);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupService, deps: [{ token: ProBranchService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProBranchService }] });

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será branch_code
 */
class ProBranchLookupComponent {
    constructor(service) {
        this.service = service;
        this.branchSetted = new EventEmitter();
    }
    fieldFormat(value) {
        return value.Code;
    }
    /**
     * @description metodo para setar o foco no lookup de branch
     */
    setBranchFocus() {
        this.lookup.focus();
    }
    /*
    trecho para mostrar a consulta pelo atalho do F3
    mantido aqui para servir de base caso venha a ser necessário utilizar isso no futuro.
  
    // Registre o HostListener para a tecla F3
    @HostListener('document:keydown.F3', ['$event'])
    handleF3Key(event: KeyboardEvent): void {
      console.log("f3 branch out");
      if (this.lookup.inputEl.nativeElement == document.activeElement){
        console.log("f3 branch in");
        event.preventDefault(); // Isso impede que a ação padrão da tecla F3 (geralmente abrir a busca) seja executada
        this.lookup.openLookup();
      }
    } */
    setBranch(branch) {
        if (Object.keys(branch).length > 0) {
            this.parent.patchValue({ branch_description: branch.Description });
            this.service.setBranch(branch);
            this.branchSetted.emit(branch);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupComponent, deps: [{ token: ProBranchLookupService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProBranchLookupComponent, isStandalone: false, selector: "pro-branch-lookup", inputs: { parent: "parent", pLabel: ["p-label", "pLabel"], pHint: ["p-hint", "pHint"], columns: ["pro-columns", "columns"] }, outputs: { branchSetted: "branchSetted" }, viewQueries: [{ propertyName: "lookup", first: true, predicate: PoLookupComponent, descendants: true, static: true }], ngImport: i0, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"branch_code\"\r\n    formControlName=\"branch_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setBranch($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"branch_description\"\r\n    formControlName=\"branch_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"], dependencies: [{ kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.PoInputComponent, selector: "po-input" }, { kind: "component", type: i3.PoLookupComponent, selector: "po-lookup" }, { kind: "directive", type: i3.PoTooltipDirective, selector: "[p-tooltip]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-branch-lookup', standalone: false, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"branch_code\"\r\n    formControlName=\"branch_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setBranch($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"branch_description\"\r\n    formControlName=\"branch_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"] }]
        }], ctorParameters: () => [{ type: ProBranchLookupService }], propDecorators: { parent: [{
                type: Input
            }], branchSetted: [{
                type: Output
            }], pLabel: [{
                type: Input,
                args: ['p-label']
            }], pHint: [{
                type: Input,
                args: ['p-hint']
            }], columns: [{
                type: Input,
                args: ['pro-columns']
            }], lookup: [{
                type: ViewChild,
                args: [PoLookupComponent, { static: true }]
            }] } });

class ProBranchLookupModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupModule, declarations: [ProBranchLookupComponent], imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule], exports: [ProBranchLookupComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupModule, imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBranchLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule],
                    declarations: [ProBranchLookupComponent],
                    exports: [ProBranchLookupComponent]
                }]
        }] });

class ProCompanyLookupService {
    constructor(proCompanyService) {
        this.proCompanyService = proCompanyService;
        this.useHTTP = environment.useHTTP;
        this.changeServiceChannel();
    }
    getFilteredItems(params) {
        return this.proCompanyService.getListOfCompanies(params.filter, params.page, params.pageSize);
    }
    getObjectByValue(value) {
        return this.proCompanyService.getCompany(value);
    }
    setCompany(company) {
        this.proCompanyService.company = company;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
        this.changeServiceChannel();
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    changeServiceChannel() {
        this.proCompanyService.setChannelAsHTTP(this.useHTTP);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupService, deps: [{ token: ProCompanyService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProCompanyService }] });

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será company_code
 */
class ProCompanyLookupComponent {
    /**
     * @description Construtor da classe
     * @param service Serviço de Lookup do grupo de empresas
     */
    constructor(service) {
        this.service = service;
        this.companySetted = new EventEmitter();
        this.branchSetted = new EventEmitter();
        this.started = false;
        this.firstPass = true;
    }
    fieldFormat(value) {
        return value.Code;
    }
    setCompanyFocus() {
        this.lookup.focus();
    }
    setStarted(started) {
        this.started = started;
    }
    /*
    trecho para mostrar a consulta pelo atalho do F3
    mantido aqui para servir de base caso venha a ser necessário utilizar isso no futuro.
  
    // Registre o HostListener para a tecla F3
    @HostListener('document:keydown.F3', ['$event'])
    handleF3Key(event: KeyboardEvent): void {
      console.log("f3 out");
      if (this.lookup.inputEl.nativeElement == document.activeElement){
        console.log("f3 in");
        event.preventDefault(); // Isso impede que a ação padrão da tecla F3 (geralmente abrir a busca) seja executada
        this.lookup.openLookup();
      }
    } */
    /**
     * @description Efetua o set do grupo de empresas para o serviço, atualiza o parent e disparada o evento
     * @param company Objeto do grupo de empresas
     */
    setCompany(company) {
        if (Object.keys(company).length > 0) {
            this.parent.patchValue({
                company_description: company.CorporateName,
                branch_code: '',
                branch_description: '',
                companyLayout: company.Layout
            });
            this.service.setCompany(company);
            this.companySetted.emit(company);
            const hasBranch = !!company.FirstBranchCode && !!company.FirstBranchDescription;
            if (this.started && hasBranch && !this.firstPass) {
                this.parent.patchValue({
                    branch_code: company.FirstBranchCode,
                    branch_description: company.FirstBranchDescription
                });
                setTimeout(() => {
                    // evento para forçar o foco no lookup de branch
                    // por algum motivo obscuro o patchValue no branch retira o foco do elemento
                    this.branchSetted.emit();
                }, 200);
            }
            if (this.firstPass) {
                this.firstPass = false;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupComponent, deps: [{ token: ProCompanyLookupService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProCompanyLookupComponent, isStandalone: false, selector: "pro-company-lookup", inputs: { parent: "parent", pLabel: ["p-label", "pLabel"], pHint: ["p-hint", "pHint"], columns: ["pro-columns", "columns"] }, outputs: { companySetted: "companySetted", branchSetted: "branchSetted" }, viewQueries: [{ propertyName: "lookup", first: true, predicate: PoLookupComponent, descendants: true, static: true }], ngImport: i0, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"company_code\"\r\n    formControlName=\"company_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setCompany($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"company_description\"\r\n    formControlName=\"company_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"], dependencies: [{ kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.PoInputComponent, selector: "po-input" }, { kind: "component", type: i3.PoLookupComponent, selector: "po-lookup" }, { kind: "directive", type: i3.PoTooltipDirective, selector: "[p-tooltip]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-company-lookup', standalone: false, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"company_code\"\r\n    formControlName=\"company_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setCompany($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"company_description\"\r\n    formControlName=\"company_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"] }]
        }], ctorParameters: () => [{ type: ProCompanyLookupService }], propDecorators: { parent: [{
                type: Input
            }], companySetted: [{
                type: Output
            }], branchSetted: [{
                type: Output
            }], pLabel: [{
                type: Input,
                args: ['p-label']
            }], pHint: [{
                type: Input,
                args: ['p-hint']
            }], columns: [{
                type: Input,
                args: ['pro-columns']
            }], lookup: [{
                type: ViewChild,
                args: [PoLookupComponent, { static: true }]
            }] } });

class ProCompanyLookupModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupModule, declarations: [ProCompanyLookupComponent], imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule], exports: [ProCompanyLookupComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupModule, imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProCompanyLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule],
                    declarations: [ProCompanyLookupComponent],
                    exports: [ProCompanyLookupComponent]
                }]
        }] });

const CACHE_KEY$2 = 'ProRole';
class ProRoleService {
    constructor(advplService, sessionInfoService) {
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
    }
    getListofRoles(description = '', page = 1, pageSize = 10) {
        pageSize = 100; // Alterado o tamanho da página para melhorar a experiência do usuário.
        if (this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse.length === 0) {
                    subscriber.next({
                        hasNext: false,
                        items: []
                    });
                }
                else {
                    const roleList = JSON.parse(protheusResponse)
                        .map((role) => {
                        return {
                            Code: role[0],
                            Description: role[1]
                        };
                    })
                        .filter((role) => {
                        return role.Description.includes(description);
                    });
                    subscriber.next({
                        hasNext: roleList.length > page * pageSize,
                        items: roleList.slice((page - 1) * pageSize, page * pageSize)
                    });
                }
                subscriber.complete();
            }, {
                autoDestruct: true,
                receiveId: 'setRoleList',
                sendInfo: { type: 'getRoleList' }
            });
        }
        else {
            return new Observable(subscriber => {
                subscriber.next({
                    hasNext: false,
                    items: []
                });
                subscriber.complete();
            });
        }
    }
    getRoleByCode(roleCode) {
        if (this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                const role = JSON.parse(protheusResponse);
                const response = { Code: role[0], Description: role[1] };
                subscriber.next(response);
                subscriber.complete();
            }, {
                autoDestruct: true,
                receiveId: 'setRoleItem',
                sendInfo: { type: 'getRoleItem', content: roleCode }
            });
        }
        else {
            return new Observable(subscriber => {
                subscriber.next({ Code: '', Description: '' });
                subscriber.complete();
            });
        }
    }
    /**
     * @description Retorna as informações de papel de trabalho do usuário.
     */
    get role() {
        const role = this.sessionInfoService.getRole();
        if (role) {
            return role;
        }
        else {
            return { Code: '', Description: '' };
        }
    }
    set role(role) {
        sessionStorage[CACHE_KEY$2] = JSON.stringify(role);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleService, deps: [{ token: ProJsToAdvplService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProJsToAdvplService }, { type: ProSessionInfoService }] });

class ProRoleLookupService {
    constructor(proRoleService) {
        this.proRoleService = proRoleService;
    }
    getFilteredItems(params) {
        return this.proRoleService.getListofRoles(params.filter, params.page, params.pageSize);
    }
    getObjectByValue(code) {
        return this.proRoleService.getRoleByCode(code);
    }
    setRole(role) {
        this.proRoleService.role = role;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupService, deps: [{ token: ProRoleService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProRoleService }] });

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será role_code
 */
class ProRoleLookupComponent {
    constructor(service) {
        this.service = service;
        this.roleSetted = new EventEmitter();
    }
    fieldFormat(value) {
        return value.Code;
    }
    setRole(role) {
        this.parent.patchValue({ role_description: role.Description });
        this.service.setRole(role);
        this.roleSetted.emit(role);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupComponent, deps: [{ token: ProRoleLookupService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProRoleLookupComponent, isStandalone: false, selector: "pro-role-lookup", inputs: { parent: "parent", pLabel: ["p-label", "pLabel"], pHint: ["p-hint", "pHint"], columns: ["pro-columns", "columns"], pDisabled: ["p-disabled", "pDisabled"] }, outputs: { roleSetted: "roleSetted" }, ngImport: i0, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"role_code\"\r\n    formControlName=\"role_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setRole($event)\"\r\n    [p-disabled]=\"pDisabled\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"role_description\"\r\n    formControlName=\"role_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"], dependencies: [{ kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.PoInputComponent, selector: "po-input" }, { kind: "component", type: i3.PoLookupComponent, selector: "po-lookup" }, { kind: "directive", type: i3.PoTooltipDirective, selector: "[p-tooltip]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-role-lookup', standalone: false, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"role_code\"\r\n    formControlName=\"role_code\"\r\n    p-field-label=\"Code\"\r\n    p-field-value=\"Code\"\r\n    [p-label]=\"pLabel\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setRole($event)\"\r\n    [p-disabled]=\"pDisabled\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"role_description\"\r\n    formControlName=\"role_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"] }]
        }], ctorParameters: () => [{ type: ProRoleLookupService }], propDecorators: { parent: [{
                type: Input
            }], roleSetted: [{
                type: Output
            }], pLabel: [{
                type: Input,
                args: ['p-label']
            }], pHint: [{
                type: Input,
                args: ['p-hint']
            }], columns: [{
                type: Input,
                args: ['pro-columns']
            }], pDisabled: [{
                type: Input,
                args: ['p-disabled']
            }] } });

class ProRoleLookupModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupModule, declarations: [ProRoleLookupComponent], imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule], exports: [ProRoleLookupComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupModule, imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProRoleLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule],
                    declarations: [ProRoleLookupComponent],
                    exports: [ProRoleLookupComponent]
                }]
        }] });

const CACHE_KEY$1 = 'ProSystemModule';
class ProSystemModuleService {
    constructor(http, advplService, sessionInfoService) {
        this.http = http;
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
        this.url = '/api/framework/v1/systemModules';
        this.useHTTP = true;
        this.EVENT_SET_LIST = 'setModulesList';
        this.EVENT_GET_LIST = 'getModulesList';
        this.EVENT_SET_ONE = 'setModuleInfo';
        this.EVENT_GET_ONE = 'getModuleInfo';
    }
    getListOfSystemModules(description = '', page = 1, _pageSize = 10) {
        const pageSize = 100;
        if (this.useHTTP) {
            return this.getListOfSystemModulesFromApi(description, page, pageSize);
        }
        return this.getListOfSystemModulesFromAdvpl(description, page, pageSize);
    }
    getListOfSystemModulesFromApi(description, page, pageSize) {
        let params = new HttpParams()
            .append('page', page.toString())
            .append('pageSize', pageSize.toString()); // Alterado o tamanho da página para melhorar a experiência do usuário.
        if (description !== '') {
            params = params.append('description', description);
        }
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(this.url, { headers, params });
    }
    getListOfSystemModulesFromAdvpl(description, page, pageSize) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        const stringContent = JSON.stringify({
            description,
            page,
            pageSize,
        });
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `module ${description} could not be found`
                });
            }
            else {
                const modulesData = JSON.parse(protheusResponse);
                subscriber.next(modulesData);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_LIST,
                content: stringContent
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_LIST
        });
    }
    getSystemModule(systemModuleId) {
        if (this.useHTTP) {
            return this.getSystemModuleFromAPI(systemModuleId);
        }
        return this.getSystemModuleFromAdvpl(systemModuleId);
    }
    getSystemModuleFromAPI(systemModuleId) {
        const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
        return this.http.get(`${this.url}/${systemModuleId}`, {
            headers
        });
    }
    getSystemModuleFromAdvpl(systemModuleId) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `module ${systemModuleId} could not be found`
                });
            }
            else {
                const moduleData = JSON.parse(protheusResponse);
                subscriber.next(moduleData);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_ONE,
                content: systemModuleId
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_ONE
        });
    }
    /**
     * @description Retorna as informações do módulo logado.
     * @returns ProSystemModules
     */
    get systemModule() {
        const systemModule = this.sessionInfoService.getSystemModule();
        if (systemModule) {
            return systemModule;
        }
        else {
            return { id: '', name: '', description: '' };
        }
    }
    set systemModule(systemModule) {
        sessionStorage[CACHE_KEY$1] = JSON.stringify(systemModule);
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProSystemModuleService'
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProSessionInfoService }] });

class ProSystemModuleLookupService {
    constructor(proSystemModuleService) {
        this.proSystemModuleService = proSystemModuleService;
        this.useHTTP = environment.useHTTP;
        this.changeServiceChannel();
    }
    getFilteredItems(params) {
        return this.proSystemModuleService.getListOfSystemModules(params.filter, params.page, params.pageSize);
    }
    getObjectByValue(moduleId) {
        this.setSystemModule({ id: moduleId });
        return this.proSystemModuleService.getSystemModule(moduleId);
    }
    setSystemModule(systemModule) {
        this.proSystemModuleService.systemModule = systemModule;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
        this.changeServiceChannel();
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    changeServiceChannel() {
        this.proSystemModuleService.setChannelAsHTTP(this.useHTTP);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupService, deps: [{ token: ProSystemModuleService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProSystemModuleService }] });

/**
 * @description
 *
 * Componente que disponibiliza um campo para lookup para grupo de empresa.
 * O nome do field no formulário será company_code
 */
class ProSystemModuleLookupComponent {
    constructor(service) {
        this.service = service;
        this.systeModuleSetted = new EventEmitter();
    }
    fieldFormat(value) {
        return `${value.id}`;
    }
    setSystemModule(systemModule) {
        this.parent.patchValue({
            environment_description: systemModule.description
        });
        this.service.setSystemModule(systemModule);
        this.systeModuleSetted.emit(systemModule);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupComponent, deps: [{ token: ProSystemModuleLookupService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProSystemModuleLookupComponent, isStandalone: false, selector: "pro-system-module-lookup", inputs: { parent: "parent", pLabel: ["p-label", "pLabel"], pDisabled: ["p-disabled", "pDisabled"], pHint: ["p-hint", "pHint"], columns: ["pro-columns", "columns"] }, outputs: { systeModuleSetted: "systeModuleSetted" }, ngImport: i0, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"environment_code\"\r\n    formControlName=\"environment_code\"\r\n    p-field-label=\"id\"\r\n    p-field-value=\"id\"\r\n    [p-label]=\"pLabel\"\r\n    [p-disabled]=\"pDisabled\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setSystemModule($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"environment_description\"\r\n    formControlName=\"environment_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"], dependencies: [{ kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: i3.PoInputComponent, selector: "po-input" }, { kind: "component", type: i3.PoLookupComponent, selector: "po-lookup" }, { kind: "directive", type: i3.PoTooltipDirective, selector: "[p-tooltip]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-system-module-lookup', standalone: false, template: "<div [formGroup]=\"parent\" class=\"po-page-login-info-container\">\r\n  <po-lookup\r\n    class=\"po-md-6\"\r\n    name=\"environment_code\"\r\n    formControlName=\"environment_code\"\r\n    p-field-label=\"id\"\r\n    p-field-value=\"id\"\r\n    [p-label]=\"pLabel\"\r\n    [p-disabled]=\"pDisabled\"\r\n    [p-columns]=\"columns\"\r\n    [p-field-format]=\"fieldFormat\"\r\n    [p-filter-service]=\"service\"\r\n    (p-selected)=\"setSystemModule($event)\"\r\n  >\r\n  </po-lookup>\r\n  <po-input\r\n    class=\"po-md-6\"\r\n    name=\"environment_description\"\r\n    formControlName=\"environment_description\"\r\n    p-label=\"&nbsp;\"\r\n    p-disabled=\"true\"\r\n  >\r\n  </po-input>\r\n  <div class=\"po-page-login-info-icon-container tooltip-bigscreen-adjust\">\r\n    <span\r\n      class=\"po-icon po-field-icon po-icon-info\"\r\n      [p-tooltip]=\"pHint\"\r\n      p-tooltip-position=\"right\"\r\n    >\r\n    </span>\r\n  </div>\r\n</div>\r\n", styles: ["@media(min-width:1367px){.tooltip-bigscreen-adjust{padding-left:0}}\n"] }]
        }], ctorParameters: () => [{ type: ProSystemModuleLookupService }], propDecorators: { parent: [{
                type: Input
            }], systeModuleSetted: [{
                type: Output
            }], pLabel: [{
                type: Input,
                args: ['p-label']
            }], pDisabled: [{
                type: Input,
                args: ['p-disabled']
            }], pHint: [{
                type: Input,
                args: ['p-hint']
            }], columns: [{
                type: Input,
                args: ['pro-columns']
            }] } });

class ProSystemModuleLookupModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupModule, declarations: [ProSystemModuleLookupComponent], imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule], exports: [ProSystemModuleLookupComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupModule, imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModuleLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, PoFieldModule, PoTooltipModule],
                    declarations: [ProSystemModuleLookupComponent],
                    exports: [ProSystemModuleLookupComponent]
                }]
        }] });

class ProFieldsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProFieldsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProFieldsModule, imports: [ProCompanyLookupModule,
            ProBranchLookupModule,
            ProRoleLookupModule,
            ProSystemModuleLookupModule], exports: [ProCompanyLookupModule,
            ProBranchLookupModule,
            ProRoleLookupModule,
            ProSystemModuleLookupModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProFieldsModule, imports: [ProCompanyLookupModule,
            ProBranchLookupModule,
            ProRoleLookupModule,
            ProSystemModuleLookupModule, ProCompanyLookupModule,
            ProBranchLookupModule,
            ProRoleLookupModule,
            ProSystemModuleLookupModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProFieldsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ProCompanyLookupModule,
                        ProBranchLookupModule,
                        ProRoleLookupModule,
                        ProSystemModuleLookupModule
                    ],
                    exports: [
                        ProCompanyLookupModule,
                        ProBranchLookupModule,
                        ProRoleLookupModule,
                        ProSystemModuleLookupModule
                    ]
                }]
        }] });

class ProHomeComponent {
    constructor() { }
    ngOnInit() {
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProHomeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProHomeComponent, isStandalone: false, selector: "pro-home", ngImport: i0, template: "<p>\r\n  home works!\r\n</p>\r\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProHomeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-home', standalone: false, template: "<p>\r\n  home works!\r\n</p>\r\n" }]
        }], ctorParameters: () => [] });

class ProHomeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProHomeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProHomeModule, declarations: [ProHomeComponent], imports: [CommonModule], exports: [ProHomeComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProHomeModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProHomeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [ProHomeComponent],
                    exports: [ProHomeComponent]
                }]
        }] });

const CACHE_KEY_USER = 'ProUser';
const USER_ENDPOINT = '/api/framework/v1/users';
/**
 * Essa classe corresponde ao serviço de busca de informações do usuário
 */
class ProUserInfoService {
    constructor(http, advplService) {
        this.http = http;
        this.advplService = advplService;
        this.useHTTP = true;
        this.EVENT_GET_ID = 'getUserInfo';
        this.EVENT_SET_ID = 'setUserInfo';
        this.URL_PSWRET = '/api/framework/v1/basicProtheusServices/pswret/';
    }
    /**
     * @description Retorna informações do usuário
     * @param userId string, id do usuário
     * @param isUseHttp boolean, indica se utiliza requisição http
     * @returns Observable de ProUserInfo, dados do usuário
     */
    get(userId, isUseHttp = false) {
        if (this.useHTTP || isUseHttp) {
            return this.getFromApi(userId);
        }
        return this.getFromAdvpl(userId);
    }
    getFromApi(userId) {
        const headers = new HttpHeaders()
            .append('X-Totvs-No-Error', 'true')
            .append('Accept', 'application/json; charset=utf-8');
        return this.http.get(`${USER_ENDPOINT}/${userId}`, { headers }).pipe(map((userInfo) => {
            userInfo.complete_name = userInfo.userName;
            return userInfo;
        }), tap((userInfo) => {
            sessionStorage[CACHE_KEY_USER] = JSON.stringify(userInfo);
        }));
    }
    getFromAdvpl(userId) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        const randomEventId = this.advplService.generateEventId();
        const observableParams = {
            sendInfo: {
                type: `${this.EVENT_GET_ID}#id#${randomEventId}`,
                content: userId
            },
            autoDestruct: true,
            receiveId: `${this.EVENT_SET_ID}#id#${randomEventId}`
        };
        const observableCallback = ({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `user ${userId} could not be found`
                });
            }
            else {
                const userInfo = JSON.parse(protheusResponse);
                userInfo.complete_name = userInfo.userName;
                sessionStorage[CACHE_KEY_USER] = JSON.stringify(protheusResponse);
                subscriber.next(userInfo);
            }
            subscriber.complete();
        };
        return this.advplService.buildObservable(observableCallback, observableParams);
    }
    removeFromStorage() {
        sessionStorage.removeItem(CACHE_KEY_USER);
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProUserInfoService'
                /**
                 * Esse erro está sendo emitido ao utilizar o app com a otimização ligada e a opção de SSO.
                 * O que foi percebido é que em determinada situação a conexão AdvPL
                 * não fica disponível quando o serviço é solicitado. Foram feitos testes adicionando
                 * múltiplas tentativas mas sem sucesso. Utilizando a opção de canal HTTP funciona corretamente,
                 * porém interfere na criação de dicionários do lado AdvPL, o que torna a opção inviável.
                 */
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    /**
     * efetua um get na api referente a função PswRet do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @returns Observable com o retorno da api
     */
    pswRet() {
        return this.http.get(this.URL_PSWRET);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserInfoService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserInfoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserInfoService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }] });

const HAS_SECURITY = '/api/framework/mfa/hasSecret';
const VALID_TOKEN = '/api/framework/mfa/tok';
const GET_QRCODE = '/api/framework/mfa/TOTPURI';
class ProMfaService {
    constructor(http, advplService) {
        this.http = http;
        this.advplService = advplService;
        this.isHTTP = true;
        this.hasMFA = false;
        this.isValidToken = false;
        this.isSigaCfg = false;
    }
    /**
     * @description Atribui valor para hasMFA.
     * @param hasMFA boolean, indica se o usuário possui MFA habilitado.
     */
    setHasMFA(hasMFA) {
        this.hasMFA = hasMFA;
    }
    /**
     * @description Retorna o atributo hasMFA.
     * @returns boolean, indica se o usuário possui MFA habilitado.
     */
    getHasMFA() {
        return this.hasMFA;
    }
    /**
     * @description Atribui valor para isValidToken.
     * @param isValid boolean, indica se o token MFA é válido.
     */
    setIsValidToken(isValid) {
        this.isValidToken = isValid;
    }
    /**
     * @description Retorna o atributo isValidToken.
     * @returns boolean, indica se o token MFA é válido.
     */
    getIsValidToken() {
        return this.isValidToken;
    }
    /**
     * @description Atribui valor para isSigaCfg.
     * @param isCfg boolean, indica se o login está sendo feito no módulo SIGACFG.
     */
    setIsSigaCfg(isCfg) {
        this.isSigaCfg = isCfg;
    }
    /**
     * @description Retorna o atributo isSigaCfg.
     * @returns boolean, indica se o login está sendo feito no módulo SIGACFG.
     */
    getIsSigaCfg() {
        return this.isSigaCfg;
    }
    /**
     * @description
     * Serviço que verifica se o usuário já possui MFA registrado.
     * @return Json da interface ProMfaHasSecretInterface
     */
    userHasMfaSecurity() {
        if (!this.isHTTP && this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (this.validResponse(protheusResponse, subscriber)) {
                    const hasSecret = JSON.parse(protheusResponse);
                    subscriber.next(hasSecret);
                }
                subscriber.complete();
            }, this.getJsToAdvplSend('hasSecret', '', 'hasSecret'));
        }
        else {
            return this.http.get(HAS_SECURITY);
        }
    }
    /**
     * @description
     * Serviço que retorna os dados para geração do Qr Code
     * @return Json da interface ProMfaQrCodeInterface
     */
    getMfaQrCode() {
        if (!this.isHTTP && this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (this.validResponse(protheusResponse, subscriber)) {
                    const mfaQrCode = JSON.parse(protheusResponse);
                    subscriber.next(mfaQrCode);
                }
                subscriber.complete();
            }, this.getJsToAdvplSend('mfaQrCode', '', 'mfaQrCode'));
        }
        else {
            return this.http.get(GET_QRCODE);
        }
    }
    /**
     * @description
     * Serviço que valida o token informado.
     * @param tokenMfa, token informado pelo usuário
     * @return Json da interface ProMfaValidCodeInterface
     */
    getMfaValid(tokenMfa) {
        if (!this.isHTTP && this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (this.validResponse(protheusResponse, subscriber)) {
                    const mfaValidCode = JSON.parse(protheusResponse);
                    subscriber.next(mfaValidCode);
                }
                subscriber.complete();
            }, this.getJsToAdvplSend('mfaValidCode', tokenMfa, 'mfaValidCode'));
        }
        else {
            let parameters = new HttpParams().append('token', tokenMfa);
            return this.http.get(VALID_TOKEN, {
                params: parameters,
            });
        }
    }
    /**
     * @description Valida se está no módulo SIGACFG.
     * @return Observable boolean
     */
    isSIGACFG() {
        if (!this.isHTTP || this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (this.validResponse(protheusResponse, subscriber)) {
                    const mfaIsConfig = JSON.parse(protheusResponse);
                    subscriber.next(mfaIsConfig.isConfig);
                }
                subscriber.complete();
            }, this.getJsToAdvplSend('isConfig', '', 'isConfig'));
        }
        else {
            //Apenas para situações de debug em navegador
            return of(false);
        }
    }
    /**
     * @description Metodo apenas para apoio nos testes automatizados
     * @return Informa se se o Http esta ativo
     */
    isChannelHTTP() {
        return this.isHTTP;
    }
    /**
     * @description Muda o parametro de environment para Http
     * @param value, indica o valor a ser atribuido
     */
    setChannelAsHTTP(value) {
        this.isHTTP = value;
    }
    /**
     * @description Validação do response e disparo do evento de erro
     * @param protheusResponse, Response do JsToAdvpl
     * @param subscriber, Subscriber do JsToAdvpl
     * @return Indica se a resposta foi validada
     */
    validResponse(protheusResponse, subscriber) {
        const isValid = !(protheusResponse.length === 0);
        if (!isValid) {
            subscriber.error({ status: 401 });
        }
        return isValid;
    }
    /**
     * @description Retorna o objeto sender
     * @param type, Tipo do Sender
     * @param content, Conteudo a ser enviado
     * @param receiveId, Id do evento
     * @param autoDestruct, Indica se realiza a eliminação automatica do objeto
     * @return Objeto Sender
     */
    getJsToAdvplSend(type, content, receiveId, autoDestruct) {
        const sendInfo = {
            sendInfo: {
                type: type,
                content: content,
            },
            autoDestruct: autoDestruct ?? true,
            receiveId: receiveId,
        };
        return sendInfo;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMfaService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMfaService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMfaService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }] });

const CACHE_KEY_TOKEN = 'ERPTOKEN';
const TOKEN_ENDPOINT = '/api/oauth2/v1/token';
class ProAuthService {
    constructor(http, proUserInfoService, advplService, sessionInfoService, proMfaService) {
        this.http = http;
        this.proUserInfoService = proUserInfoService;
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
        this.proMfaService = proMfaService;
        this.proUserInfoService.setChannelAsHTTP(environment.useHTTP);
    }
    requestLoginDefaults() {
        if (!valueIsNull(this.advplService.getWebChannel())) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse.length === 0) {
                    subscriber.next({
                        username: '',
                        username_when: true,
                        password: '',
                        remember_user: false,
                        show_remember_user: false
                    });
                }
                else {
                    const startKeys = JSON.parse(protheusResponse);
                    subscriber.next(startKeys);
                }
                subscriber.complete();
            }, {
                sendInfo: {
                    type: 'getLoginStart'
                },
                autoDestruct: true
            });
        }
        else {
            return new Observable(subscriber => {
                subscriber.next({
                    username: '',
                    username_when: true,
                    password: '',
                    remember_user: false,
                    show_remember_user: false
                });
                subscriber.complete();
            });
        }
    }
    requestToken(user) {
        if (this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse.length === 0) {
                    subscriber.error({ status: 401 });
                }
                else {
                    const tokenInside = JSON.parse(protheusResponse);
                    subscriber.next(tokenInside);
                }
                subscriber.complete();
            }, {
                sendInfo: {
                    type: 'loginInside',
                    content: btoa(JSON.stringify({ "usr": user.username, "psw": user.password, "remember": user.remember_user }))
                },
                autoDestruct: true,
                receiveId: 'setToken'
            });
        }
        else {
            const headers = new HttpHeaders()
                .append('X-Totvs-No-Error', 'true')
                .set('grant_type', 'password')
                .set('username', user.username)
                .set('password', user.password);
            return this.http.post(TOKEN_ENDPOINT, {}, { headers });
        }
    }
    refreshToken(refresh_token) {
        const params = new HttpParams()
            .set('grant_type', 'refresh_token')
            .set('refresh_token', refresh_token);
        return this.http.post(TOKEN_ENDPOINT, {}, { params });
    }
    login(user) {
        const loginSubject = new Subject();
        this.requestToken(user).subscribe({
            next: (token) => {
                const userId = this.getTokenPayload(token.access_token).userid;
                this.saveToken(token);
                this.saveUserInfo(userId);
                loginSubject.next(token);
            },
            error: (error) => {
                loginSubject.error(error);
            }
        });
        return loginSubject.asObservable();
    }
    passwordRecovery(user) {
        this.advplService.jsToAdvpl('openPasswordRecovery', user);
    }
    saveToken(token) {
        this.sessionInfoService.setErpToken(token);
        sessionStorage[CACHE_KEY_TOKEN] = JSON.stringify(token);
    }
    saveUserInfo(userId) {
        this.proUserInfoService.get(userId).subscribe((userInfo) => {
            this._ProUserInfo = userInfo;
        });
    }
    isTokenValid(now = Date.now()) {
        const date_now = Math.round(now / 1000.0);
        const payload = this.getTokenPayload(this.token.access_token);
        // Faltando 10% do tempo de expiração já peço a renovação
        return payload.exp - date_now > this.token.expires_in / 10;
    }
    async updateToken() {
        const token = await this.refreshToken(this.token.refresh_token).toPromise();
        this.saveToken(token);
        this._token = token;
    }
    get userInfo() {
        return this._ProUserInfo;
    }
    /**
     * @description Retorna o token de autenticação gerado.
     */
    get token() {
        const token_string = this.sessionInfoService.getErpToken();
        if (token_string) {
            this._token = token_string;
        }
        return this._token;
    }
    get isUserAuthenticate() {
        return !valueIsNull(this.token) && !valueIsNull(this.token.access_token);
    }
    /**
     * @description Realiza a limpeza do token ao realizar o logout.
     */
    logout() {
        this.proMfaService.setIsValidToken(false);
        this.sessionInfoService.setErpToken(undefined);
        sessionStorage.removeItem(CACHE_KEY_TOKEN);
        this.proUserInfoService.removeFromStorage();
    }
    getTokenPayload(token = this.token.access_token) {
        return JSON.parse(atob(token.split('.')[1]));
    }
    get userId() {
        return this.getTokenPayload().userid;
    }
    /**
     * @description
     * Exibir a mensagem de confirmação de Autenticação.
     */
    showLoginMessage() {
        if (this.advplService.protheusConnected()) {
            this.advplService.jsToAdvpl('showLoginMessage', '');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthService, deps: [{ token: i1.HttpClient }, { token: ProUserInfoService }, { token: ProJsToAdvplService }, { token: ProSessionInfoService }, { token: ProMfaService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProUserInfoService }, { type: ProJsToAdvplService }, { type: ProSessionInfoService }, { type: ProMfaService }] });

class ProLoginDefaultsResolver {
    constructor(proAuthService) {
        this.proAuthService = proAuthService;
    }
    resolve(_route, _state) {
        return this.proAuthService.requestLoginDefaults();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginDefaultsResolver, deps: [{ token: ProAuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginDefaultsResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginDefaultsResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProAuthService }] });

class ProMessageService {
    constructor(poNotificationService, advplService) {
        this.poNotificationService = poNotificationService;
        this.advplService = advplService;
        if (this.advplService.protheusConnected()) {
            this.advplService.buildListener('showMessage', ({ protheusResponse }) => {
                if (protheusResponse.length === 0) {
                    return;
                }
                else {
                    const messageObject = JSON.parse(protheusResponse);
                    this.showMessage(messageObject.message, messageObject.type);
                }
            });
        }
    }
    // Método criado para evitar que sejam exibidas duas mensagens para o usuário (uma do Angular e outra do Protheus)
    showOneMessage(message, type = 2) {
        if (!this.advplService.protheusConnected()) {
            this.showMessage(message, type);
        }
    }
    /**
     * @description Exibe uma mensagem via notificação
     * @param message Mensagem
     * @param type Tipo da mensage, como erro, informação etc
     */
    showMessage(message, type = 2) {
        const notification = {
            message,
            orientation: PoToasterOrientation.Top
        };
        if (type === 1) {
            this.poNotificationService.warning(notification);
        }
        if (type === 2) {
            this.poNotificationService.error(notification);
        }
        if (type === 3) {
            this.poNotificationService.information(notification);
        }
    }
    /**
     * @description Executa a mudança do idioma no Protheus via Observable do advplService
     * @param language idioma escolhido via po-select
     * @returns Observable de boolean da confirmação da troca do idioma no BackEnd
     */
    changeLanguage(language) {
        if (this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse !== 'true') {
                    subscriber.error({
                        status: 400,
                        description: 'language could not be changed'
                    });
                }
                else {
                    subscriber.next();
                }
                subscriber.complete();
            }, {
                sendInfo: {
                    type: 'changeLanguage',
                    content: language
                },
                autoDestruct: true,
                receiveId: 'changeLanguage'
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessageService, deps: [{ token: i3.PoNotificationService }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i3.PoNotificationService }, { type: ProJsToAdvplService }] });

class ProAuthGuard {
    constructor(proAuthService, router) {
        this.proAuthService = proAuthService;
        this.router = router;
    }
    canActivate(next, state) {
        const url = state.url;
        return this.checkLogin(url);
    }
    checkLogin(url) {
        if (this.proAuthService.isUserAuthenticate) {
            return true;
        }
        // Store the attempted URL for redirecting
        this.proAuthService.redirectUrl = url;
        // Navigate to the login page with extras
        this.router.navigate(['/login']);
        return false;
    }
    canActivateChild(route, state) {
        return this.canActivate(route, state);
    }
    canLoad(route) {
        const url = `/${route.path}`;
        return this.checkLogin(url);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthGuard, deps: [{ token: ProAuthService }, { token: i2$1.Router }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProAuthService }, { type: i2$1.Router }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere o endereço e o header que define o erro padrão do Protheus.
 */
class ProAppConfigInteceptor {
    constructor(injector, sessionInfoService) {
        this.injector = injector;
        this.sessionInfoService = sessionInfoService;
    }
    intercept(original_request, next) {
        let requestResult;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (original_request.url.search(/assets/) >= 0) {
            requestResult = this.appendPathNameToUrl(original_request);
        }
        else {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                requestResult = this.appendDomainToUrl(original_request);
            }
            else {
                requestResult = original_request;
            }
        }
        return next.handle(requestResult);
    }
    /**
     * @description Altera a URL da requisição para acesso aos assets do app
     * @param request Requisição HTTP original
     * @returns Requisição HTTP com a alteração do path, somente para assets
     */
    appendPathNameToUrl(request) {
        const location = window.location;
        let appName = this.sessionInfoService.getAppName();
        let clone;
        if (appName === undefined) {
            clone = request.clone();
        }
        else {
            const requestUrl = request.url.startsWith('/') ? request.url.substring(1) : request.url;
            const newUrl = `${location.protocol}//${location.host}/app-root/${appName}/${requestUrl}`;
            const urlWithPathName = appName.includes('_env_')
                ? this.appendEnvironmentToUrl(location, appName, newUrl, requestUrl)
                : newUrl;
            clone = request.clone({
                url: urlWithPathName
            });
        }
        return clone;
    }
    /**
     * @description Inclui o nome do ambiente na URL da requisição que acessa os assets do app
     * @param location Localização atual do app
     * @param appName Nome do app atual
     * @param newUrl URL base montada
     * @param requestUrl URL da requisição original (caminho do /assets)
     * @returns URL alterada com o nome do ambiente
    */
    appendEnvironmentToUrl(location, appName, newUrl, requestUrl) {
        let urlWithEnvironment = newUrl;
        const locationPathNameEnvironment = this.sessionInfoService.getLocationPathNameEnvironment();
        const appNameArray = appName.split('_env_');
        if (appNameArray?.length > 1) {
            const environment = appNameArray[appNameArray.length - 1];
            if (environment && locationPathNameEnvironment === environment) {
                const root = `${environment}/${appName}`;
                urlWithEnvironment = `${location.protocol}//${location.host}/app-root/${root}/${requestUrl}`;
            }
        }
        return urlWithEnvironment;
    }
    /**
     * @description Altera da URL da requisição conforme regras
     * @param request Requisição HTTP Original
     * @returns Requisição HTTP, podendo ter sua URL alterada
     */
    appendDomainToUrl(request) {
        const proAppConfigService = this.injector.get(ProAppConfigService);
        const domain = proAppConfigService.serverWithApiUrl;
        let urlWithDomain = '';
        //Caso a URL comece com http ou https, concatenar o domínio vai gerar um URL inválida
        //Essa situação pode ocorrer quando o app consulta serviços de terceiros
        const lowerUrl = request.url.toLowerCase();
        if (lowerUrl.startsWith('http://') || lowerUrl.startsWith('https://')) {
            urlWithDomain = request.url;
        }
        else {
            urlWithDomain = `${domain}${request.url}`;
        }
        return request.clone({
            url: urlWithDomain
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigInteceptor, deps: [{ token: i0.Injector }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigInteceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigInteceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ProSessionInfoService }] });

class ProAppConfigModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigModule, providers: [
            { provide: HTTP_INTERCEPTORS, useClass: ProAppConfigInteceptor, multi: true }
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        { provide: HTTP_INTERCEPTORS, useClass: ProAppConfigInteceptor, multi: true }
                    ]
                }]
        }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o token.
 */
class ProAuthInteceptor {
    constructor(injector, advplService) {
        this.injector = injector;
        this.advplService = advplService;
    }
    intercept(original_request, next) {
        let requestResult;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (this.isUrlNeedsProAuth(original_request.url)) {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                if (this.doIHaveAToken()) {
                    requestResult = this.appendTokenToRequest(original_request);
                }
                else {
                    requestResult = this.callTokenFromADVPL(original_request);
                }
            }
            else {
                return next.handle(original_request);
            }
        }
        else {
            requestResult = original_request.clone();
        }
        return next.handle(requestResult).pipe(catchError((error, caught) => {
            if (!this.isAuthError(error)) {
                throw error;
            }
            if (this.isUrlNeedsProAuth(original_request.url) &&
                this.doIHaveAToken()) {
                return from(this.appendTokenOnError(original_request, next));
            }
            else {
                return next.handle(original_request.clone());
            }
        }));
    }
    isAuthError(error) {
        return error instanceof HttpErrorResponse && error.status === 401;
    }
    doIHaveAToken() {
        const proAuthService = this.injector.get(ProAuthService);
        const token = proAuthService.token;
        return !valueIsNull(token);
    }
    callTokenFromADVPL(request) {
        this.advplService.jsToAdvpl('internalToken', '');
        return request.clone();
    }
    appendTokenToRequest(request) {
        const proAuthService = this.injector.get(ProAuthService);
        if (!proAuthService.isTokenValid()) {
            proAuthService.updateToken();
        }
        return this.cloneAuthRequest(request, proAuthService.token);
    }
    async appendTokenOnError(request, next) {
        const proAuthService = this.injector.get(ProAuthService);
        if (!proAuthService.isTokenValid()) {
            await proAuthService.updateToken();
        }
        return next.handle(this.cloneAuthRequest(request, proAuthService.token)).toPromise();
    }
    cloneAuthRequest(request, token) {
        return request.clone({
            headers: request.headers.set('Authorization', `Bearer ${token.access_token}`)
        });
    }
    isUrlNeedsProAuth(url) {
        let needProAuth = true;
        const whiteList = [/token/, /assets/];
        for (const whiteUrl of whiteList) {
            if (url.search(whiteUrl) >= 0) {
                needProAuth = false;
                break;
            }
        }
        return needProAuth;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthInteceptor, deps: [{ token: i0.Injector }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthInteceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthInteceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ProJsToAdvplService }] });

class ProAuthorizationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthorizationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProAuthorizationModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthorizationModule, providers: [
            ProAuthService,
            ProAuthGuard,
            ProUserInfoService,
            { provide: HTTP_INTERCEPTORS, useClass: ProAuthInteceptor, multi: true }
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAuthorizationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [],
                    providers: [
                        ProAuthService,
                        ProAuthGuard,
                        ProUserInfoService,
                        { provide: HTTP_INTERCEPTORS, useClass: ProAuthInteceptor, multi: true }
                    ]
                }]
        }] });

class ProUserAccessService {
    constructor(http) {
        this.http = http;
        this.URL_ALIAS = '/api/framework/v1/accessPrivilegesServices/aliasAccess/';
        this.URL_FUNCTION = '/api/framework/v1/accessPrivilegesServices/functionAccess/';
    }
    /**
     * efetua um get na api referente a função MpUserHasAccess do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @param cRotina Nome da rotina a ser pesquisada
     * @param nOpc parametro opcional, numero da rotina no menudef a ser pesquisada
     * caso não seja passada a pesquisa será com base apenas na função
     * @returns Observable com o retorno da api
     */
    userHasAccess(cRotina, nOpc = 0) {
        if (nOpc) {
            return this.http.get(`${this.URL_FUNCTION}${cRotina}/${nOpc}`);
        }
        else {
            return this.http.get(`${this.URL_FUNCTION}${cRotina}`);
        }
    }
    /**
     * efetua um get na api referente a função FWChkTblAccess do protheus
     * a api utiliza o usuário logado para efetuar a busca
     * @param cTabela Tabela a ser pesquisada
     * @param nOpc parametro opcional, numero da rotina no menudef a ser pesquisada
     * caso não seja passada a pesquisa será com base apenas na função
     * @returns Observable com o retorno da api
     */
    aliasHasAccess(cTabela, nOpc = 0) {
        if (nOpc) {
            return this.http.get(`${this.URL_ALIAS}${cTabela}/${nOpc}`);
        }
        else {
            return this.http.get(`${this.URL_ALIAS}${cTabela}`);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserAccessService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserAccessService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserAccessService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

const CACHE_KEY = 'ERPAPPCONFIG';
class ProAppConfigService {
    constructor(http, advplService, sessionInfoService, proAuthService) {
        this.http = http;
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
        this.proAuthService = proAuthService;
        this.readyEmitter = new EventEmitter();
    }
    /**
     * @description Realiza o carregamento do appConfig.json e adiciona as informações de contexto.
     * @returns Promise, ProAppConfig
     */
    loadAppConfig() {
        if (this.isProtheusRender && this.insideProtheus() && this.proAuthService.isUserAuthenticate) {
            this.sessionInfoService.setSessionInfo();
        }
        return this.http
            .get('assets/data/appConfig.json')
            .toPromise()
            .then((data) => {
            const proAppConfig = data;
            // A função FwCallApp do Protheus pode ter subido a AppConfig com valores manipulados e não podemos sobreescrever
            if (sessionStorage[CACHE_KEY] === undefined) {
                sessionStorage[CACHE_KEY] = JSON.stringify(proAppConfig);
            }
            this.readyEmitter.emit();
            return this.proAppConfig;
        });
    }
    /**
     * @description Método para encerrar o aplicativo
     * @param ask Boolean que indica se o sistema deve perguntar antes de fechar o app
     */
    callAppClose(ask = true) {
        if (ask) {
            this.advplService.AdvplCloseApp('force');
        }
        else {
            this.advplService.AdvplCloseApp();
        }
    }
    insideProtheus() {
        return this.advplService.protheusConnected();
    }
    /**
     * @description Retorna as informações do appConfig.json (ProAppConfig)
     */
    get proAppConfig() {
        if (valueIsNull(this._ProAppConfig)) {
            this._ProAppConfig = this.sessionInfoService.getErpAppConfig();
        }
        return this._ProAppConfig;
    }
    get nameApp() {
        return this.proAppConfig.name;
    }
    get serverWithApiUrl() {
        if (this.proAppConfig) {
            return valueIsNull(this.proAppConfig.api_baseUrl)
                ? this.proAppConfig.serverBackend + this.proAppConfig.restEntryPoint
                : this.proAppConfig.api_baseUrl;
        }
        else {
            return '';
        }
    }
    /**
     * @description Retorna a linha de produto que está sendo utilizada.
     * @returns string
     */
    get productLine() {
        return this.proAppConfig ? this.proAppConfig.productLine : '';
    }
    get isProtheusRender() {
        return this.productLine.toLowerCase() === 'protheus';
    }
    freeAppConfig() {
        this._ProAppConfig = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProSessionInfoService }, { token: ProAuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAppConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProSessionInfoService }, { type: ProAuthService }] });

class ProLanguageService {
    constructor(http, advplService, proAppConfigService) {
        this.http = http;
        this.advplService = advplService;
        this.proAppConfigService = proAppConfigService;
        this.url = '/api/language/v1/protheus-suported-languages';
        this.useHTTP = true;
        this.EVENT_GET_LANGUAGES = 'getLanguages';
        this.EVENT_SET_LANGUAGES = 'setLanguages';
    }
    getListOfLanguages() {
        if (this.proAppConfigService.isProtheusRender) {
            if (this.useHTTP) {
                return this.http.get(this.url);
            }
            return this.getAdvplLanguages();
        }
        else {
            return of([]);
        }
    }
    getAdvplLanguages() {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: 'No language can be found'
                });
            }
            else {
                const laguages = JSON.parse(protheusResponse);
                subscriber.next(laguages);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_LANGUAGES
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_LANGUAGES
        });
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProLanguageService'
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProAppConfigService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProAppConfigService }] });

class ProBrandService {
    constructor(http, advplService, proAppConfigService) {
        this.http = http;
        this.advplService = advplService;
        this.proAppConfigService = proAppConfigService;
        this.url = '/api/brand/v1/erp-brand';
        this.useHTTP = true;
        this.EVENT_GET_BRANDCONTEXT = 'getBrandContext';
        this.EVENT_SET_BRANDCONTEXT = 'setBrandContext';
    }
    getERPBrand() {
        if (this.proAppConfigService.isProtheusRender) {
            if (this.useHTTP) {
                return this.http.get(this.url, { responseType: 'text' });
            }
            return this.getAdvplBrandContext();
        }
        else {
            return of('TOTVS');
        }
    }
    /**
     * @description Cria um observable para a comunicação com o ADVPL
     * @returns Observable de string sobre a marca do ambiente
     */
    getAdvplBrandContext() {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (subscriber) {
                if (protheusResponse.length === 0) {
                    subscriber.error({
                        status: 400,
                        description: 'Brand context not found'
                    });
                }
                else {
                    subscriber.next(protheusResponse);
                }
                subscriber.complete();
            }
        }, {
            sendInfo: {
                type: this.EVENT_GET_BRANDCONTEXT
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_BRANDCONTEXT
        });
    }
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProBrandService'
            });
            subscriber.complete();
        });
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProAppConfigService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProAppConfigService }] });

const ENDPOINT = '/api/protheus/session/v1/defaults';
class ProSessionSettingsService {
    constructor(http, advplService, sessionInfoService) {
        this.http = http;
        this.advplService = advplService;
        this.sessionInfoService = sessionInfoService;
    }
    requestSettingsDefaults() {
        if (!valueIsNull(this.advplService.getWebChannel())) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse.length === 0) {
                    subscriber.next({
                        role_code: '',
                        role_description: '',
                        role_when: false,
                        show_go_emp_fil: false,
                        show_mdi_menu_info: false,
                        environment_code: '',
                        environment_description: '',
                        environment_when: true,
                        disable_back_button: false
                    });
                }
                else {
                    const startKeys = JSON.parse(protheusResponse);
                    subscriber.next(startKeys);
                }
                subscriber.complete();
            }, {
                autoDestruct: true,
                receiveId: 'setSessionStart',
                sendInfo: {
                    type: 'getSessionStart'
                }
            });
        }
        else {
            const headers = new HttpHeaders().append('Accept', 'application/json; charset=utf-8');
            return this.http.get(ENDPOINT, {
                headers
            });
        }
    }
    /**
     * @description Realiza a limpeza das informações adicionadas na tela de sessão.
     */
    clearSettingsDefaults() {
        if (this.advplService.protheusConnected()) {
            this.advplService.jsToAdvpl('backButton', '');
        }
        const erpAppConfig = this.sessionInfoService.getErpAppConfig();
        const programStart = this.sessionInfoService.getProgramStart();
        const newHome = this.sessionInfoService.getNewHome();
        sessionStorage.clear();
        sessionStorage.setItem('ERPAPPCONFIG', JSON.stringify(erpAppConfig));
        sessionStorage.setItem('ProStartProgram', JSON.stringify(programStart));
        sessionStorage.setItem('ProNewHome', JSON.stringify(newHome));
        if (erpAppConfig) {
            this.sessionInfoService.setErpAppConfig(erpAppConfig);
        }
    }
    saveSettingsDefaults(session) {
        if (this.advplService.protheusConnected()) {
            return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
                if (protheusResponse === 'true') {
                    subscriber.next({});
                }
                else {
                    subscriber.error({});
                }
                subscriber.complete();
            }, {
                autoDestruct: true,
                receiveId: 'submitButtonResponse',
                sendInfo: {
                    type: 'submitButton',
                    content: JSON.stringify(session)
                }
            });
        }
        else {
            const headers = new HttpHeaders().append('Content-Type', 'application/json; charset=utf-8');
            return this.http.post(ENDPOINT, session, { headers });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProSessionInfoService }] });

class ProSessionSettingsDefaultsResolver {
    constructor(sessionSettingsService) {
        this.sessionSettingsService = sessionSettingsService;
    }
    resolve(_route, _state) {
        return this.sessionSettingsService.requestSettingsDefaults();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsDefaultsResolver, deps: [{ token: ProSessionSettingsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsDefaultsResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsDefaultsResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProSessionSettingsService }] });

class ProSessionSettingsUserInfoResolver {
    constructor(proUserInfoService, proAuthService) {
        this.proUserInfoService = proUserInfoService;
        this.proAuthService = proAuthService;
        this.proUserInfoService.setChannelAsHTTP(environment.useHTTP);
    }
    resolve(_route, _state) {
        const userId = this.proAuthService.userId;
        return this.proUserInfoService.get(userId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsUserInfoResolver, deps: [{ token: ProUserInfoService }, { token: ProAuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsUserInfoResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsUserInfoResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProUserInfoService }, { type: ProAuthService }] });

/**
 * @description
 * Constante com os tokens para o tema TOTVS Clássico
 */
const ProThemeTotvsLight = {
    '--color-brand-01-lightest': '#d7f0fe',
    '--color-brand-01-lighter': '#9cd8fc',
    '--color-brand-01-light': '#6bc5fa',
    '--color-brand-01-base': '#045b8f',
    '--color-brand-01-dark': '#013f65',
    '--color-brand-01-darker': '#002944',
    '--color-brand-01-darkest': '#00182b',
    '--color-action-default': '#045b8f',
    '--color-action-hover': '#013f65',
    '--color-action-pressed': '#002944',
    '--color-action-disabled': '#b2b2b2',
    '--color-action-focus': '#00182b',
    '--color-neutral-light-00': '#ffffff',
    '--color-neutral-light-05': '#f2f2f2',
    '--color-neutral-light-10': '#e5e5e5',
    '--color-neutral-light-20': '#cccccc',
    '--color-neutral-light-30': '#b2b2b2',
    '--color-neutral-mid-40': '#999999',
    '--color-neutral-mid-60': '#666666',
    '--color-neutral-dark-70': '#4d4d4d',
    '--color-neutral-dark-80': '#363636',
    '--color-neutral-dark-90': '#1a1a1a',
    '--color-neutral-dark-95': '#0d0d0d',
    '--color-brand-02-base': '#045b8f',
    '--color-brand-03-base': '#045b8f',
    '--color-feedback-negative-lightest': '#f6e6e5',
    '--color-feedback-negative-lighter': '#e3aeab',
    '--color-feedback-negative-light': '#d58581',
    '--color-feedback-negative-base': '#be3e37',
    '--color-feedback-negative-dark': '#9b2d27',
    '--color-feedback-negative-darker': '#72211d',
    '--color-feedback-negative-darkerst': '#4a1512',
    '--color-feedback-info-lightest': '#e3e9f7',
    '--color-feedback-info-lighter': '#b0c1e8',
    '--color-feedback-info-light': '#7996d7',
    '--color-feedback-info-base': '#23489f',
    '--color-feedback-info-dark': '#173782',
    '--color-feedback-info-darker': '#0f2557',
    '--color-feedback-info-darkerst': '#081536',
    '--color-feedback-positive-lightest': '#def7ed',
    '--color-feedback-positive-lighter': '#7ecead',
    '--color-feedback-positive-light': '#41b483',
    '--color-feedback-positive-base': '#107048',
    '--color-feedback-positive-dark': '#0f5236',
    '--color-feedback-positive-darker': '#083a25',
    '--color-feedback-positive-darkerst': '#002415',
    '--color-feedback-warning-lightest': '#fcf6e3',
    '--color-feedback-warning-lighter': '#f7dd97',
    '--color-feedback-warning-light': '#f1cd6a',
    '--color-feedback-warning-base': '#efba2a',
    '--color-feedback-warning-dark': '#d8a20e',
    '--color-feedback-warning-darker': '#705200',
    '--color-feedback-warning-darkerst': '#473400',
};
/**
 * @description
 * Constante com os tokens para o tema escuro
 */
const ProThemeTotvsDark = {
    '--color-brand-01-lightest': '#051f31',
    '--color-brand-01-lighter': '#004064',
    '--color-brand-01-light': '#00659a',
    '--color-brand-01-base': '#0079b8',
    '--color-brand-01-dark': '#3dadfa',
    '--color-brand-01-darker': '#afd3fa',
    '--color-brand-01-darkest': '#e3eefb',
    '--color-action-default': '#3dadfa',
    '--color-action-hover': '#afd3fa',
    '--color-action-pressed': '#e3eefb',
    '--color-action-disabled': '#7c7c7c',
    '--color-action-focus': '#e3eefb',
    '--color-neutral-light-00': '#1c1c1c',
    '--color-neutral-light-05': '#202020',
    '--color-neutral-light-10': '#2b2b2b',
    '--color-neutral-light-20': '#3b3b3b',
    '--color-neutral-light-30': '#5a5a5a',
    '--color-neutral-mid-40': '#7c7c7c',
    '--color-neutral-mid-60': '#a1a1a1',
    '--color-neutral-dark-70': '#c1c1c1',
    '--color-neutral-dark-80': '#d9d9d9',
    '--color-neutral-dark-90': '#eeeeee',
    '--color-neutral-dark-95': '#fbfbfb',
    '--color-brand-02-base': '#3dadfa',
    '--color-brand-03-base': '#3dadfa',
    '--color-feedback-negative-lightest': '#4a1512',
    '--color-feedback-negative-lighter': '#72211d',
    '--color-feedback-negative-light': '#9b2d27',
    '--color-feedback-negative-base': '#be3e37',
    '--color-feedback-negative-dark': '#d58581',
    '--color-feedback-negative-darker': '#e3aeab',
    '--color-feedback-negative-darkerst': '#f6e6e5',
    '--color-feedback-info-lightest': '#081536',
    '--color-feedback-info-lighter': '#0f2557',
    '--color-feedback-info-light': '#173782',
    '--color-feedback-info-base': '#23489f',
    '--color-feedback-info-dark': '#7996d7',
    '--color-feedback-info-darker': '#b0c1e8',
    '--color-feedback-info-darkerst': '#e3e9f7',
    '--color-feedback-positive-lightest': '#002415',
    '--color-feedback-positive-lighter': '#083a25',
    '--color-feedback-positive-light': '#0f5236',
    '--color-feedback-positive-base': '#107048',
    '--color-feedback-positive-dark': '#41b483',
    '--color-feedback-positive-darker': '#7ecead',
    '--color-feedback-positive-darkerst': '#def7ed',
    '--color-feedback-warning-lightest': '#473400',
    '--color-feedback-warning-lighter': '#705200',
    '--color-feedback-warning-light': '#d8a20e',
    '--color-feedback-warning-base': '#efba2a',
    '--color-feedback-warning-dark': '#f1cd6a',
    '--color-feedback-warning-darker': '#f7dd97',
    '--color-feedback-warning-darkerst': '#fcf6e3',
};
/**
 * @description
 * Constante com os tokens para o tema sunset
 */
const ProThemeSunsetLight = {
    '--color-brand-01-lightest': '#ffebee',
    '--color-brand-01-lighter': '#ef9a9a',
    '--color-brand-01-light': '#ef5350',
    '--color-brand-01-base': '#c20c18',
    '--color-brand-01-dark': '#a5131a',
    '--color-brand-01-darker': '#5d0d11',
    '--color-brand-01-darkest': '#400a08',
    '--color-action-default': '#c20c18',
    '--color-action-hover': '#a5131a',
    '--color-action-pressed': '#5d0d11',
    '--color-action-disabled': '#b2b2b2',
    '--color-action-focus': '#400a08',
    '--color-neutral-light-00': '#ffffff',
    '--color-neutral-light-05': '#f2f2f2',
    '--color-neutral-light-10': '#e5e5e5',
    '--color-neutral-light-20': '#cccccc',
    '--color-neutral-light-30': '#b2b2b2',
    '--color-neutral-mid-40': '#999999',
    '--color-neutral-mid-60': '#666666',
    '--color-neutral-dark-70': '#4d4d4d',
    '--color-neutral-dark-80': '#363636',
    '--color-neutral-dark-90': '#1a1a1a',
    '--color-neutral-dark-95': '#0d0d0d',
    '--color-brand-02-base': '#c20c18',
    '--color-brand-03-base': '#c20c18',
    '--color-feedback-negative-lightest': '#f1e8fd',
    '--color-feedback-negative-lighter': '#d691e1',
    '--color-feedback-negative-light': '#ba6bcd',
    '--color-feedback-negative-base': '#7b1fa2',
    '--color-feedback-negative-dark': '#4a148c',
    '--color-feedback-negative-darker': '#3e166f',
    '--color-feedback-negative-darkerst': '#1e0a36',
    '--color-feedback-info-lightest': '#e3e9f7',
    '--color-feedback-info-lighter': '#b0c1e8',
    '--color-feedback-info-light': '#7996d7',
    '--color-feedback-info-base': '#23489f',
    '--color-feedback-info-dark': '#173782',
    '--color-feedback-info-darker': '#0f2557',
    '--color-feedback-info-darkerst': '#081536',
    '--color-feedback-positive-lightest': '#def7ed',
    '--color-feedback-positive-lighter': '#7ecead',
    '--color-feedback-positive-light': '#41b483',
    '--color-feedback-positive-base': '#107048',
    '--color-feedback-positive-dark': '#0f5236',
    '--color-feedback-positive-darker': '#083a25',
    '--color-feedback-positive-darkerst': '#002415',
    '--color-feedback-warning-lightest': '#fcf6e3',
    '--color-feedback-warning-lighter': '#f7dd97',
    '--color-feedback-warning-light': '#f1cd6a',
    '--color-feedback-warning-base': '#efba2a',
    '--color-feedback-warning-dark': '#d8a20e',
    '--color-feedback-warning-darker': '#705200',
    '--color-feedback-warning-darkerst': '#473400',
};

/**
 * @description Classe para consumo de traduções de resource presentes no RPO do Protheus
 */
class ProTranslateStringService {
    /**
     * @description Construtor da classe
     * @param http Objeto HttpClient para efetuar as requisições REST
     * @param advplService Serviço ProJsToAdvplService para comunicação via jsToAdvpl
     * @param proAppConfigService Serviço ProAppConfigService para verificação de estado (Advpl/Http)
     */
    constructor(http, advplService, proAppConfigService) {
        this.http = http;
        this.advplService = advplService;
        this.proAppConfigService = proAppConfigService;
        this.url = '/api/framework/v1/FwRestTranslate/';
        this.useHTTP = true;
        this.EVENT_GET_TRANSLATES = 'getTranslateStringResource';
        this.EVENT_SET_TRANSLATES = 'setTranslateStringResource';
    }
    /**
     * @description Retorna todas as string de um resource de tradução do Protheus
     * @param cTRES string contendo o nome do resource (CH)
     * @returns Retorna um json que pode conter nenhuma ou várias chaves de string, normalmente enumeradas de str0001 até str9999
     */
    getStrList(cTRES) {
        if (this.proAppConfigService.isProtheusRender) {
            if (this.useHTTP) {
                return this.http.get(`${this.url}${cTRES}`);
            }
            return this.getAdvplLanguages();
        }
        else {
            return of({});
        }
    }
    /**
     * @description Retorna as traduções do resource via ADVPL (jstoadvpl)
     * @returns Observable das traduções do resource do Protheus
     */
    getAdvplLanguages() {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: 'No translate can be found'
                });
            }
            else {
                const translates = JSON.parse(protheusResponse);
                subscriber.next(translates);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_TRANSLATES,
                content: ""
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_TRANSLATES
        });
    }
    /**
     * @description Retorna um erro da conexão jstoadvpl
     * @returns Observable de exceção
     */
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProTranslateStringService'
            });
            subscriber.complete();
        });
    }
    /**
     * @description Indica o consumo de API via HTTP ou jstoadvpl
     * @returns Informa se a classe fará a requisição via HTTP
     */
    isChannelHTTP() {
        return this.useHTTP;
    }
    /**
     * @description Permite dizer se a requisição será efetuada via HTTP ou jstoadvpl, sempre usar como HTTP, apenas pequenas exceções como jstoadvpl
     * @param value Uso de HTTP para requisição
     */
    setChannelAsHTTP(value) {
        this.useHTTP = value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringService, deps: [{ token: i1.HttpClient }, { token: ProJsToAdvplService }, { token: ProAppConfigService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: ProJsToAdvplService }, { type: ProAppConfigService }] });

class ProUserProfileService {
    constructor(http, poI18nService) {
        this.http = http;
        this.poI18nService = poI18nService;
        this.URL_PROFILE = "/api/framework/v1/profileService/";
        this.programName = "";
        this.task = "";
        this.type = "";
        this.isReady = false;
        const language = this.poI18nService.getShortLanguage();
        poI18nService.getLiterals({ language, context: 'general' })
            .subscribe(literals => {
            this.literals = literals;
        });
    }
    /**
     * Metodo para definir o profile a ser utilizado
     * antes de utilizar qualquer metodo de CRUD é necessário definir o profile por esse metodo.
     * @param programName Nome do programa a ser usado no profile
     * @param task Nome da tarefa a ser utilizado no profile
     * @param type Tipo a ser utilizado no profile
     */
    setProfile(programName, task, type) {
        this.programName = programName;
        this.task = task;
        this.type = type;
        this.isReady = true;
    }
    /**
     * Cria um novo registro no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    create(value) {
        const profileBody = this.getRequisitionBody(value);
        if (this.isReady) {
            return this.http.post(this.URL_PROFILE, profileBody);
        }
        else {
            return this.profileNotReady();
        }
    }
    /**
     * Busca o valor de uma chave salva no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param defaultValue Valor padrão a ser retornado caso não exista o profile na base
     * @param respType tipo a ser retornado, podendo ser apenas json ou text
     * @returns Observable com o retorno da api
     */
    read(defaultValue = "", respType = "json") {
        if (this.isReady) {
            let acceptHeader = "application/json";
            if (respType != "json") {
                respType = "text";
                acceptHeader = "text/plain";
            }
            const params = new HttpParams().set('defaultValue', defaultValue);
            const headers = new HttpHeaders().set('Accept', acceptHeader);
            return this.http.get(this.getUrlApi(), { responseType: respType, params, headers });
        }
        else {
            return this.profileNotReady();
        }
    }
    /**
     * Atualiza um registro no profile
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    update(value) {
        const profileBody = this.getRequisitionBody(value);
        if (this.isReady) {
            return this.http.put(this.getUrlApi(), profileBody);
        }
        else {
            return this.profileNotReady();
        }
    }
    /**
     * Deleta um registro no profile
     * @returns Observable com o retorno da api
     */
    delete() {
        if (this.isReady) {
            return this.http.delete(this.getUrlApi());
        }
        else {
            return this.profileNotReady();
        }
    }
    /**
     * Deleta e cria um registro no profile
     * esse metodo pode substituir o uso do metodo create e update em alguns casos
     * (profile a ser gravado definido pelo metodo setProfile)
     * @param value Valor a ser gravado no profile
     * @returns Observable com o retorno da api
     */
    deleteThenCreate(value) {
        if (this.isReady) {
            return this.http.delete(this.getUrlApi()).pipe(catchError$1(() => {
                // erro no delete deve ser pelo fato do profile não existir ainda
                // retorna o post do profile
                return of(this.http.post(this.URL_PROFILE, this.getRequisitionBody(value)));
            }), switchMap(() => this.http.post(this.URL_PROFILE, this.getRequisitionBody(value))));
        }
        else {
            return this.profileNotReady();
        }
    }
    /**
     * Observable para apresentar um erro para o usuário caso utilize algum metodo de CRUD
     * sem utilizar o setProfile antes
     * @returns Observable com erro
     */
    profileNotReady() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                message: this.literals.str0001 // 'Para utilizar esse serviço é preciso definir o profile a ser utilizado pelo método setProfile'
            });
            subscriber.complete();
        });
    }
    /**
     * retorna a composição da url da api, com os path param necessários
     * @returns url completa da api
     */
    getUrlApi() {
        return `${this.URL_PROFILE}${this.programName}/${this.task}/${this.type}`;
    }
    /**
     * body para ser utilizado no post e update da api de profile
     * @param value Valor a ser gravado no profile
     * @returns o body a ser utilizado
     */
    getRequisitionBody(value) {
        const profileBody = {
            programName: this.programName,
            task: this.task,
            type: this.type,
            value: value
        };
        return profileBody;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileService, deps: [{ token: i1.HttpClient }, { token: i3.PoI18nService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i3.PoI18nService }] });

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240711
const literalsEnUS$3 = {
    str0001: 'Protheus Line',
    str0002: 'User or password not valid.',
    str0003: 'Unable to connect with server.',
    str0004: 'A problem occurred in Login attempt',
    str0005: 'Enter your user',
    str0006: 'Ex. sp01\\name.lastname',
    str0007: 'Enter your password',
    str0008: 'This is an example with domain//user; however, depending on configuration, the user name may have another format.',
    str0009: 'Associate Protheus user with Operational System user',
    str0010: 'Support'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240711
const literalsEsES$3 = {
    str0001: 'Línea Protheus',
    str0002: 'Usuario o contraseña no válida.',
    str0003: 'No fue posible establecer conexión con el servidor.',
    str0004: 'Ocurrió un problema al intentar el Login',
    str0005: 'Incluya su usuario',
    str0006: 'Ej. sp01\\nombre.apellido',
    str0007: 'Incluya su contraseña',
    str0008: 'Este es un ejemplo con dominio\\usuario, sin embargo, dependiendo de la configuración, el nombre del usuario puede tener otro formato.',
    str0009: 'Vincule usuario del Protheus al usuario del sistema operativo',
    str0010: 'Soporte'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240711
const literalsPtBR$3 = {
    str0001: 'Linha Protheus',
    str0002: 'Usuário ou senha inválida.',
    str0003: 'Não foi possível estabelecer conexão com o servidor.',
    str0004: 'Ocorreu um problema na tentativa de Login',
    str0005: 'Insira seu usuário',
    str0006: 'Ex. sp01\\nome.sobrenome',
    str0007: 'Insira sua senha',
    str0008: 'Este é um exemplo com dominio\\usuario, porém dependendo da configuração, o nome de usuário pode ter outro formato.',
    str0009: 'Associar usuário do Protheus com usuário do Sistema Operacional',
    str0010: 'Suporte'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240711
const literalsRuRU$3 = {
    str0001: "Линия #_PRODUCT_#",
    str0002: "Пользователь или пароль недействительны.",
    str0003: "Не удалось подключиться к серверу.",
    str0004: "При попытке входа в систему возникла проблема",
    str0005: "Введите имя пользователя",
    str0006: "Например, sp01\имя.фамилия",
    str0007: "Введите пароль",
    str0008: "Это пример с доменом//пользователем; однако, в зависимости от конфигурации, имя пользователя может иметь другой формат.",
    str0009: "Свяжите пользователя Proteus с пользователем операционной системы",
    str0010: 'Поддержка'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240816
const literalsEnUS$2 = {
    str0001: "Checking MFA",
    str0002: "To continue, enter the code generated by the authentication application.",
    str0003: "If you lose your device, contact the system administrator.",
    str0004: "CODE",
    str0005: "1. Scan the QR Code below in the MFA application of your choice:",
    str0006: '2. Enter below the MFA token generated in the application and click "Register"',
    str0007: "Register",
    str0008: "MFA Token not valid. Enter it again or contact the System Administrator.",
    str0009: "MFA Token successfully validated",
    str0010: "MFA Token successfully registered.",
    str0011: "Enter",
    str0012: "Back"
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240816
const literalsEsES$2 = {
    str0001: "Verificando MFA",
    str0002: "Para continuar es necesario incluir el código generado por la aplicación de autenticación.",
    str0003: "Si perdiera su dispositivo, entre en contacto con el administrador del sistema.",
    str0004: "CÓDIGO",
    str0005: "1. Escanear el siguiente QR Code en la aplicación MFA de su preferencia:",
    str0006: '2. Digite a continuación el token MFA generado en la aplicación y haga clic en "Registrar"',
    str0007: "Registrar",
    str0008: "Token MFA no válido, digite nuevamente o entre en contacto con el Administrador del Sistema.",
    str0009: "Token MFA validado con éxito",
    str0010: "Token MFA registrado con éxito.",
    str0011: "Entrar",
    str0012: "Volver"
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240816
const literalsPtBR$2 = {
    str0001: "Verificando MFA",
    str0002: "Para continuar é necessário inserir o código gerado pelo aplicativo de autenticação.",
    str0003: "Em caso de perda do dispositivo, entrar em contato com o administrador do sistema.",
    str0004: "CÓDIGO",
    str0005: "1. Escanear o QR Code abaixo no aplicativo MFA de sua preferência:",
    str0006: '2. Digite abaixo o token MFA gerado no aplicativo e clique em "Registrar"',
    str0007: "Registrar",
    str0008: "Token MFA inválido, digite novamente ou entre em contato com o Administrador do Sistema.",
    str0009: "Token MFA validado com sucesso.",
    str0010: "Token MFA registrado com sucesso.",
    str0011: "Entrar",
    str0012: "Voltar"
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20240816
const literalsRuRU$2 = {
    str0001: "Проверка MFA",
    str0002: "Для продолжения введите код, сгенерированный приложением для аутентификации",
    str0003: "В случае потери устройства обратитесь к системному администратору.",
    str0004: "Код",
    str0005: "1. Отсканируйте приведенный ниже QR-код в выбранном вами приложении MFA:",
    str0006: "2. Введите сгенерированный в приложении токен MFA и нажмите «Зарегистрироваться»",
    str0007: "Зарегистрироваться",
    str0008: "Токен MFA недействителен. Введите его еще раз или обратитесь к системному администратору",
    str0009: "Токен MFA успешно подтвержден",
    str0010: "Токен MFA успешно зарегистрирован",
    str0011: "Войти",
    str0012: "Назад"
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20260211
const literalsEnUS$1 = {
    str0001: 'Protheus Line',
    str0002: 'Choose a system base date.',
    str0003: 'After enabling it, you can restore this option on the system menu (Miscellaneous/SingleSignOn Users).',
    str0004: 'Support',
    str0005: 'Use the information above in all sessions.',
    str0006: 'Loading...',
    str0007: 'Enter',
    str0008: 'Back',
    str0009: 'Welcome, {0}.',
    str0010: 'Group',
    str0011: 'Select Group of Companies.',
    str0012: 'Branch',
    str0013: 'Select Branch.',
    str0014: 'Environment',
    str0015: 'Select system module.',
    str0016: 'Work role',
    str0017: 'Select a work role.',
    str0018: 'Base Date',
    str0019: 'Form not valid',
    str0020: 'Code',
    str0021: 'Description',
    str0022: 'Name',
    str0023: 'Start with last session information.',
    str0024: 'Unable to prepare printer. ',
    str0025: 'Trade name',
    str0026: 'EIN',
    str0027: 'Company',
    str0028: 'Unit',
    str0029: 'Enable dark mode',
    str0030: 'Disable dark mode',
    str0031: 'Tema {0} Classic Dark'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20260211
const literalsEsES$1 = {
    str0001: 'Línea Protheus',
    str0002: 'Seleccione la fecha base del sistema.',
    str0003: 'Después de habilitar, usted puede restaurar esta opción en el menú del sistema (Miscelánea/Usuarios SingleSignOn).',
    str0004: 'Soporte',
    str0005: 'Utilizar las informaciones anteriores en todas las sesiones.',
    str0006: 'Cargando....',
    str0007: 'Entrar',
    str0008: 'Volver',
    str0009: 'Bienvenido, {0}.',
    str0010: 'Grupo',
    str0011: 'Seleccione el Grupo de empresas.',
    str0012: 'Sucursal',
    str0013: 'Seleccione la sucursal.',
    str0014: 'Entorno',
    str0015: 'Seleccione el módulo del sistema.',
    str0016: 'Papel de trabajo',
    str0017: 'Seleccione un Papel de trabajo.',
    str0018: 'Fecha base',
    str0019: 'Formulario no válido',
    str0020: 'Código',
    str0021: 'Descripción',
    str0022: 'Nombre',
    str0023: 'Iniciar con la información de la última sesión.',
    str0024: 'No se pudo enviar la requisición. Por favor, intente nuevamente.',
    str0025: 'Nombre comercial',
    str0026: 'RCPJ',
    str0027: 'Empresa',
    str0028: 'Unidad',
    str0029: 'Activar modo escuro',
    str0030: 'Desactivar modo escuro',
    str0031: 'Tema {0} Classic Dark'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20260211
const literalsPtBR$1 = {
    str0001: 'Linha Protheus',
    str0002: 'Escolha a data base do sistema.',
    str0003: 'Após habilitado, você pode restaurar essa opção no menu do sistema(Miscelanea/Usuários SingleSignOn).',
    str0004: 'Suporte',
    str0005: 'Usar as informações acima em todas as sessões.',
    str0006: 'Carregando...',
    str0007: 'Entrar',
    str0008: 'Voltar',
    str0009: 'Boas-vindas, {0}.',
    str0010: 'Grupo',
    str0011: 'Selecione o Grupo de Empresas.',
    str0012: 'Filial',
    str0013: 'Selecione a Filial.',
    str0014: 'Ambiente',
    str0015: 'Selecione o módulo do sistema.',
    str0016: 'Papel de trabalho',
    str0017: 'Selecione um Papel de trabalho.',
    str0018: 'Data base',
    str0019: 'Formulário inválido',
    str0020: 'Código',
    str0021: 'Descrição',
    str0022: 'Nome',
    str0023: 'Iniciar com as informações da última sessão.',
    str0024: 'Não foi possível enviar a requisição. Por favor, tente novamente.',
    str0025: 'Nome comercial',
    str0026: 'CNPJ',
    str0027: 'Empresa',
    str0028: 'Unidade',
    str0029: 'Ativar modo escuro',
    str0030: 'Desativar modo escuro',
    str0031: 'Tema {0} Classic Dark'
};

/* tslint:disable */
// TOTVS TypeScript translaton resource
// Reference date : 20260211
const literalsRuRU$1 = {
    str0001: "Линия Protheus",
    str0002: "Выберите базовую дату системы.",
    str0003: 'After enabling it, you can restore this option on the system menu (Miscellaneous/SingleSignOn Users).',
    str0004: "Поддержка",
    str0005: "Используйте приведенную выше информацию во всех сеансах.",
    str0006: "Загрузка...",
    str0007: "Ввод",
    str0008: "Назад",
    str0009: "Добро пожаловать, {0}.",
    str0010: "Группа",
    str0011: "Выберите Группу компаний.",
    str0012: "Филиал",
    str0013: "Выберите Филиал.",
    str0014: "Среда",
    str0015: "Выберите системный модуль.",
    str0016: "Рабочая роль",
    str0017: "Выберите рабочую роль.",
    str0018: "Базовая дата",
    str0019: "Форма недействительна",
    str0020: "Код",
    str0021: "Описание",
    str0022: "Имя",
    str0023: "Начните с информации о последнем сеансе.",
    str0024: "Не удалось подготовить принтер.",
    str0025: "Торговое наименование",
    str0026: "ИНН/КПП",
    str0027: "Компания",
    str0028: "Филиал",
    str0029: "Включить темный режим",
    str0030: "Выключить темный режим",
    str0031: ''
};

/* tslint:disable */
// TOTVS TypeScript translation resource
// Reference date : 20230531
const literalsEnUS = {
    str0001: "Para utilizar esse serviço é preciso definir o profile a ser utilizado pelo método setProfile"
};

/* tslint:disable */
// TOTVS TypeScript translation resource
// Reference date : 20230531
const literalsEsES = {
    str0001: "Para utilizar esse serviço é preciso definir o profile a ser utilizado pelo método setProfile"
};

/* tslint:disable */
// TOTVS TypeScript translation resource
// Reference date : 20230531
const literalsPtBR = {
    str0001: "Para utilizar esse serviço é preciso definir o profile a ser utilizado pelo método setProfile"
};

/* tslint:disable */
// TOTVS TypeScript translation resource
// Reference date : 20230531
const literalsRuRU = {
    str0001: ''
};

const i18nConfig = {
    default: {
        language: 'pt',
        context: 'general',
        cache: true,
    },
    contexts: {
        login: {
            en: literalsEnUS$3,
            es: literalsEsES$3,
            pt: literalsPtBR$3,
            ru: literalsRuRU$3,
        },
        session: {
            en: literalsEnUS$1,
            es: literalsEsES$1,
            pt: literalsPtBR$1,
            ru: literalsRuRU$1,
        },
        profileService: {
            en: literalsEnUS,
            es: literalsEsES,
            pt: literalsPtBR,
            ru: literalsRuRU,
        },
        mfa: {
            en: literalsEnUS$2,
            es: literalsEsES$2,
            pt: literalsPtBR$2,
            ru: literalsRuRU$2,
        },
        general: {},
    },
};
/**
 * @description
 * Módulo para concentrar todas as strings e serviços de tradução
 * que envolvem o PoI18nConfig e o PoI18nModule
 */
class ProI18nConfigModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nConfigModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProI18nConfigModule, imports: [i3.PoI18nModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nConfigModule, imports: [PoI18nModule.config(i18nConfig)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nConfigModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PoI18nModule.config(i18nConfig)],
                }]
        }] });

class ProUserProfileModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileModule, imports: [CommonModule,
            ProI18nConfigModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileModule, imports: [CommonModule,
            ProI18nConfigModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProUserProfileModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        CommonModule,
                        ProI18nConfigModule,
                    ]
                }]
        }] });

class ProThemeService {
    constructor(poTheme, proJsToAdvplService, proUserProfileService, proSessionInfoService) {
        this.poTheme = poTheme;
        this.proJsToAdvplService = proJsToAdvplService;
        this.proUserProfileService = proUserProfileService;
        this.proSessionInfoService = proSessionInfoService;
        /** Definição para atributo theme */
        this.themeConfigMap = {
            0: {
                type: {
                    light: ProThemeTotvsLight,
                    dark: ProThemeTotvsDark
                },
                defaultType: PoThemeTypeEnum.light
            },
            1: {
                type: {
                    light: ProThemeTotvsLight,
                    dark: ProThemeTotvsDark
                },
                defaultType: PoThemeTypeEnum.dark
            },
            2: {
                type: {
                    light: ProThemeSunsetLight,
                    dark: ProThemeTotvsDark
                },
                defaultType: PoThemeTypeEnum.light
            }
        };
    }
    /**
     * @description Método para configurar o tema do aplicativo com base
     * na configuração da localStorage - ProTheme
     * @param theme ProThemeEnum, tema a ser aplicado
     * @param type PoThemeTypeEnum, tipo do tema
     */
    setTheme(theme, type) {
        const a11y = this.proSessionInfoService.getErpAppConfig()?.name === 'protheuslib-tface'
            ? PoThemeA11yEnum.AAA
            : PoThemeA11yEnum.AA;
        // Se release igual ou superior a 12.1.2610 ou se utilizado a Lib @framesp/ProtheusLibTHF o tema não pode ser alterado
        if (!ProSessionInfoService.canSetTheme || this.proSessionInfoService.getThemeType() === 'thf')
            return;
        if (theme) {
            this.poTheme.setTheme(theme, type, a11y);
        }
        else {
            const sessionProtheusTheme = this.getProtheusConfig();
            const configuration = this.themeConfigMap[sessionProtheusTheme?.Configuration ?? 0] ?? this.themeConfigMap[0];
            this.theme = {
                active: {
                    type: configuration.defaultType,
                    a11y
                },
                name: sessionProtheusTheme?.Description ?? 'Tema Totvs Classic Light',
                type: configuration.type
            };
            this.poTheme.setTheme(this.theme, configuration.defaultType, a11y);
        }
    }
    getProtheusConfig() {
        return this.proSessionInfoService.getTheme();
    }
    /**
     * @description Retorna se o usuário pode habilitar o tema dark.
     * @returns Observable de boolean
    */
    canUseDarkTheme() {
        if (this.proJsToAdvplService.protheusConnected()) {
            return this.checkDarkFromAdvpl();
        }
        else {
            return of(true); // Utilizado apenas em ambiente de desenvolvimento
        }
    }
    /**
     * @description Consulta se pode utilizar o tema dark fazendo a conexão direta com advpl.
     * @returns Observable de boolean
     */
    checkDarkFromAdvpl() {
        return this.proJsToAdvplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.next(false);
            }
            else {
                if (protheusResponse === 'true') {
                    subscriber.next(true);
                }
                else {
                    subscriber.next(false);
                }
            }
            subscriber.complete();
        }, {
            autoDestruct: true,
            receiveId: 'canUseDarkTheme',
            sendInfo: {
                type: 'canUseDarkTheme'
            }
        });
    }
    /**
     * @description Salva no profile do usuário se ele ativou ou desativou o tema dark.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    setThemeProfile(value) {
        if (this.proJsToAdvplService.protheusConnected()) {
            return this.setThemeProfileFromAdvpl(value);
        }
        else {
            return this.setThemeProfileFromApi(value);
        }
        ;
    }
    ;
    /**
     * @description Salva no profile fazendo a comunicação direta com o Protheus via JsToAdvpl.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    setThemeProfileFromAdvpl(value) {
        return this.proJsToAdvplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.next(false);
            }
            else {
                if (protheusResponse === 'true') {
                    subscriber.next(true);
                }
                else {
                    subscriber.next(false);
                }
            }
            subscriber.complete();
        }, {
            autoDestruct: true,
            receiveId: 'setThemeProfile',
            sendInfo: {
                type: 'setThemeProfile',
                content: value
            }
        });
    }
    ;
    /**
     * @description Salva no profile via api.
     * @param value string, valor a ser salvo no profile (true/false)
     * @returns Observable de boolean
     */
    setThemeProfileFromApi(value) {
        this.proUserProfileService.setProfile('wAPIpLOGIN', 'CONFIG', 'DARK');
        return this.proUserProfileService.update(value);
    }
    ;
    /**
     * @description Retorna o profile do usuário indicando se ele ativou/desativou o tema dark.
     * @returns Observable de boolean
     */
    getThemeProfile() {
        if (this.proJsToAdvplService.protheusConnected()) {
            return this.getThemeProfileFromAdvpl();
        }
        else {
            return this.getThemeProfileFromApi();
        }
        ;
    }
    ;
    /**
     * @description Retorna o profile realização a comunicação direta com o Protheus via JsToAdvpl.
     * @returns Observable de boolean
     */
    getThemeProfileFromAdvpl() {
        return this.proJsToAdvplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.next(false);
            }
            else {
                if (protheusResponse === 'true') {
                    subscriber.next(true);
                }
                else {
                    subscriber.next(false);
                }
            }
            subscriber.complete();
        }, {
            autoDestruct: true,
            receiveId: 'getDarkUserProfile',
            sendInfo: {
                type: 'getDarkUserProfile'
            }
        });
    }
    ;
    /**
     * @description Renotar o profile do usuário via api.
     * @returns Observable de boolean
     */
    getThemeProfileFromApi() {
        this.proUserProfileService.setProfile('wAPIpLOGIN', 'CONFIG', 'DARK');
        return this.proUserProfileService
            .read('true', 'text')
            .pipe(map$1((response) => (response === 'true' ? true : false)));
    }
    ;
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeService, deps: [{ token: i3.PoThemeService }, { token: ProJsToAdvplService }, { token: ProUserProfileService }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i3.PoThemeService }, { type: ProJsToAdvplService }, { type: ProUserProfileService }, { type: ProSessionInfoService }] });

class ProDateService {
    /**
     * @description Metodo construtor da classe
     * @param advplService Serviço ProJsToAdvplService para comunicação via jsToAdvpl
     */
    constructor(advplService) {
        this.advplService = advplService;
        this.EVENT_SET_FORMAT = 'setDateFormat';
        this.EVENT_GET_FORMAT = 'getDateFormat';
    }
    /**
     * @description Retorna o formato da data do sistema protheus com base no idioma.
     * @param language string codigo do idioma.
     * @returns Observable de string
     */
    getDateFormat(language) {
        if (!this.advplService.protheusConnected()) {
            return this.advplNotPrepared();
        }
        return this.advplService.buildObservable(({ protheusResponse, subscriber }) => {
            if (protheusResponse.length === 0) {
                subscriber.error({
                    status: 400,
                    description: `dateFormat for language ${language ? language : ''} could not be found`
                });
            }
            else {
                subscriber.next(protheusResponse);
            }
            subscriber.complete();
        }, {
            sendInfo: {
                type: this.EVENT_GET_FORMAT,
                content: language
            },
            autoDestruct: true,
            receiveId: this.EVENT_SET_FORMAT
        });
    }
    /**
     * @description Retorna um erro da conexão jstoadvpl
     * @returns Observable de exceção
     */
    advplNotPrepared() {
        return new Observable(subscriber => {
            subscriber.error({
                status: 400,
                description: 'advplService not prepared in ProDateService'
            });
            subscriber.complete();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateService, deps: [{ token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProJsToAdvplService }] });

class ProMessagesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessagesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProMessagesModule, imports: [CommonModule, PoNotificationModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessagesModule, imports: [CommonModule, PoNotificationModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProMessagesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, PoNotificationModule]
                }]
        }] });

class ProBrandModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProBrandModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProBrandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule]
                }]
        }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header do idioma.
 */
class ProSystemIdiomInteceptor {
    constructor(injector, sessionInfoService) {
        this.injector = injector;
        this.sessionInfoService = sessionInfoService;
    }
    /**
     * @description Intercept http para tratamento do módulo do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do módulo caso o ERP seja Protheus
     */
    intercept(original_request, next) {
        let requestResult = original_request;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (!(original_request.url.search(/assets/) >= 0)) {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                requestResult = this.appendLanguageToRequest(original_request);
            }
        }
        return next.handle(requestResult);
    }
    /**
     * @description Efetua a validação e adição do header de idioma
     * @param request Requisição HTTP Original
     * @returns HttpRequest, podendo ser alterada com a inclusão do idioma conforme o Protheus
     */
    appendLanguageToRequest(request) {
        const language = this.getLanguage();
        if (language) {
            return request.clone({
                headers: request.headers.set('Accept-Language', language)
            });
        }
        else {
            return request.clone();
        }
    }
    /**
     * @description Retorna o idioma presente no storage do navegador
     * @returns string contendo o valor de idioma do Protheus
     */
    getLanguage() {
        return this.sessionInfoService.getIdiom();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemIdiomInteceptor, deps: [{ token: i0.Injector }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemIdiomInteceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemIdiomInteceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ProSessionInfoService }] });

/**
 * @description Módulo de idioma, contendo os serviços e interceptor
 */
class ProLanguageModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageModule, providers: [
            ProLanguageService,
            { provide: HTTP_INTERCEPTORS, useClass: ProSystemIdiomInteceptor, multi: true }
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLanguageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        ProLanguageService,
                        { provide: HTTP_INTERCEPTORS, useClass: ProSystemIdiomInteceptor, multi: true }
                    ]
                }]
        }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o módulo.
 */
class ProSystemModulesInteceptor {
    constructor(injector, sessionInfoService) {
        this.injector = injector;
        this.sessionInfoService = sessionInfoService;
    }
    /**
     * @description Intercept http para tratamento do módulo do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do módulo caso o ERP seja Protheus
     */
    intercept(original_request, next) {
        let requestResult = original_request;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (!(original_request.url.search(/assets/) >= 0)) {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                requestResult = this.appendModuleToRequest(original_request);
            }
        }
        return next.handle(requestResult);
    }
    appendModuleToRequest(request) {
        const module = this.getModule();
        if (module) {
            return request.clone({
                headers: request.headers.set('x-erp-module', module)
            });
        }
        else {
            return request.clone();
        }
    }
    /**
     * @description Retorno o módulo logado
     * @returns string
     */
    getModule() {
        return this.sessionInfoService.getModule();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModulesInteceptor, deps: [{ token: i0.Injector }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModulesInteceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemModulesInteceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ProSessionInfoService }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o database.
 */
class ProSystemDatabaseInterceptor {
    constructor(injector, sessionInfoService) {
        this.injector = injector;
        this.sessionInfoService = sessionInfoService;
    }
    /**
     * @description Intercept http para tratamento do database do Protheus nas requisições
     * @param original_request Requisição http
     * @param next Handler da requisição http
     * @returns Observable da requisição http com o header do database caso o ERP seja Protheus
     */
    intercept(original_request, next) {
        let requestResult = original_request;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (!(original_request.url.search(/assets/) >= 0)) {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                requestResult = this.appendDataBaseToRequest(original_request);
            }
        }
        return next.handle(requestResult);
    }
    /**
     * @description Adiciona o header da database na requisição caso exista
     * @param request Objeto HttpRequest da requisição
     * @returns HttpRequest da requisição com a database ou apenas um cópia
     */
    appendDataBaseToRequest(request) {
        const database = this.getDatabase();
        if (database) {
            return request.clone({
                headers: request.headers.set('x-erp-database', database)
            });
        }
        else {
            return request.clone();
        }
    }
    /**
     * @description Verifica o valor da database no SessionStorage
     * @returns Retorna o valor da database no SessionStorage, podendo não ter valor algum
     */
    getDatabase() {
        return this.sessionInfoService.getDataBase();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemDatabaseInterceptor, deps: [{ token: i0.Injector }, { token: ProSessionInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemDatabaseInterceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemDatabaseInterceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }, { type: ProSessionInfoService }] });

class ProSystemInfoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProSystemInfoModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemInfoModule, providers: [
            ProSystemModuleService,
            { provide: HTTP_INTERCEPTORS, useClass: ProSystemModulesInteceptor, multi: true },
            { provide: HTTP_INTERCEPTORS, useClass: ProSystemDatabaseInterceptor, multi: true }
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSystemInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        ProSystemModuleService,
                        { provide: HTTP_INTERCEPTORS, useClass: ProSystemModulesInteceptor, multi: true },
                        { provide: HTTP_INTERCEPTORS, useClass: ProSystemDatabaseInterceptor, multi: true }
                    ]
                }]
        }] });

/**
 * @description
 *
 * Interceptor que pega a requisição html e insere no header o token.
 */
class ProTenantInteceptor {
    constructor(injector) {
        this.injector = injector;
    }
    intercept(original_request, next) {
        let requestResult = original_request;
        const proAppConfigService = this.injector.get(ProAppConfigService);
        if (!(original_request.url.search(/assets/) >= 0)) {
            const isProtheus = proAppConfigService.isProtheusRender;
            if (isProtheus) {
                requestResult = this.appendTenantToRequest(original_request);
            }
        }
        return next.handle(requestResult);
    }
    appendTenantToRequest(request) {
        const tenantid = this.getTenantId();
        if (tenantid) {
            return request.clone({
                headers: request.headers.set('tenantid', tenantid)
            });
        }
        else {
            return request.clone();
        }
    }
    getTenantId() {
        const proBranchService = this.injector.get(ProBranchService);
        const proCompanyService = this.injector.get(ProCompanyService);
        const companyCode = proCompanyService.company.Code;
        const branchCode = proBranchService.branch.Code;
        let tenantid = '';
        if (companyCode !== '') {
            tenantid += companyCode;
            if (branchCode !== '') {
                // adicionada a virgula a direita para preservar o espaço a direita
                // no codigo da filial quando houver
                tenantid += `,${branchCode},`;
            }
            return tenantid;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantInteceptor, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantInteceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantInteceptor, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i0.Injector }] });

class ProTenantModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProTenantModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantModule, providers: [
            ProCompanyService,
            ProBranchService,
            { provide: HTTP_INTERCEPTORS, useClass: ProTenantInteceptor, multi: true }
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTenantModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        ProCompanyService,
                        ProBranchService,
                        { provide: HTTP_INTERCEPTORS, useClass: ProTenantInteceptor, multi: true }
                    ]
                }]
        }] });

class ProThemeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProThemeModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeModule, providers: [ProThemeService, { provide: 'Window', useValue: window }], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [ProThemeService, { provide: 'Window', useValue: window }],
                }]
        }] });

/***
 * @description Classe com métodos para recuperar informações da thread do Protheus, thread a qual abriu o app via FWCallApp
 */
class ProThreadInfoService {
    constructor(proAuthService, proUserInfoService) {
        this.proAuthService = proAuthService;
        this.proUserInfoService = proUserInfoService;
    }
    /**
     * @description Retorna um objeto contendo informações do usuário logado no app e na thread do Protheus
     * @returns ProThreadInfo = {userId, userName}
     * userId = ID do usuário
     * userName = Nome (login) do usuário
     */
    get proThreadInfo() {
        const token = this.proAuthService.getTokenPayload();
        const proThreadInfo = {};
        proThreadInfo.userId = token.userid;
        proThreadInfo.userName = token.sub;
        return proThreadInfo;
    }
    /**
     * @description Recupera o ID do usuário logado no app e no Protheus
     * @returns ID do usuário
     */
    get userId() {
        return this.proAuthService.userId;
    }
    /**
     * @description Recupera o nome (login) do usuário logado no app e no Protheus
     * @returns Nome do usuário (login)
     */
    get userName() {
        return this.proThreadInfo.userName;
    }
    /**
     * @description Retorna informações do usuário logado (id, nome de usuário, nome e emails)
     * @returns ProUserInfo = {id, userName, displayName, emails}
     */
    getUserInfoThread() {
        return this.proUserInfoService.get(this.userId, true).pipe(map$1((user) => ({
            id: user.id,
            userName: user.userName,
            displayName: user.displayName,
            emails: user.emails
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoService, deps: [{ token: ProAuthService }, { token: ProUserInfoService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: ProAuthService }, { type: ProUserInfoService }] });

/**
 * @description Módulo com as classes que retornam informações da thread do Protheus
 */
class ProThreadInfoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoModule, providers: [ProThreadInfoService], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThreadInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [ProThreadInfoService]
                }]
        }] });

/**
 * @description Módulo contendo as classes para consumo de traduções do Protheus, traduções presentes no RPO do Protheus como resources
 */
class ProTranslateStringModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringModule, providers: [ProTranslateStringService], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProTranslateStringModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [ProTranslateStringService]
                }]
        }] });

class ProDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProDateModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateModule, providers: [ProDateService], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [ProDateService]
                }]
        }] });

/**
 * @description Módulo contendo os serviços do protheus-lib-core
 */
class ProServicesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProServicesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProServicesModule, imports: [CommonModule,
            ProAppConfigModule,
            ProAuthorizationModule,
            ProJsToAdvplModule,
            ProMessagesModule,
            ProTenantModule,
            ProSystemInfoModule,
            ProLanguageModule,
            ProThemeModule,
            ProBrandModule,
            ProThreadInfoModule,
            ProTranslateStringModule,
            ProUserProfileModule,
            ProDateModule], exports: [ProAppConfigModule,
            ProAuthorizationModule,
            ProJsToAdvplModule,
            ProMessagesModule,
            ProTenantModule,
            ProSystemInfoModule,
            ProLanguageModule,
            ProBrandModule,
            ProThreadInfoModule,
            ProTranslateStringModule,
            ProUserProfileModule,
            ProDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProServicesModule, imports: [CommonModule,
            ProAppConfigModule,
            ProAuthorizationModule,
            ProJsToAdvplModule,
            ProMessagesModule,
            ProTenantModule,
            ProSystemInfoModule,
            ProLanguageModule,
            ProThemeModule,
            ProBrandModule,
            ProThreadInfoModule,
            ProTranslateStringModule,
            ProUserProfileModule,
            ProDateModule, ProAppConfigModule,
            ProAuthorizationModule,
            ProJsToAdvplModule,
            ProMessagesModule,
            ProTenantModule,
            ProSystemInfoModule,
            ProLanguageModule,
            ProBrandModule,
            ProThreadInfoModule,
            ProTranslateStringModule,
            ProUserProfileModule,
            ProDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProServicesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ProAppConfigModule,
                        ProAuthorizationModule,
                        ProJsToAdvplModule,
                        ProMessagesModule,
                        ProTenantModule,
                        ProSystemInfoModule,
                        ProLanguageModule,
                        ProThemeModule,
                        ProBrandModule,
                        ProThreadInfoModule,
                        ProTranslateStringModule,
                        ProUserProfileModule,
                        ProDateModule
                    ],
                    exports: [
                        ProAppConfigModule,
                        ProAuthorizationModule,
                        ProJsToAdvplModule,
                        ProMessagesModule,
                        ProTenantModule,
                        ProSystemInfoModule,
                        ProLanguageModule,
                        ProBrandModule,
                        ProThreadInfoModule,
                        ProTranslateStringModule,
                        ProUserProfileModule,
                        ProDateModule
                    ],
                }]
        }] });

class ProAdapterBaseV2Service {
    /**
     * @description Retorna parâmetros no formato HttpParams para ser enviado na requisição HTTP.
     *
     * @param page number, número da página
     * @param pageSize number, quantidade de registros da página
     * @param filter string, filtro a ser utilizado na requisição
     * @param fields string, campos a serem retornados pela requisição
     * @param order string, ordenação a ser utilizada no retorno da requisição
     *
     * @return HttpParams, parâmetros
    */
    getHttpParams(page, pageSize, filter, fields, order) {
        const params = new HttpParams()
            .append('page', page ? page : 1)
            .append('pageSize', pageSize ? pageSize : 20)
            .append('filter', filter ? filter : '')
            .append('fields', fields ? fields : '')
            .append('order', order ? order : '');
        return params;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAdapterBaseV2Service, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAdapterBaseV2Service, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProAdapterBaseV2Service, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ProGenericAdapterService {
    constructor(http) {
        this.http = http;
        this.URL_LIST = "/api/framework/v1/genericList";
        this.URL_QUERY = "/api/framework/v1/genericQuery";
    }
    /**
     * Metodo para devolver uma listagem de registro baseado na api genericList
     * @param searchParams parametros da interface ProAdapterListInterface a ser enviado
     * para api genericList
     * @returns Observable de ProAdapterBaseV2 a ser utilizado em um po-table
     */
    list(searchParams) {
        const params = this.convertSearchParamsToHttpParams(searchParams);
        return this.http.get(this.URL_LIST, { params });
    }
    /**
     * Metodo para devolver uma listagem de registro baseado na api genericQuery
     * @param searchParams parametros da interface ProAdapterQueryInterface a ser enviado
     * para api genericQuery
     * @returns Observable de ProAdapterBaseV2 a ser utilizado em um po-table
     */
    query(searchParams) {
        const params = this.convertSearchParamsToHttpParams(searchParams);
        return this.http.get(this.URL_QUERY, { params });
    }
    /**
     * converte uma interface para httpParams
     * cada propriedade vira um parametro http
     * @param searchParams parametro a ser convetido
     * @returns httpParams a ser utilizado em uma requisição
     */
    convertSearchParamsToHttpParams(searchParams) {
        let params = new HttpParams();
        Object.keys(searchParams).forEach(key => {
            params = params.set(key, searchParams[key]);
        });
        return params;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProGenericAdapterService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProGenericAdapterService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProGenericAdapterService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

/**
 * @description
 * Classe para tratamentos de i18n do Protheus
 */
class ProI18nService {
    /**
     * @description
     * Efetua a transformação de um texto de tradução com tokens,
     * os tokens são iniciados com # e um número de 1 a 99.
     * Os valores são convertidos para string via função String do JS,
     * não possuindo um padrão de conversão
     *
     * @param str Texto de internacionalização
     * @param values Lista de tokens, podendo ter de 0 a 99 itens
     * @returns Texto original com a substituição dos tokens (#)
     */
    static getTranslateTokenString(str, values = []) {
        for (let i = values.length - 1; i >= 0; i--) {
            const token = String(values[i]);
            const section = '#' + (i + 1).toString();
            const posSection = str.indexOf(`${section}[`);
            if (posSection >= 0) {
                const hintStart = posSection + section.length;
                const hintEnd = str.substring(hintStart + 1).indexOf(']#');
                if (hintStart >= 0 && hintEnd >= 0) {
                    const search = new RegExp(`${section}\\[.*]#`, 'g');
                    str = str.replace(search, section);
                }
            }
            str = str.replace(section, token);
        }
        return str;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProI18nService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

/**
 * @docsPrivate
 *
 * @description
 *
 * Componente para definição de cor de fundo e dos logotipos primário e secundário para os templates
 * de `po-page-login` e demais templates de login.
 */
class ProPageBackgroundComponent {
    /** Caminho para a logomarca localizada na parte superior. */
    set logo(value) {
        this._logo = isTypeof(value, 'string') && value.trim() ? value : undefined;
    }
    get logo() {
        return this._logo;
    }
    /**
     * @optional
     *
     * @description
     *
     * Caminho para a logomarca localizada no rodapé.
     */
    set secondaryLogo(value) {
        this._secondaryLogo =
            isTypeof(value, 'string') && value.trim() ? value : undefined;
    }
    get secondaryLogo() {
        return this._secondaryLogo;
    }
    /** Define se o seletor de idiomas deve ser exibido. */
    set showSelectLanguage(showSelectLanguage) {
        this._showSelectLanguage = convertToBoolean(showSelectLanguage);
    }
    get showSelectLanguage() {
        return this._showSelectLanguage;
    }
    /**
     * @description Construtor do componente
     * @param poLanguageService Serviço de idioma do PO UI
     * @param proLanguageService Serviço de idiomas do Protheus
     */
    constructor(poLanguageService, proLanguageService) {
        this.poLanguageService = poLanguageService;
        this.proLanguageService = proLanguageService;
        this.selectLanguageOptions = [];
        /**
         * Evento disparado ao selecionar alguma opção no seletor de idiomas.
         * Para este evento será passado como parâmetro o valor de idioma selecionado.
         */
        // tslint:disable-next-line: no-output-rename
        this.selectedLanguage = new EventEmitter();
        this.updateLangs();
    }
    /**
     * @description Atualiza os idiomas disponíveis
     */
    updateLangs() {
        this.proLanguageService.setChannelAsHTTP(environment.useHTTP);
        this.proLanguageService.getListOfLanguages().subscribe({
            next: (langs) => {
                this.selectLanguageOptions = langs.map((language) => {
                    return {
                        label: language.description,
                        value: language.language,
                    };
                });
            },
            error: (error) => {
                console.error(error);
            },
        });
    }
    ngOnInit() {
        this.selectedLanguageOption = this.poLanguageService.getShortLanguage();
    }
    onChangeLanguage() {
        this.selectedLanguage.emit(this.selectedLanguageOption);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundComponent, deps: [{ token: i3.PoLanguageService }, { token: ProLanguageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.9", type: ProPageBackgroundComponent, isStandalone: false, selector: "pro-page-background", inputs: { background: ["p-background", "background"], hideLogo: ["p-hide-logo", "hideLogo"], highlightInfo: ["p-highlight-info", "highlightInfo"], logo: ["p-logo", "logo"], secondaryLogo: ["p-secondary-logo", "secondaryLogo"], showSelectLanguage: ["p-show-select-language", "showSelectLanguage"] }, outputs: { selectedLanguage: "p-selected-language" }, ngImport: i0, template: "<div class=\"po-page-login-container\">\r\n  <div\r\n    class=\"po-page-login-panel\">\r\n    @if (logo) {\r\n      <img\r\n        class=\"po-page-background-main-logo-image\"\r\n        [class.po-page-background-hide-logo-image]=\"hideLogo\"\r\n        alt=\"main-logo\"\r\n        [src]=\"logo\"\r\n        />\r\n    }\r\n\r\n    <div class=\"po-page-login-body\">\r\n      <div class=\"po-page-login-panel-content pro-bg-component\">\r\n        <ng-content></ng-content>\r\n      </div>\r\n    </div>\r\n    <div class=\"po-page-background-footer po-sm-12\">\r\n      <po-divider class=\"po-page-background-footer-mobile-only\"></po-divider>\r\n\r\n      <div class=\"po-page-background-footer-content\">\r\n        @if (showSelectLanguage) {\r\n          <div\r\n            class=\"po-page-background-footer-select\"\r\n            >\r\n            @if (selectLanguageOptions) {\r\n              <po-select\r\n                name=\"selectedLanguageOption\"\r\n                [(ngModel)]=\"selectedLanguageOption\"\r\n                [p-options]=\"selectLanguageOptions\"\r\n                (p-change)=\"onChangeLanguage()\"\r\n                >\r\n              </po-select>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        <div\r\n          class=\"po-page-background-secondary-logo\"\r\n          [ngClass]=\"\r\n            showSelectLanguage\r\n              ? 'po-page-background-secondary-logo-right'\r\n              : 'po-page-background-secondary-logo-centered'\r\n          \"\r\n          >\r\n          @if (secondaryLogo) {\r\n            <img\r\n              class=\"po-page-background-secondary-logo-image\"\r\n              alt=\"secondary-logo\"\r\n              [src]=\"secondaryLogo\"\r\n              />\r\n          }\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (background) {\r\n    <div\r\n    [ngClass]=\"\r\n      background\r\n        ? 'po-page-login-highlight-image'\r\n        : 'po-page-login-highlight-image-off'\r\n    \"\r\n      [style.background-image]=\"'url(' + background + ')'\"\r\n      >\r\n      <div class=\"po-page-login-highlight-text\">\r\n        <div class=\"po-font-display\">{{ highlightInfo }}</div>\r\n      </div>\r\n    </div>\r\n  }\r\n</div>\r\n", styles: [".pro-bg-component{margin-bottom:2%;padding:8%}\n"], dependencies: [{ kind: "directive", type: i3$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: i3.PoDividerComponent, selector: "po-divider" }, { kind: "component", type: i3.PoSelectComponent, selector: "po-select", inputs: ["p-readonly", "p-placeholder", "p-options", "p-field-label", "p-field-value", "p-control-value-with-label", "p-size", "p-helper", "p-label-text-wrap"], outputs: ["p-blur", "ngModelChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-page-background', standalone: false, template: "<div class=\"po-page-login-container\">\r\n  <div\r\n    class=\"po-page-login-panel\">\r\n    @if (logo) {\r\n      <img\r\n        class=\"po-page-background-main-logo-image\"\r\n        [class.po-page-background-hide-logo-image]=\"hideLogo\"\r\n        alt=\"main-logo\"\r\n        [src]=\"logo\"\r\n        />\r\n    }\r\n\r\n    <div class=\"po-page-login-body\">\r\n      <div class=\"po-page-login-panel-content pro-bg-component\">\r\n        <ng-content></ng-content>\r\n      </div>\r\n    </div>\r\n    <div class=\"po-page-background-footer po-sm-12\">\r\n      <po-divider class=\"po-page-background-footer-mobile-only\"></po-divider>\r\n\r\n      <div class=\"po-page-background-footer-content\">\r\n        @if (showSelectLanguage) {\r\n          <div\r\n            class=\"po-page-background-footer-select\"\r\n            >\r\n            @if (selectLanguageOptions) {\r\n              <po-select\r\n                name=\"selectedLanguageOption\"\r\n                [(ngModel)]=\"selectedLanguageOption\"\r\n                [p-options]=\"selectLanguageOptions\"\r\n                (p-change)=\"onChangeLanguage()\"\r\n                >\r\n              </po-select>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        <div\r\n          class=\"po-page-background-secondary-logo\"\r\n          [ngClass]=\"\r\n            showSelectLanguage\r\n              ? 'po-page-background-secondary-logo-right'\r\n              : 'po-page-background-secondary-logo-centered'\r\n          \"\r\n          >\r\n          @if (secondaryLogo) {\r\n            <img\r\n              class=\"po-page-background-secondary-logo-image\"\r\n              alt=\"secondary-logo\"\r\n              [src]=\"secondaryLogo\"\r\n              />\r\n          }\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n\r\n  @if (background) {\r\n    <div\r\n    [ngClass]=\"\r\n      background\r\n        ? 'po-page-login-highlight-image'\r\n        : 'po-page-login-highlight-image-off'\r\n    \"\r\n      [style.background-image]=\"'url(' + background + ')'\"\r\n      >\r\n      <div class=\"po-page-login-highlight-text\">\r\n        <div class=\"po-font-display\">{{ highlightInfo }}</div>\r\n      </div>\r\n    </div>\r\n  }\r\n</div>\r\n", styles: [".pro-bg-component{margin-bottom:2%;padding:8%}\n"] }]
        }], ctorParameters: () => [{ type: i3.PoLanguageService }, { type: ProLanguageService }], propDecorators: { background: [{
                type: Input,
                args: ['p-background']
            }], hideLogo: [{
                type: Input,
                args: ['p-hide-logo']
            }], highlightInfo: [{
                type: Input,
                args: ['p-highlight-info']
            }], logo: [{
                type: Input,
                args: ['p-logo']
            }], secondaryLogo: [{
                type: Input,
                args: ['p-secondary-logo']
            }], showSelectLanguage: [{
                type: Input,
                args: ['p-show-select-language']
            }], selectedLanguage: [{
                type: Output,
                args: ['p-selected-language']
            }] } });

class ProSessionSettingsComponent {
    /**
     * @description metodo chamado na mudança do combox de idioma da tela de parametros da sessão
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    onSelectedLanguage(language) {
        this.poI18nService.setLanguage(language, false);
        this.poI18nService
            .getLiterals({ language, context: 'session' })
            .subscribe(literals => {
            this.updLiterals(literals);
            this.updateProductName();
        });
        this.updateDateFormat(language);
        this.messageService.changeLanguage(language).subscribe({
            next: () => { this.updateModuleDescription(); }
        });
    }
    /**
     * @description Atualiza as strings traduzíveis da interface
     * @param literals Objeto de literais, contendo as traduções da interface
     */
    updLiterals(literals) {
        this.literals = literals;
        this.companyColumns[0].label = this.literals.str0020; // 'Código'
        this.companyColumns[1].label = this.literals.str0021; // 'Descrição'
        this.moduleColumns[0].label = this.literals.str0020; // 'Código'
        this.moduleColumns[1].label = this.literals.str0022; // 'Nome'
        this.moduleColumns[2].label = this.literals.str0021; // 'Descrição'
        this.roleColumns[0].label = this.literals.str0020; // 'Código'
        this.roleColumns[1].label = this.literals.str0021; // 'Descrição'
        this.updateBranchLiterals();
    }
    /**
     * @description Atualiza as strings de tradução as colunas do Lookup de filial
     */
    updateBranchLiterals() {
        this.branchColumns[0].label = this.literals.str0020; // 'Código'
        this.branchColumns[1].label = this.literals.str0021; // 'Descrição'
        this.branchColumns[2].label = this.literals.str0026; // 'CNPJ'
        this.branchColumns[3].label = this.literals.str0025; // 'Nome comercial'
        this.updateCnpjTitleColumn();
    }
    activateSupport(url = this.getSupportLink()) {
        this.setUrlRedirect(url);
    }
    /**
     * @description Método para obter o link de suporte
     * @returns Retorna uma string contendo o link de suporte do ERP
     */
    getSupportLink() {
        const language = this.poI18nService.getShortLanguage();
        let supportLink = 'http://suporte.totvs.com/';
        if (this.brand == 'MA3') {
            supportLink = language === 'en' ? 'https://www.national-platform.com/' : 'https://www.national-platform.ru/';
        }
        else {
            if (language === 'es') {
                supportLink = 'https://totvscst.zendesk.com/hc/es#home';
            }
            else if (language === 'en') {
                supportLink = 'https://totvscst.zendesk.com/hc/en-us#home';
            }
        }
        return supportLink;
    }
    /**
     * @description Efetua o redirect conforme a URL recebida
     * @param url URL que será verificada, podendo abrir uma janela ou mudar a rota
     */
    setUrlRedirect(url) {
        isExternalLink(url)
            ? window.open(url, '_blank')
            : this.router.navigate([url]);
    }
    /**
     * @description Construtor da classe
     * @param formBuilder Objeto FormBuilder para controle do formulário
     * @param router Objeto Router para controle da rota
     * @param messageService Serviço ProMessageService para exibição de notificações
     * @param route Objeto ActivatedRoute para controle da rota atual
     * @param proSessionSettingsService Serviço ProSessionSettingsService para obter os dados de login salvos
     * @param proCompanyService Serviço ProCompanyService para obter dados do grupo de empresas
     * @param proRoleService Serviço ProRoleService para obter dados de papel de trabalho
     * @param proBranchService Serviço ProBranchService para obter dados da filial
     * @param poI18nService Serviço PoI18nService para tradução da interface via dados locais
     * @param proTranslateStringService Serviço ProTranslateStringService para tradução da interface via API do Protheus
     * @param proBrandService Serviço para identificação da marca, MA3 na russia
     * @param proAuthService Serviço para Autenticação
     */
    constructor(formBuilder, router, messageService, route, proSessionSettingsService, proCompanyService, proRoleService, proBranchService, poI18nService, proTranslateStringService, proBrandService, proSystemModuleService, proThemeService, proDateService, proAuthService, proJsToAdvplService) {
        this.formBuilder = formBuilder;
        this.router = router;
        this.messageService = messageService;
        this.route = route;
        this.proSessionSettingsService = proSessionSettingsService;
        this.proCompanyService = proCompanyService;
        this.proRoleService = proRoleService;
        this.proBranchService = proBranchService;
        this.poI18nService = poI18nService;
        this.proTranslateStringService = proTranslateStringService;
        this.proBrandService = proBrandService;
        this.proSystemModuleService = proSystemModuleService;
        this.proThemeService = proThemeService;
        this.proDateService = proDateService;
        this.proAuthService = proAuthService;
        this.proJsToAdvplService = proJsToAdvplService;
        this.useHTTP = environment.useHTTP;
        this.darkSwitchValue = false;
        this.isDarkAllowed = false;
        this.isLoadingDark = true;
        this.isTokenValid = true;
        this.showModules = false;
        this.subs = new SubSink();
        this.poI18nPipe = new PoI18nPipe();
        this.companyColumns = [
            { property: 'Code', label: '' },
            { property: 'CorporateName', label: '' }
        ];
        this.branchColumns = this.getDefaultBranchColumns();
        this.moduleColumns = [
            { property: 'id', label: '' },
            { property: 'name', label: '' },
            { property: 'description', label: '' }
        ];
        this.roleColumns = [
            { property: 'Code', label: '' },
            { property: 'Description', label: '' }
        ];
        const language = poI18nService.getShortLanguage();
        poI18nService
            .getLiterals({ language, context: 'session' })
            .subscribe(literals => {
            this.updLiterals(literals);
            this.updateBrand();
        });
        this.updateDateFormat(language);
        this.messageService.changeLanguage(language);
        this.changeServicesChannel();
        blockBackAction('/session-settings', 'sessionSettings', this.proJsToAdvplService);
    }
    /**
     * @description Lista de colunas do Lookup de filiais
     * @returns Retorna uma lista de PoLookupColumn, contendo as colunas padrões do Lookup de filiais
     */
    getDefaultBranchColumns() {
        return [
            { property: 'Code', label: '', width: '140px' },
            { property: 'Description', label: '', width: '200px' },
            { property: 'Cgc', label: '', width: '180px' },
            { property: 'CommercialName', label: '', width: '200px' },
        ];
    }
    /**
     * @description metodo disparado a partir de um evento no lookup de company
     * utilizado para forçar o foco no lookup de branch
     */
    branchSettedEvent() {
        this.proBranchLookupComponent.setBranchFocus();
    }
    /**
     * @description Método disparado via o evento de troca de grupo de empresas
     * @param event Evento do formulário
     */
    changeBranchColumns(event) {
        this.updateCnpjTitle();
        const layout = event.layout || this.settingForm.value.companyLayout;
        if (layout) {
            this.branchColumns = this.getDefaultBranchColumns();
            this.updateBranchLiterals();
            const company = layout.includes('E');
            const unit = layout.includes('U');
            if (company) {
                this.branchColumns.push({ property: 'CompanyCode', label: this.literals.str0027, width: '100px' });
            }
            if (unit) {
                this.branchColumns.push({ property: 'UnitOfBusiness', label: this.literals.str0028, width: '100px' });
            }
            if ((unit || company) && layout.includes('F')) {
                this.branchColumns.push({ property: 'ParentCode', label: this.literals.str0012, width: '100px' });
            }
        }
    }
    /**
     * @description Método do ciclo de vida do Angular, esse método é chamado após o construtor da classe
     */
    ngOnInit() {
        this.showLoginMessage();
        this.canUseDarkTheme();
        this.showGoEmpFil = false;
        this.showMDIMenuInfo = false;
        this.showModules = this.useModules();
        this.isLoading = false;
        this.settingForm = this.buildForm();
        this.subs.sink = this.subscribeToResolver();
        this.logo = './assets/images/totvs/totvs.svg';
        this.secondaryLogo = './assets/images/totvs/totvs.svg';
        this.updateCnpjTitle();
    }
    /**
     * @description Responda depois que o Angular inicializar as visualizações do componente e as visualizações filhas ou a visualização que contém a diretiva.
     * utilizado aqui para setar o foco no componente de grupo de empresa na abertura da tela
     * e definir a variavel started para true do componente company
     */
    ngAfterViewInit() {
        this.darkSwitchValue = true;
        if (this.isTokenValid) {
            setTimeout(() => {
                this.proCompanyLookupComponent?.setCompanyFocus?.();
                this.proCompanyLookupComponent?.setStarted?.(true);
            }, 500);
        }
    }
    /**
     * @description Atribui configurações para o tema dark.
     */
    setDarkThemeConfiguration() {
        const name = this.poI18nPipe.transform(this.literals.str0031, [this.brand]);
        this.darkTheme = {
            name: name,
            type: { light: { ...ProThemeTotvsLight }, dark: { ...ProThemeTotvsDark } }
        };
    }
    ;
    /**
     * @description Atualiza o título da coluna de CNPJ da consulta de filiais conforme API
     */
    updateCnpjTitle() {
        let unsubscribe;
        unsubscribe = this.proTranslateStringService.getStrList('fwfilial').subscribe({
            next: (strs) => {
                if (strs && strs.str0010) {
                    this.cnpjTitle = strs.str0010;
                    if (this.literals) {
                        this.updateCnpjTitleColumn();
                    }
                }
            },
            complete: () => unsubscribe ? unsubscribe.unsubscribe() : null
        });
    }
    /**
     * @description Atualiza o título da coluna de CNPJ no objeto da coluna da interface já criada
     */
    updateCnpjTitleColumn() {
        //A prioridade é o valor da API, caso contrário, utiliza o valor de tradução local
        this.cnpjTitle = this.cnpjTitle || this.literals.str0026; // 'CNPJ'
        this.branchColumns[2].label = this.cnpjTitle;
    }
    /**
     * @description Atualiza a descrição do modulo selecionado
     */
    updateModuleDescription() {
        this.proSystemModuleService.getSystemModule(this.settingForm.get('environment_code').value).subscribe((systemModule) => {
            this.settingForm.get('environment_description').patchValue(systemModule.description);
        });
    }
    /**
     * @description Cria e retorna o dados de controle de formulário das configurações de login
     * @returns Retorna o FormGroup do formulário de dados de login
     */
    buildForm() {
        return this.formBuilder.group({
            base_date: [null, [Validators.required]],
            company_code: [null, [Validators.required]],
            company_description: [null, [Validators.required]],
            branch_code: [null, [Validators.required]],
            branch_description: [null, [Validators.required]],
            environment_code: [
                null,
                [this.moduleValidator.bind(this), Validators.required]
            ],
            environment_description: [null, [Validators.required]],
            role_code: [null, []],
            role_description: [null, []],
            mdi_menu_info: [false, []],
            go_emp_fil: [false, []],
            companyLayout: [null, []],
        });
    }
    moduleValidator(control) {
        if (!this.fixedModule && parseInt(control.value, 10) === 99) {
            return {
                configurador: this.literals.str0019
            };
        }
        else {
            return Validators.required(control);
        }
    }
    subscribeToResolver() {
        return this.route.data.subscribe(resultOfResolver => {
            this.validateResolverData(resultOfResolver);
        });
    }
    validateResolverData(resolveData) {
        if (resolveData.defaultsSettings) {
            this.sessionSettingsDefaults = resolveData.defaultsSettings;
            this.fixedModule =
                typeof resolveData.defaultsSettings.environment_when === 'undefined'
                    ? false
                    : !resolveData.defaultsSettings.environment_when;
            this.fixedRole = !resolveData.defaultsSettings.role_when;
            this.disableBackButton = resolveData.defaultsSettings.disable_back_button;
            this.showMDIMenuInfo = resolveData.defaultsSettings.show_mdi_menu_info;
            this.showGoEmpFil = resolveData.defaultsSettings.show_go_emp_fil;
            this.loadSettingForm();
        }
        if (resolveData.userInfo) {
            this.displayName = resolveData.userInfo.displayName;
        }
        if (!resolveData.userMfa) {
            this.isTokenValid = false;
            this.proSessionSettingsService.clearSettingsDefaults();
            this.router.navigate(['/login']);
        }
    }
    set sessionSettingsDefaults(defaults) {
        if (defaults.base_date) {
            defaults.base_date = this.convertDateforPoDatePicker(defaults.base_date);
        }
        else {
            defaults.base_date = new Date();
        }
        this._ProSessionSettingsDefaults = defaults;
    }
    get sessionSettingsDefaults() {
        return this._ProSessionSettingsDefaults;
    }
    convertDateforPoDatePicker(base_date) {
        let convertedDate = base_date;
        if (base_date && !(base_date instanceof Date)) {
            convertedDate = `${base_date}T00:00:00-02:00`;
        }
        return convertedDate;
    }
    loadSettingForm() {
        // Carrega o campo de empresa primeiro, pois ele é utilizado no campo de filial.
        this.settingForm
            .get('company_code')
            .patchValue(this.sessionSettingsDefaults.company_code);
        this.settingForm.patchValue(this.sessionSettingsDefaults);
        this.proCompanyService.company = {
            Code: this.sessionSettingsDefaults.company_code
        };
        this.proBranchService.branch = {
            Code: this.sessionSettingsDefaults.branch_code
        };
        this.proRoleService.role = {
            Code: this.sessionSettingsDefaults.role_code,
            Description: this.sessionSettingsDefaults.role_description
        };
    }
    onSessionSettingBack() {
        this.proSessionSettingsService.clearSettingsDefaults();
        this.router.navigate(['/login']);
    }
    onSessionSettingSubmit() {
        this.isLoading = true;
        of(true)
            .pipe(delay(100), tap(() => {
            if (this.settingForm.pending) {
                throw new Error();
            }
        }), retry(25), tap(() => {
            this.submitForm();
        }))
            .subscribe({
            error: () => {
                this.isLoading = false;
                this.onErrorSubmit(this.literals.str0024);
            }
        });
    }
    submitForm() {
        if (this.settingForm.valid) {
            this.subs.sink = this.saveSettings(this.settingForm).subscribe({
                next: () => {
                    this.messageService.changeLanguage(this.poI18nService.getShortLanguage());
                    this.router.navigate(['/home']);
                },
                error: () => {
                    this.onErrorSubmit();
                }
            });
        }
        else {
            this.onErrorSubmit(this.literals.str0019); // 'Formulário inválido'
        }
    }
    ngOnDestroy() {
        this.subs.unsubscribe();
        this.brandSubscription.unsubscribe();
    }
    onErrorSubmit(message) {
        this.isLoading = false;
        if (message) {
            this.messageService.showMessage(message, 2);
        }
        this.router.navigate(['/session-settings']);
    }
    saveSettings(form) {
        const newSession = {
            base_date: form.get('base_date').value,
            company_code: form.get('company_code').value,
            branch_code: form.get('branch_code').value,
            environment_code: form.get('environment_code').value,
            role_code: form.get('role_code').value,
            mdi_menu_info: form.get('mdi_menu_info').value,
            go_emp_fil: form.get('go_emp_fil').value
        };
        return this.proSessionSettingsService.saveSettingsDefaults(newSession);
    }
    setChannelAsHTTP(value) {
        this.useHTTP = value;
        this.changeServicesChannel();
    }
    isChannelHTTP() {
        return this.useHTTP;
    }
    /**
     * @description Atualiza o Canal de comunicação
     * dos serviços utilizados pelo componente
     * @returns void
     */
    changeServicesChannel() {
        this.proCompanyService.setChannelAsHTTP(this.useHTTP);
        this.proBranchService.setChannelAsHTTP(this.useHTTP);
        this.proTranslateStringService.setChannelAsHTTP(this.useHTTP);
        this.proSystemModuleService.setChannelAsHTTP(this.useHTTP);
    }
    /**
     * @description Atualiza as variaveis a partir da marca
     * ma3 na russia e protheus nas demais
     * @returns void
     */
    updateResourceByBrand() {
        if (this.brand == "MA3") {
            this.logo = './assets/images/nationalplatform/nationalplatform.svg';
            this.secondaryLogo = './assets/images/nationalplatform/nationalplatform.svg';
            this.productName = 'Ma-3 Line';
        }
        else {
            this.logo = './assets/images/totvs/totvs.svg';
            this.secondaryLogo = './assets/images/totvs/totvs.svg';
            this.productName = this.literals.str0001;
        }
    }
    /**
     * @description atualiza a variavel productName.
     * quando não for MA3 precisa atualziar com a literals cada vez que muda o idioma
     * @returns void
     */
    updateProductName() {
        if (this.brand != "MA3") {
            this.productName = this.literals.str0001;
        }
    }
    /**
     * @description atualiza a variavel de marca
     * @returns void
     */
    updateBrand() {
        this.proBrandService.setChannelAsHTTP(environment.useHTTP);
        this.brandSubscription = this.proBrandService.getERPBrand()
            .pipe(finalize(() => {
            this.setDarkThemeConfiguration();
            this.updateResourceByBrand();
        }))
            .subscribe({
            next: (brand) => this.brand = brand,
            error: () => this.brand = 'TOTVS'
        });
    }
    /**
     * @description atualiza o formato de data do po-datepicker
     * @param language string codigo do idioma.
     * @returns void
     */
    updateDateFormat(language) {
        this.proDateService.getDateFormat(language).pipe(take(1)).subscribe({
            next: (dateFormat) => this.dateFormat = dateFormat,
            error: () => this.dateFormat = 'dd/mm/yyyy'
        });
    }
    /**
     * @description Retorna ícone a ser utilizado no botão de ativar/desativar o dark.
     * @returns string
     */
    getDarkSwitchClass() {
        if (this.isLoadingDark) {
            return 'an an-circle-notch session-dark-icon';
        }
        else {
            return this.darkSwitchValue ? 'an an-moon session-dark-icon' : 'an an-sun session-dark-icon';
        }
    }
    /**
     * @description Retorna o texto de apoio a ser utilizado no botão de ativar/desativar o dark.
     * @returns string
     */
    getDarkTooltipValue() {
        return this.darkSwitchValue ? this.literals.str0030 : this.literals.str0029;
    }
    /**
     * @description Executa ação ao ativar/desativar o dark.
     * @param value boolean
     */
    onChangeDarkSwitchValue(value) {
        this.isLoadingDark = true;
        this.darkSwitchValue = value;
        this.proThemeService.setThemeProfile(value ? 'true' : 'false')
            .pipe(finalize(() => this.isLoadingDark = false))
            .subscribe({
            next: () => {
                if (value) {
                    this.proThemeService.setTheme({ ...this.darkTheme }, PoThemeTypeEnum.dark);
                }
                else {
                    this.proThemeService.setTheme();
                }
                ;
            }
        });
    }
    /**
     * @description Consulta se mostra ou não o botão de ativar/desativar o dark.
     */
    canUseDarkTheme() {
        this.isLoadingDark = true;
        this.proThemeService.canUseDarkTheme().pipe(tap((isDarkAllowed) => this.isDarkAllowed = isDarkAllowed), switchMap$1((isDarkAllowed) => this.getProfileValue(isDarkAllowed))).pipe(finalize(() => this.isLoadingDark = false)).subscribe({
            next: (isDarkEnabled) => {
                this.darkSwitchValue = isDarkEnabled;
                if (isDarkEnabled) {
                    this.proThemeService.setTheme({ ...this.darkTheme }, PoThemeTypeEnum.dark);
                }
                else {
                    this.proThemeService.setTheme();
                }
                ;
            }
        });
    }
    /**
     * @description Consulta valor do profile para saber se usuário está com o dark habilitado.
     * @param isDarkAllowed boolean, indica se o usuário pode ativar/desativar o dark.
     * @returns Observable de string
     */
    getProfileValue(isDarkAllowed) {
        if (isDarkAllowed) {
            return this.proThemeService.getThemeProfile();
        }
        else {
            return of(false);
        }
        ;
    }
    ;
    /**
     * @description
     * Notificar o usuário que a autenticação foi bem sucessidade. Utilizada em casos que a página de Autenticação é igorada
     */
    showLoginMessage() {
        this.proAuthService.showLoginMessage();
    }
    /**
     * @description
     * Indica se será apresentado o combo de módulo na tela de contexto.
     */
    useModules() {
        const dataNewHome = sessionStorage.getItem('ProNewHome');
        const dataProgram = sessionStorage.getItem('ProStartProgram');
        if (!dataNewHome || !dataProgram) {
            return true;
        }
        const newHome = JSON.parse(dataNewHome).newHome;
        const startProgram = JSON.parse(dataProgram).startProgram;
        const programUseModule = startProgram !== 'SIGAMDI' && startProgram !== 'SIGAADV';
        return newHome === "false" || programUseModule;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsComponent, deps: [{ token: i2.UntypedFormBuilder }, { token: i2$1.Router }, { token: ProMessageService }, { token: i2$1.ActivatedRoute }, { token: ProSessionSettingsService }, { token: ProCompanyService }, { token: ProRoleService }, { token: ProBranchService }, { token: i3.PoI18nService }, { token: ProTranslateStringService }, { token: ProBrandService }, { token: ProSystemModuleService }, { token: ProThemeService }, { token: ProDateService }, { token: ProAuthService }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.9", type: ProSessionSettingsComponent, isStandalone: false, selector: "pro-session-settings", inputs: { environment: ["p-environment", "environment"], background: ["p-background", "background"], hideLogo: ["p-hide-logo", "hideLogo"], highlightInfo: ["p-highlight-info", "highlightInfo"] }, viewQueries: [{ propertyName: "proBranchLookupComponent", first: true, predicate: ProBranchLookupComponent, descendants: true }, { propertyName: "proCompanyLookupComponent", first: true, predicate: ProCompanyLookupComponent, descendants: true }], ngImport: i0, template: "<div>\r\n  <button\r\n    class=\"po-page-login-support\"\r\n    (click)=\"activateSupport()\"\r\n    [hidden]=\"!literals?.str0004\"\r\n  >\r\n    <span class=\"po-icon an an-question\"></span>\r\n    {{ literals?.str0004 }}\r\n    <!-- Suporte -->\r\n  </button>\r\n\r\n  @if (isDarkAllowed) {\r\n    <div class=\"session-dark-switch\">\r\n      <span [ngClass]=\"getDarkSwitchClass()\"></span>\r\n      <po-switch\r\n        [p-tooltip]=\"getDarkTooltipValue()\"\r\n        p-tooltip-position=\"bottom-left\"\r\n        [p-value]=\"darkSwitchValue\"\r\n        (p-change)=\"onChangeDarkSwitchValue($event)\"\r\n        [p-disabled]=\"isLoadingDark\"\r\n        [p-hide-label-status]=\"true\"\r\n      />\r\n    </div>\r\n  }\r\n</div>\r\n\r\n@if (isTokenValid) {\r\n  <pro-page-background\r\n    p-show-select-language\r\n    [p-background]=\"background\"\r\n    [p-highlight-info]=\"highlightInfo\"\r\n    [p-logo]=\"logo\"\r\n    [p-secondary-logo]=\"secondaryLogo\"\r\n    (p-selected-language)=\"onSelectedLanguage($event)\"\r\n  >\r\n    <header class=\"po-page-login-header\">\r\n      <div class=\"session-display-top session-display-bot\">\r\n        <div class=\"po-page-login-header-product-name\">\r\n          <h1>{{ productName }}</h1>\r\n          <!-- Linha Protheus -->\r\n        </div>\r\n        @if (environment) {\r\n          <po-tag p-type=\"warning\" [p-value]=\"environment\"> </po-tag>\r\n        }\r\n      </div>\r\n      <div class=\"po-page-login-header-welcome session-display-bot\">\r\n        {{\r\n          displayName\r\n            ? (literals?.str0009 | poI18n: [displayName])\r\n            : literals?.str0006\r\n        }}<!-- Boas-vindas, {0}. --><!-- Carregando... -->\r\n      </div>\r\n    </header>\r\n    <form class=\"session-settings-form\" [formGroup]=\"settingForm\">\r\n      <div class=\"po-row\">\r\n        <div\r\n          class=\"po-md-12 po-lg-12 po-xl-12 po-page-login-info-container session-date-container\"\r\n        >\r\n          <po-datepicker\r\n            class=\"po-md-7 po-lg-7 po-xl-7\"\r\n            name=\"base_date\"\r\n            formControlName=\"base_date\"\r\n            p-clean\r\n            [p-format]=\"dateFormat\"\r\n            [p-label]=\"literals?.str0018\"\r\n            p-required\r\n          ></po-datepicker\r\n          ><!-- Data base -->\r\n          <div class=\"po-page-login-info-icon-container session-hint-div\">\r\n            <span\r\n              class=\"po-icon po-field-icon po-icon-info\"\r\n              [p-tooltip]=\"literals?.str0002\"\r\n              p-tooltip-position=\"right\"\r\n              ><!-- Escolha a data base do sistema. -->\r\n            </span>\r\n          </div>\r\n        </div>\r\n        <pro-company-lookup\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n          [p-label]=\"literals?.str0010\"\r\n          [p-hint]=\"literals?.str0011\"\r\n          [pro-columns]=\"companyColumns\"\r\n          (companySetted)=\"changeBranchColumns($event)\"\r\n          (branchSetted)=\"branchSettedEvent()\"\r\n        ></pro-company-lookup\r\n        ><!-- Grupo --><!-- Selecione o Grupo de Empresas. -->\r\n        <pro-branch-lookup\r\n          [p-label]=\"literals?.str0012\"\r\n          [p-hint]=\"literals?.str0013\"\r\n          [pro-columns]=\"branchColumns\"\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n          ><!-- Filial --><!-- Selecione a Filial. -->\r\n        </pro-branch-lookup>\r\n        @if (showModules) {\r\n          <pro-system-module-lookup\r\n            [p-label]=\"literals?.str0014\"\r\n            [p-disabled]=\"fixedModule\"\r\n            [p-hint]=\"literals?.str0015\"\r\n            [pro-columns]=\"moduleColumns\"\r\n            class=\"po-md-12\"\r\n            [parent]=\"settingForm\"\r\n            ><!-- Ambiente --><!-- Selecione o m\u00F3dulo do sistema. -->\r\n          </pro-system-module-lookup>\r\n        }\r\n        <pro-role-lookup\r\n          [p-label]=\"literals?.str0016\"\r\n          [p-disabled]=\"fixedRole\"\r\n          [p-hint]=\"literals?.str0017\"\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n        ></pro-role-lookup\r\n        ><!-- Papel de trabalho --><!-- Selecione um Papel de trabalho. -->\r\n        @if (showGoEmpFil) {\r\n          <div class=\"session-reminder-container\">\r\n            <po-switch\r\n              class=\"session-remider-switch\"\r\n              name=\"mdi_menu_info\"\r\n              formControlName=\"mdi_menu_info\"\r\n              p-label=\" \"\r\n              [p-label-off]=\"literals?.str0005\"\r\n              [p-label-on]=\"literals?.str0005\"\r\n            ></po-switch\r\n            ><!-- Usar as informa\u00E7\u00F5es acima em todas as sess\u00F5es. -->\r\n          </div>\r\n        }\r\n        @if (showMDIMenuInfo) {\r\n          <div class=\"session-reminder-container\">\r\n            <po-switch\r\n              class=\"session-remider-switch\"\r\n              name=\"go_emp_fil\"\r\n              formControlName=\"go_emp_fil\"\r\n              p-label=\" \"\r\n              [p-label-off]=\"literals?.str0023\"\r\n              [p-label-on]=\"literals?.str0023\"\r\n            ></po-switch\r\n            ><!-- Iniciar com as informa\u00E7\u00F5es da \u00FAltima sess\u00E3o. -->\r\n            <span\r\n              class=\"po-icon po-field-icon po-icon-info session-reminder-tooltip\"\r\n              [p-tooltip]=\"literals?.str0003\"\r\n              p-tooltip-position=\"right\"\r\n              ><!-- Voc\u00EA pode desabilitar essa op\u00E7\u00E3o no menu do sistema. -->\r\n            </span>\r\n          </div>\r\n        }\r\n\r\n        <div\r\n          class=\"po-md-12 po-page-login-info-container session-settings-buttons\"\r\n        >\r\n          <po-button\r\n            class=\"po-md-6\"\r\n            name=\"back\"\r\n            [p-disabled]=\"isLoading || disableBackButton\"\r\n            [p-label]=\"literals?.str0008\"\r\n            (p-click)=\"onSessionSettingBack()\"\r\n            ><!-- Voltar -->\r\n          </po-button>\r\n          <po-button\r\n            class=\"po-md-6 session-settings-button-enter\"\r\n            name=\"submmit\"\r\n            p-kind=\"primary\"\r\n            [p-disabled]=\"\r\n              !(\r\n                this.settingForm.get('company_code').value &&\r\n                this.settingForm.get('branch_code').value &&\r\n                this.settingForm.get('environment_code').value\r\n              )\r\n            \"\r\n            [p-label]=\"isLoading ? literals?.str0006 : literals?.str0007\"\r\n            [p-loading]=\"isLoading\"\r\n            (p-click)=\"onSessionSettingSubmit()\"\r\n            ><!-- Carregando... --><!-- Entrar -->\r\n          </po-button>\r\n          <div\r\n            class=\"po-page-login-info-icon-container session-empty-div\"\r\n          ></div>\r\n        </div>\r\n      </div>\r\n    </form>\r\n  </pro-page-background>\r\n}\r\n", styles: [".session-hint-div{padding:37px 0 0}.session-empty-div{width:30px}.session-info-diff{width:191px}.session-date-container{display:inline-block}.session-reminder-container{padding:0 16px;display:flex;margin-top:0}.session-reminder-tooltip{padding:27px 0 0 20px}.session-display-top{padding-top:3%}.session-display-bot{padding-bottom:2.2%}.session-settings-buttons{padding-top:10px}.session-dark-switch{position:absolute;z-index:1;right:24px;top:120px;text-align:center;display:flex;flex-direction:row;justify-content:space-evenly;align-items:center;width:92px}.session-dark-icon{margin-right:10px;font-size:22px}@media(min-width:1367px){.session-empty-div{width:33px}.session-info-diff{width:187px}}@media(min-width:768px){.session-settings-form{padding-top:0}}@media(max-width:480px){.session-settings-button-enter{padding-top:15px}}\n"], dependencies: [{ kind: "directive", type: i3$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i3.PoButtonComponent, selector: "po-button" }, { kind: "component", type: i3.PoDatepickerComponent, selector: "po-datepicker", inputs: ["p-label", "p-help"] }, { kind: "component", type: i3.PoSwitchComponent, selector: "po-switch", inputs: ["p-value", "p-format-model", "p-hide-label-status", "p-label-position", "p-label-off", "p-label-on", "p-field-error-message", "p-error-limit", "p-invalid-value", "p-size", "p-helper", "p-label-text-wrap"] }, { kind: "component", type: i3.PoTagComponent, selector: "po-tag" }, { kind: "component", type: ProPageBackgroundComponent, selector: "pro-page-background", inputs: ["p-background", "p-hide-logo", "p-highlight-info", "p-logo", "p-secondary-logo", "p-show-select-language"], outputs: ["p-selected-language"] }, { kind: "directive", type: i3.PoTooltipDirective, selector: "[p-tooltip]" }, { kind: "component", type: ProCompanyLookupComponent, selector: "pro-company-lookup", inputs: ["parent", "p-label", "p-hint", "pro-columns"], outputs: ["companySetted", "branchSetted"] }, { kind: "component", type: ProBranchLookupComponent, selector: "pro-branch-lookup", inputs: ["parent", "p-label", "p-hint", "pro-columns"], outputs: ["branchSetted"] }, { kind: "component", type: ProRoleLookupComponent, selector: "pro-role-lookup", inputs: ["parent", "p-label", "p-hint", "pro-columns", "p-disabled"], outputs: ["roleSetted"] }, { kind: "component", type: ProSystemModuleLookupComponent, selector: "pro-system-module-lookup", inputs: ["parent", "p-label", "p-disabled", "p-hint", "pro-columns"], outputs: ["systeModuleSetted"] }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "pipe", type: i3.PoI18nPipe, name: "poI18n" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-session-settings', standalone: false, template: "<div>\r\n  <button\r\n    class=\"po-page-login-support\"\r\n    (click)=\"activateSupport()\"\r\n    [hidden]=\"!literals?.str0004\"\r\n  >\r\n    <span class=\"po-icon an an-question\"></span>\r\n    {{ literals?.str0004 }}\r\n    <!-- Suporte -->\r\n  </button>\r\n\r\n  @if (isDarkAllowed) {\r\n    <div class=\"session-dark-switch\">\r\n      <span [ngClass]=\"getDarkSwitchClass()\"></span>\r\n      <po-switch\r\n        [p-tooltip]=\"getDarkTooltipValue()\"\r\n        p-tooltip-position=\"bottom-left\"\r\n        [p-value]=\"darkSwitchValue\"\r\n        (p-change)=\"onChangeDarkSwitchValue($event)\"\r\n        [p-disabled]=\"isLoadingDark\"\r\n        [p-hide-label-status]=\"true\"\r\n      />\r\n    </div>\r\n  }\r\n</div>\r\n\r\n@if (isTokenValid) {\r\n  <pro-page-background\r\n    p-show-select-language\r\n    [p-background]=\"background\"\r\n    [p-highlight-info]=\"highlightInfo\"\r\n    [p-logo]=\"logo\"\r\n    [p-secondary-logo]=\"secondaryLogo\"\r\n    (p-selected-language)=\"onSelectedLanguage($event)\"\r\n  >\r\n    <header class=\"po-page-login-header\">\r\n      <div class=\"session-display-top session-display-bot\">\r\n        <div class=\"po-page-login-header-product-name\">\r\n          <h1>{{ productName }}</h1>\r\n          <!-- Linha Protheus -->\r\n        </div>\r\n        @if (environment) {\r\n          <po-tag p-type=\"warning\" [p-value]=\"environment\"> </po-tag>\r\n        }\r\n      </div>\r\n      <div class=\"po-page-login-header-welcome session-display-bot\">\r\n        {{\r\n          displayName\r\n            ? (literals?.str0009 | poI18n: [displayName])\r\n            : literals?.str0006\r\n        }}<!-- Boas-vindas, {0}. --><!-- Carregando... -->\r\n      </div>\r\n    </header>\r\n    <form class=\"session-settings-form\" [formGroup]=\"settingForm\">\r\n      <div class=\"po-row\">\r\n        <div\r\n          class=\"po-md-12 po-lg-12 po-xl-12 po-page-login-info-container session-date-container\"\r\n        >\r\n          <po-datepicker\r\n            class=\"po-md-7 po-lg-7 po-xl-7\"\r\n            name=\"base_date\"\r\n            formControlName=\"base_date\"\r\n            p-clean\r\n            [p-format]=\"dateFormat\"\r\n            [p-label]=\"literals?.str0018\"\r\n            p-required\r\n          ></po-datepicker\r\n          ><!-- Data base -->\r\n          <div class=\"po-page-login-info-icon-container session-hint-div\">\r\n            <span\r\n              class=\"po-icon po-field-icon po-icon-info\"\r\n              [p-tooltip]=\"literals?.str0002\"\r\n              p-tooltip-position=\"right\"\r\n              ><!-- Escolha a data base do sistema. -->\r\n            </span>\r\n          </div>\r\n        </div>\r\n        <pro-company-lookup\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n          [p-label]=\"literals?.str0010\"\r\n          [p-hint]=\"literals?.str0011\"\r\n          [pro-columns]=\"companyColumns\"\r\n          (companySetted)=\"changeBranchColumns($event)\"\r\n          (branchSetted)=\"branchSettedEvent()\"\r\n        ></pro-company-lookup\r\n        ><!-- Grupo --><!-- Selecione o Grupo de Empresas. -->\r\n        <pro-branch-lookup\r\n          [p-label]=\"literals?.str0012\"\r\n          [p-hint]=\"literals?.str0013\"\r\n          [pro-columns]=\"branchColumns\"\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n          ><!-- Filial --><!-- Selecione a Filial. -->\r\n        </pro-branch-lookup>\r\n        @if (showModules) {\r\n          <pro-system-module-lookup\r\n            [p-label]=\"literals?.str0014\"\r\n            [p-disabled]=\"fixedModule\"\r\n            [p-hint]=\"literals?.str0015\"\r\n            [pro-columns]=\"moduleColumns\"\r\n            class=\"po-md-12\"\r\n            [parent]=\"settingForm\"\r\n            ><!-- Ambiente --><!-- Selecione o m\u00F3dulo do sistema. -->\r\n          </pro-system-module-lookup>\r\n        }\r\n        <pro-role-lookup\r\n          [p-label]=\"literals?.str0016\"\r\n          [p-disabled]=\"fixedRole\"\r\n          [p-hint]=\"literals?.str0017\"\r\n          class=\"po-md-12\"\r\n          [parent]=\"settingForm\"\r\n        ></pro-role-lookup\r\n        ><!-- Papel de trabalho --><!-- Selecione um Papel de trabalho. -->\r\n        @if (showGoEmpFil) {\r\n          <div class=\"session-reminder-container\">\r\n            <po-switch\r\n              class=\"session-remider-switch\"\r\n              name=\"mdi_menu_info\"\r\n              formControlName=\"mdi_menu_info\"\r\n              p-label=\" \"\r\n              [p-label-off]=\"literals?.str0005\"\r\n              [p-label-on]=\"literals?.str0005\"\r\n            ></po-switch\r\n            ><!-- Usar as informa\u00E7\u00F5es acima em todas as sess\u00F5es. -->\r\n          </div>\r\n        }\r\n        @if (showMDIMenuInfo) {\r\n          <div class=\"session-reminder-container\">\r\n            <po-switch\r\n              class=\"session-remider-switch\"\r\n              name=\"go_emp_fil\"\r\n              formControlName=\"go_emp_fil\"\r\n              p-label=\" \"\r\n              [p-label-off]=\"literals?.str0023\"\r\n              [p-label-on]=\"literals?.str0023\"\r\n            ></po-switch\r\n            ><!-- Iniciar com as informa\u00E7\u00F5es da \u00FAltima sess\u00E3o. -->\r\n            <span\r\n              class=\"po-icon po-field-icon po-icon-info session-reminder-tooltip\"\r\n              [p-tooltip]=\"literals?.str0003\"\r\n              p-tooltip-position=\"right\"\r\n              ><!-- Voc\u00EA pode desabilitar essa op\u00E7\u00E3o no menu do sistema. -->\r\n            </span>\r\n          </div>\r\n        }\r\n\r\n        <div\r\n          class=\"po-md-12 po-page-login-info-container session-settings-buttons\"\r\n        >\r\n          <po-button\r\n            class=\"po-md-6\"\r\n            name=\"back\"\r\n            [p-disabled]=\"isLoading || disableBackButton\"\r\n            [p-label]=\"literals?.str0008\"\r\n            (p-click)=\"onSessionSettingBack()\"\r\n            ><!-- Voltar -->\r\n          </po-button>\r\n          <po-button\r\n            class=\"po-md-6 session-settings-button-enter\"\r\n            name=\"submmit\"\r\n            p-kind=\"primary\"\r\n            [p-disabled]=\"\r\n              !(\r\n                this.settingForm.get('company_code').value &&\r\n                this.settingForm.get('branch_code').value &&\r\n                this.settingForm.get('environment_code').value\r\n              )\r\n            \"\r\n            [p-label]=\"isLoading ? literals?.str0006 : literals?.str0007\"\r\n            [p-loading]=\"isLoading\"\r\n            (p-click)=\"onSessionSettingSubmit()\"\r\n            ><!-- Carregando... --><!-- Entrar -->\r\n          </po-button>\r\n          <div\r\n            class=\"po-page-login-info-icon-container session-empty-div\"\r\n          ></div>\r\n        </div>\r\n      </div>\r\n    </form>\r\n  </pro-page-background>\r\n}\r\n", styles: [".session-hint-div{padding:37px 0 0}.session-empty-div{width:30px}.session-info-diff{width:191px}.session-date-container{display:inline-block}.session-reminder-container{padding:0 16px;display:flex;margin-top:0}.session-reminder-tooltip{padding:27px 0 0 20px}.session-display-top{padding-top:3%}.session-display-bot{padding-bottom:2.2%}.session-settings-buttons{padding-top:10px}.session-dark-switch{position:absolute;z-index:1;right:24px;top:120px;text-align:center;display:flex;flex-direction:row;justify-content:space-evenly;align-items:center;width:92px}.session-dark-icon{margin-right:10px;font-size:22px}@media(min-width:1367px){.session-empty-div{width:33px}.session-info-diff{width:187px}}@media(min-width:768px){.session-settings-form{padding-top:0}}@media(max-width:480px){.session-settings-button-enter{padding-top:15px}}\n"] }]
        }], ctorParameters: () => [{ type: i2.UntypedFormBuilder }, { type: i2$1.Router }, { type: ProMessageService }, { type: i2$1.ActivatedRoute }, { type: ProSessionSettingsService }, { type: ProCompanyService }, { type: ProRoleService }, { type: ProBranchService }, { type: i3.PoI18nService }, { type: ProTranslateStringService }, { type: ProBrandService }, { type: ProSystemModuleService }, { type: ProThemeService }, { type: ProDateService }, { type: ProAuthService }, { type: ProJsToAdvplService }], propDecorators: { environment: [{
                type: Input,
                args: ['p-environment']
            }], background: [{
                type: Input,
                args: ['p-background']
            }], hideLogo: [{
                type: Input,
                args: ['p-hide-logo']
            }], highlightInfo: [{
                type: Input,
                args: ['p-highlight-info']
            }], proBranchLookupComponent: [{
                type: ViewChild,
                args: [ProBranchLookupComponent]
            }], proCompanyLookupComponent: [{
                type: ViewChild,
                args: [ProCompanyLookupComponent]
            }] } });

/**
 * @description
 *
 * Módulo do template do pro-page-background.
 */
class ProPageBackgroundModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundModule, declarations: [ProPageBackgroundComponent], imports: [CommonModule,
            FormsModule,
            RouterModule,
            PoDividerModule,
            PoFieldModule], exports: [ProPageBackgroundComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundModule, imports: [CommonModule,
            FormsModule,
            RouterModule,
            PoDividerModule,
            PoFieldModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPageBackgroundModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        RouterModule,
                        PoDividerModule,
                        PoFieldModule
                    ],
                    declarations: [ProPageBackgroundComponent],
                    exports: [ProPageBackgroundComponent]
                }]
        }] });

class ProSessionSettingsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsModule, declarations: [ProSessionSettingsComponent], imports: [CommonModule,
            PoButtonModule,
            PoFieldModule,
            ProPageBackgroundModule,
            PoModule,
            PoTagModule,
            PoTooltipModule,
            ProFieldsModule,
            ReactiveFormsModule], exports: [ProSessionSettingsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsModule, imports: [CommonModule,
            PoButtonModule,
            PoFieldModule,
            ProPageBackgroundModule,
            PoModule,
            PoTagModule,
            PoTooltipModule,
            ProFieldsModule,
            ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProSessionSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PoButtonModule,
                        PoFieldModule,
                        ProPageBackgroundModule,
                        PoModule,
                        PoTagModule,
                        PoTooltipModule,
                        ProFieldsModule,
                        ReactiveFormsModule
                    ],
                    declarations: [ProSessionSettingsComponent],
                    exports: [ProSessionSettingsComponent]
                }]
        }] });

class ProLoginComponent {
    set nextRoute(value) {
        this._nextRoute = value;
    }
    get nextRoute() {
        return this._nextRoute ? this._nextRoute : '/session-settings';
    }
    constructor(router, route, authService, messageService, poI18nService, elRef, proLanguageService, proBrandService, proMfaService, proSessionSettingsService, proJsToAdvplService) {
        this.router = router;
        this.route = route;
        this.authService = authService;
        this.messageService = messageService;
        this.poI18nService = poI18nService;
        this.elRef = elRef;
        this.proLanguageService = proLanguageService;
        this.proBrandService = proBrandService;
        this.proMfaService = proMfaService;
        this.proSessionSettingsService = proSessionSettingsService;
        this.proJsToAdvplService = proJsToAdvplService;
        this.subs = new SubSink();
        this.languages = [];
        this.logo = '';
        this.productName = '';
        blockBackAction('', 'login', this.proJsToAdvplService);
        this.updateLangs();
        const language = poI18nService.getShortLanguage();
        poI18nService
            .getLiterals({ language, context: 'login' })
            .subscribe((literals) => {
            this.updLiterals(literals);
            this.updateBrand();
        });
        this.messageService.changeLanguage(language);
    }
    ngOnInit() {
        this.authService.logout();
        this.isLoading = false;
        this.subs.add(this.subscribeToResolver());
        this.proSessionSettingsService.clearSettingsDefaults();
    }
    ngAfterViewInit() {
        this.setFocusToInput(this.inputFocus);
    }
    setFocusToInput(name) {
        const input = this.elRef.nativeElement.querySelector('input[name="' + name + '"]');
        if (input) {
            setTimeout(() => input.focus(), 100);
        }
    }
    subscribeToResolver() {
        return this.route.data.subscribe((resultOfResolver) => {
            this.validateResolverData(resultOfResolver);
        });
    }
    /**
     * @description Metodo que realiza o login no protheus
     * @returns Subscription
     */
    subscribeToLogin(user) {
        let redirect;
        let hasMfa;
        return this.authService
            .login(user)
            .pipe(catchError$1((error) => {
            this.errorLogin(error);
            return error;
        }), tap$1((auth) => {
            redirect = this.authService.redirectUrl
                ? this.authService.redirectUrl
                : this.nextRoute;
            hasMfa = auth.hasMFA;
            this.proMfaService.setHasMFA(auth.hasMFA);
        }), concatMap(() => {
            return this.proMfaService.isSIGACFG();
        }))
            .subscribe({
            next: (isSIGACFG) => {
                this.proMfaService.setIsSigaCfg(isSIGACFG);
                if (!isSIGACFG) {
                    // Se tem MFA mas está no SIGACFG, não deve solicitar o MFA
                    if (hasMfa) {
                        redirect = `/pro-mfa${redirect}/login`;
                    }
                }
                this.resetLoading(this.router.navigate([redirect]));
            },
            error: (error) => {
                this.errorLogin(error);
            },
        });
    }
    /**
     * @description metodo que efetua o tratamento de erros.
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    errorLogin(error) {
        this.isLoading = false;
        this.messageService.showOneMessage(this.parseErrorMessage(error));
        this.router.navigate(['/login']);
    }
    resetLoading(navigatePromise) {
        if (navigatePromise) {
            navigatePromise
                .then(() => {
                this.isLoading = false;
            })
                .catch((error) => {
                console.error(error);
                this.isLoading = false;
            });
        }
    }
    validateResolverData(resolveData) {
        if (resolveData.defaultsLogin) {
            this.userDefaults = resolveData.defaultsLogin;
            this.hideRememberUser =
                !resolveData.defaultsLogin.showBindUserToSO ||
                    resolveData.defaultsLogin.singleSignOnRequired;
            this.loginValue = resolveData.defaultsLogin.cGetUser;
            this.inputFocus = resolveData.defaultsLogin.setFocus;
        }
    }
    set userDefaults(defaults) {
        this._ProUserDefaults = defaults;
    }
    get userDefaults() {
        return this._ProUserDefaults;
    }
    onLoginSubmit(formData) {
        const user = {
            username: formData.login,
            password: formData.password,
            remember_user: formData.rememberUser || this.userDefaults.singleSignOnRequired,
        };
        this.login(user);
    }
    /**
     * @description metodo chamado na mudança do combox de idioma da tela de login
     * @param language opção de idioma escolhido pelo usuário
     * @returns void
     */
    onLanguageChange({ language }) {
        this.poI18nService.setLanguage(language, false);
        this.poI18nService
            .getLiterals({ language, context: 'login' })
            .subscribe((literals) => {
            this.updLiterals(literals);
            this.updateProductName();
        });
        this.messageService.changeLanguage(language);
    }
    /**
     * @description Métodode atualização das traduções
     * @param objeto das traduções
     */
    updLiterals(literals) {
        this.literals = {
            str0001: literals.str0001,
            str0002: literals.str0002,
            str0003: literals.str0003,
            str0004: literals.str0004,
            loginLabel: literals.str0005,
            loginPlaceholder: literals.str0006,
            passwordLabel: literals.str0007,
            loginHint: literals.str0008,
            rememberUserHint: literals.str0009,
            passwordPlaceholder: '',
            str0010: literals.str0010,
        };
    }
    onLoginChange(login) {
        this.loginValue = login;
    }
    callRecoverPassword() {
        this.authService.passwordRecovery(this.loginValue);
    }
    /**
     * @description Método para obter o link de suporte e abrir em nova guia
     */
    supportLink(language = this.poI18nService.getShortLanguage()) {
        let supportLink = 'http://suporte.totvs.com/';
        if (this.brand == 'MA3') {
            supportLink =
                language === 'en'
                    ? 'https://www.national-platform.com/'
                    : 'https://www.national-platform.ru/';
        }
        else {
            if (language === 'es') {
                supportLink = 'https://totvscst.zendesk.com/hc/es#home';
            }
            else if (language === 'en') {
                supportLink = 'https://totvscst.zendesk.com/hc/en-us#home';
            }
        }
        window.open(supportLink, '_blank');
    }
    login(user) {
        if (this.isLoading) {
            return;
        }
        this.isLoading = true;
        this.subs.add(this.subscribeToLogin(user));
    }
    parseErrorMessage(error) {
        switch (error.status) {
            case 401:
                return this.literals.str0002; // 'Usuário ou senha inválida.'
            case 0:
                return this.literals.str0003; // 'Não foi possível estabelecer conexão com o servidor.';
            default:
                if (error.error && error.error.errorMessage) {
                    return this.literals.str0004 + ': ' + error.error.errorMessage; // 'Ocorreu um problema na tentativa de Login';
                }
                else {
                    return this.literals.str0004 + '.'; // 'Ocorreu um problema na tentativa de Login';
                }
        }
    }
    /**
     * @description Atualiza os idiomas disponíveis
     */
    updateLangs() {
        this.proLanguageService.setChannelAsHTTP(environment.useHTTP);
        this.proLanguageService.getListOfLanguages().subscribe({
            next: (langs) => {
                this.languages = langs;
            },
            error: (error) => {
                console.error(error);
            },
        });
    }
    /**
     * @description Atualiza as variaveis a partir da marca
     * ma3 na russia e protheus nas demais
     * @returns void
     */
    updateResourceByBrand() {
        if (this.brand == 'MA3') {
            this.logo = './assets/images/nationalplatform/nationalplatform.svg';
            this.productName = 'Ma-3 Line';
        }
        else {
            this.logo = './assets/images/totvs/totvs.svg';
            this.productName = this.literals.str0001;
        }
    }
    /**
     * @description atualiza a variavel productName.
     * quando não for MA3 precisa atualziar com a literals cada vez que muda o idioma
     * @returns void
     */
    updateProductName() {
        if (this.brand != 'MA3') {
            this.productName = this.literals.str0001;
        }
    }
    /**
     * @description atualiza a variavel de marca
     * @returns void
     */
    updateBrand() {
        this.proBrandService.setChannelAsHTTP(environment.useHTTP);
        this.proBrandService.getERPBrand().subscribe({
            next: (brand) => {
                this.brand = brand;
                this.updateResourceByBrand();
            },
            error: (error) => {
                this.brand = 'TOTVS';
                this.updateResourceByBrand();
            },
        });
    }
    ngOnDestroy() {
        this.subs.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginComponent, deps: [{ token: i2$1.Router }, { token: i2$1.ActivatedRoute }, { token: ProAuthService }, { token: ProMessageService }, { token: i3.PoI18nService }, { token: i0.ElementRef }, { token: ProLanguageService }, { token: ProBrandService }, { token: ProMfaService }, { token: ProSessionSettingsService }, { token: ProJsToAdvplService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.9", type: ProLoginComponent, isStandalone: false, selector: "pro-login", inputs: { nextRoute: ["pro-next-route", "nextRoute"] }, ngImport: i0, template: "<button\r\n  class=\"po-page-login-support\"\r\n  (click)=\"supportLink()\"\r\n  [hidden]=\"!literals?.str0010\"\r\n>\r\n  <span class=\"po-icon an an-question\"></span>\r\n  {{ literals?.str0010 }}\r\n  <!-- Suporte -->\r\n</button>\r\n\r\n <po-page-login\r\n  [p-hide-remember-user]=\"hideRememberUser\"\r\n  (p-login-submit)=\"onLoginSubmit($event)\"\r\n  (p-login-change)=\"onLoginChange($event)\"\r\n  [p-languages]=\"languages\"\r\n  (p-language-change)=\"onLanguageChange($event)\"\r\n  [p-login]=\"loginValue\"\r\n  [p-loading]=\"isLoading\"\r\n  [p-literals]=\"literals\"\r\n  [p-product-name]=\"productName\"\r\n  [p-recovery]=\"this.callRecoverPassword.bind(this)\"\r\n  [p-logo]=\"logo\"\r\n  [p-secondary-logo]=\"logo\" />\r\n  <!-- Linha Protheus -->\r\n", styles: [""], dependencies: [{ kind: "component", type: i10.PoPageLoginComponent, selector: "po-page-login" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pro-login', standalone: false, template: "<button\r\n  class=\"po-page-login-support\"\r\n  (click)=\"supportLink()\"\r\n  [hidden]=\"!literals?.str0010\"\r\n>\r\n  <span class=\"po-icon an an-question\"></span>\r\n  {{ literals?.str0010 }}\r\n  <!-- Suporte -->\r\n</button>\r\n\r\n <po-page-login\r\n  [p-hide-remember-user]=\"hideRememberUser\"\r\n  (p-login-submit)=\"onLoginSubmit($event)\"\r\n  (p-login-change)=\"onLoginChange($event)\"\r\n  [p-languages]=\"languages\"\r\n  (p-language-change)=\"onLanguageChange($event)\"\r\n  [p-login]=\"loginValue\"\r\n  [p-loading]=\"isLoading\"\r\n  [p-literals]=\"literals\"\r\n  [p-product-name]=\"productName\"\r\n  [p-recovery]=\"this.callRecoverPassword.bind(this)\"\r\n  [p-logo]=\"logo\"\r\n  [p-secondary-logo]=\"logo\" />\r\n  <!-- Linha Protheus -->\r\n" }]
        }], ctorParameters: () => [{ type: i2$1.Router }, { type: i2$1.ActivatedRoute }, { type: ProAuthService }, { type: ProMessageService }, { type: i3.PoI18nService }, { type: i0.ElementRef }, { type: ProLanguageService }, { type: ProBrandService }, { type: ProMfaService }, { type: ProSessionSettingsService }, { type: ProJsToAdvplService }], propDecorators: { nextRoute: [{
                type: Input,
                args: ['pro-next-route']
            }] } });

class ProLoginModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProLoginModule, declarations: [ProLoginComponent], imports: [CommonModule, PoComponentsModule, ReactiveFormsModule], exports: [ProLoginComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginModule, imports: [CommonModule, PoComponentsModule, ReactiveFormsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProLoginModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, PoComponentsModule, ReactiveFormsModule],
                    declarations: [ProLoginComponent],
                    exports: [ProLoginComponent]
                }]
        }] });

class ProPagesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPagesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProPagesModule, imports: [ProI18nConfigModule,
            ProHomeModule,
            PoModule,
            ProLoginModule,
            ProPageBackgroundModule,
            ProSessionSettingsModule], exports: [ProHomeModule,
            ProLoginModule,
            ProPageBackgroundModule,
            ProSessionSettingsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPagesModule, imports: [ProI18nConfigModule,
            ProHomeModule,
            PoModule,
            ProLoginModule,
            ProPageBackgroundModule,
            ProSessionSettingsModule, ProHomeModule,
            ProLoginModule,
            ProPageBackgroundModule,
            ProSessionSettingsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProPagesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ProI18nConfigModule,
                        ProHomeModule,
                        PoModule,
                        ProLoginModule,
                        ProPageBackgroundModule,
                        ProSessionSettingsModule
                    ],
                    exports: [
                        ProHomeModule,
                        ProLoginModule,
                        ProPageBackgroundModule,
                        ProSessionSettingsModule
                    ]
                }]
        }] });

class ProComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProComponentsModule, imports: [ProFieldsModule, ProPagesModule], exports: [ProFieldsModule, ProPagesModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProComponentsModule, imports: [ProFieldsModule, ProPagesModule, ProFieldsModule, ProPagesModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProFieldsModule, ProPagesModule],
                    exports: [ProFieldsModule, ProPagesModule]
                }]
        }] });

class ProtheusLibCoreModule {
    constructor(themeService) {
        this.themeService = themeService;
        const theme = localStorage.getItem('totvs-theme');
        if (theme && theme.includes('"_name":')) {
            localStorage.removeItem('totvs-theme');
        }
        this.themeService.setTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibCoreModule, deps: [{ token: ProThemeService }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibCoreModule, imports: [ProComponentsModule, ProServicesModule], exports: [ProComponentsModule, ProServicesModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibCoreModule, imports: [ProComponentsModule, ProServicesModule, ProComponentsModule, ProServicesModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProComponentsModule, ProServicesModule],
                    exports: [ProComponentsModule, ProServicesModule]
                }]
        }], ctorParameters: () => [{ type: ProThemeService }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ProAdapterBaseV2Service, ProAppConfigInteceptor, ProAppConfigModule, ProAppConfigService, ProAuthGuard, ProAuthInteceptor, ProAuthService, ProAuthorizationModule, ProBranchLookupComponent, ProBranchLookupModule, ProBranchLookupService, ProBranchService, ProBrandModule, ProBrandService, ProCompanyLookupComponent, ProCompanyLookupModule, ProCompanyLookupService, ProCompanyService, ProComponentsModule, ProDateModule, ProDateService, ProFieldsModule, ProGenericAdapterService, ProHomeComponent, ProHomeModule, ProI18nConfigModule, ProI18nService, ProJsToAdvplModule, ProJsToAdvplService, ProLanguageModule, ProLanguageService, ProLoginComponent, ProLoginDefaultsResolver, ProLoginModule, ProMessageService, ProMessagesModule, ProPageBackgroundComponent, ProPageBackgroundModule, ProPagesModule, ProRoleLookupComponent, ProRoleLookupModule, ProRoleLookupService, ProServicesModule, ProSessionInfoService, ProSessionSettingsComponent, ProSessionSettingsDefaultsResolver, ProSessionSettingsModule, ProSessionSettingsService, ProSessionSettingsUserInfoResolver, ProSystemDatabaseInterceptor, ProSystemIdiomInteceptor, ProSystemInfoModule, ProSystemModuleLookupComponent, ProSystemModuleLookupModule, ProSystemModuleLookupService, ProSystemModuleService, ProSystemModulesInteceptor, ProTenantModule, ProThreadInfoModule, ProThreadInfoService, ProTranslateStringModule, ProTranslateStringService, ProUserAccessService, ProUserInfoService, ProUserProfileModule, ProUserProfileService, ProtheusLibCoreModule, blockBackAction, convertToBoolean, generateRandomId, isExternalLink, isTypeof, valueIsNull };
//# sourceMappingURL=totvs-protheus-lib-core.mjs.map
