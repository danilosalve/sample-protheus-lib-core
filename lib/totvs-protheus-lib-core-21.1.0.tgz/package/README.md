# TOTVS - Protheus-Lib-Core

Repositório dos pacotes npm da família protheus-lib com os componentes Angular/Po-ui especializados para o desenvolvimento de interfaces para o sistema Protheus.

### Instalação

Instale utilizando o npm:
```
npm i @totvs/protheus-lib-core
```

_Atenção para a compatibilidade das versões do Angular, do Po-ui e do protheus-lib-core._

### Utilização

Para utilizar o protheus-lib-core, basta importar o módulo principal no projeto:

```
import { ProtheusLibCoreModule } from '@totvs/protheus-lib-core';
```

A importação do protheus-lib-core já vai resultar nos seguintes aspectos:
 - Integração do aplicativo com o Protheus via FWCallApp
 - Interceptor para que toda requisição seja autenticada de acordo com o usuário logado no Protheus
 - Interceptor para a URL da requisição seja auto-completeda de acordo com o REST MPP
 - Interceptor para o envio de grupo de empresas e filial no header da requisição

### Configuração

 - Veja demais informações sobre configuração no TDN: [FWCallApp  Abrido aplicativos no Protheus][fwcallapp]

[fwcallapp]: https://tdn.totvs.com.br/display/public/framework/FwCallApp+-+Abrindo+aplicativos+Web+no+Protheus

### Documentação

 - [https://tdn.totvs.com.br/display/framework/Protheus-lib-core](https://tdn.totvs.com.br/display/framework/Protheus-lib-core)