import * as i0 from '@angular/core';
import * as i1 from '@totvs/protheus-lib-core';
export * from '@totvs/protheus-lib-core';
import * as i2 from '@totvs/thf-components';
export * from '@totvs/thf-components';
import * as i3 from '@po-ui/ng-components';
export * from '@po-ui/ng-components';
import * as i4 from '@po-ui/ng-templates';

declare class ProtheusLibTHFModule {
    private readonly proThemeThf;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ProtheusLibTHFModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProtheusLibTHFModule, never, [typeof i1.ProtheusLibCoreModule, typeof i2.ThfModule, typeof i3.PoModule, typeof i4.PoTemplatesModule], [typeof i1.ProtheusLibCoreModule, typeof i2.ThfModule, typeof i3.PoModule, typeof i4.PoTemplatesModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProtheusLibTHFModule>;
}

export { ProtheusLibTHFModule };
