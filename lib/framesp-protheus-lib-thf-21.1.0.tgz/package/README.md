# ⚠️ Uso exclusivo dos produtos TOTVS ⚠️

## @framesp/protheus-lib-thf
Biblioteca para facilicar a integração de aplicativos web com o Protheus, disponibilizando o uso das libs @totvs/thf-components e @po-ui/ng-components.

## Como usar a biblioteca

### Guia passo a passo

Em uma aplicação **Angular** siga os seguintes passos:

1. Instale a biblioteca `@framesp/protheus-lib-thf`:

**Atenção:** As bibliotecas @totvs/protheus-lib-core, @totvs/thf-components e @po-ui/ng-components serão instaladas automaticamente.

```bash
npm install @framesp/protheus-lib-thf --registry=https://npm.totvs.io/
```

2. Importe o módulo `ProtheusLibTHFModule`:
#### Exemplo para projetos que não utilizam standalone components

```javascript
import { NgModule } from '@angular/core';
import { ProtheusLibTHFModule } from '@framesp/protheus-lib-thf';

@NgModule({
  ...
    imports: [
        ProtheusLibTHFModule
    ]
  ...
})
export class AppModule {}
```

#### Exemplo para aplicações standalone

```javascript
import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { ProtheusLibTHFModule } from '@framesp/protheus-lib-thf';

export const appConfig: ApplicationConfig = {
  providers: [
    ...
    importProvidersFrom([ProtheusLibTHFModule]),
    ...
  ],
};
```

3. Utilize os recursos das libs @totvs/protheus-lib-core, @totvs/thf-components e @po-ui/ng-components:
Os recursos acima são disponibilizados assim que o módulo ProtheusLibTHFModule é importado, portanto para utilizá-los, basta importá-los de @framesp/protheus-lib-thf.

#### Exemplo typescript
```javascript
import { ProAppConfigService, PoMenuItem } from '@framesp/protheus-lib-thf';
```

#### Exemplo html
```html
<po-page-default
  p-title="Exemplo thf-grid">
  <thf-grid></thf-grid>
</po-page-default>
```

## Exemplo de uso
Para consultar um exemplo de uso da biblioteca acesse [sample-protheus-lib-thf](https://code.engpro.totvs.com.br/debora.constantino/sample-protheus-lib-thf).