import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { PoThemeA11yEnum, PoThemeTypeEnum, PoModule } from '@po-ui/ng-components';
export * from '@po-ui/ng-components';
import { PoTemplatesModule } from '@po-ui/ng-templates';
import { ProSessionInfoService, ProtheusLibCoreModule } from '@totvs/protheus-lib-core';
export * from '@totvs/protheus-lib-core';
import { poThemeSunset, poThemeTotvs, ThfModule } from '@totvs/thf-components';
export * from '@totvs/thf-components';
import { ThfThemeService, poThemeSunsetDeprecated, poThemeTotvsDeprecated } from '@totvs/themes';

/**
 * @description Constante com os tipos de temas aceitos.
 */
const PRO_THEME_TYPE = {
    POUI: 'poui',
    THF: 'thf'
}; // O 'as const' torna as propriedades readonly e fixa seus tipos literais
/**
 * @description Verifica se a string contendo o tipo de tema é válido (poui ou thf)
 * @param { unknown } value valor do tipo de tema
 * @returns indica se o tipo de tema é valido
 */
function isValidProThemeType(value) {
    return typeof value === 'string' && Object.values(PRO_THEME_TYPE).includes(value);
}

/**
 * @service
 * Serviço resposável em definir o tema utilizado no aplicativo.
 *
 * @useBy Este serviço é utilizado apenas pela biblioteca e não é exportado para uso externo.
 */
class ProThemeThfService {
    constructor() {
        this.proSessionInfoService = inject(ProSessionInfoService);
        this.thfThemeService = inject(ThfThemeService);
    }
    /**
     * @description
     * Aplica um tema no aplicativo conforme o tipo informado. Caso o tema não seja informado, o tema será carregado do ERP, se o aplicativo estiver sendo executado dentro do Protheus.
     *
     * @param {PoTheme} theme (Opcional) Configuração de tema a ser aplicada ao componente. Se não informado busca o tema do Protheus.
     * @param {PoThemeTypeEnum} themeType (Opcional) Tipo de tema, podendo ser 'light' (claro) ou 'dark' (escuro). O tema claro é o padrão.
     * @example
     * export class SampleComponent {
     *    private readonly themeService = inject(ProThemeThfService);
     *
     *    setTheme(): void {
     *        this.proThemeThfService.setTheme();
     *    }
     * }
     */
    setTheme(theme, themeType) {
        const rawType = this.proSessionInfoService.getThemeType();
        const safeType = this.resolveThemeType(rawType);
        const a11y = this.getA11y(safeType);
        if (!theme) {
            const defaultTheme = this.getDefaultTheme(safeType);
            theme = defaultTheme.theme;
            themeType = themeType ?? defaultTheme.themeType;
        }
        // Desabilita definição de tema no @totvs/ProtheusLibCore
        ProSessionInfoService.canSetTheme = false;
        this.thfThemeService.setA11yDefaultSizeSmall(false);
        this.thfThemeService.setTheme(theme, themeType, a11y);
    }
    /**
     * @description
     * Obtem o nivel de acessibilidade utilizado no aplicativo
     *
     * @param {ProThemeTHFOption} type tipo de tema a ser aplicado
     * @returns {PoThemeA11yEnum} Nivel de acessibilidade
     * @private
     */
    getA11y(type) {
        const isProtheusTface = this.proSessionInfoService.getErpAppConfig()?.name === 'protheuslib-tface';
        const isPoui = type === PRO_THEME_TYPE.POUI;
        return isProtheusTface || isPoui ? PoThemeA11yEnum.AAA : PoThemeA11yEnum.AA;
    }
    /**
     * @description
     * Obtem o tema padrão a ser aplicado
     *
     * @param {ProThemeTHFOption} type tipo de tema a ser aplicado (poui ou thf)
     * @returns {ProThemeTHF} objeto contendo o tema e o tipo (claro ou escuro)
     * @private
     */
    getDefaultTheme(type) {
        const themeConfig = this.proSessionInfoService.getTheme();
        const config = themeConfig?.Configuration ?? 0;
        const isDeprecated = type === PRO_THEME_TYPE.POUI;
        const isSunset = config === 2;
        // Se tema Sunset altera o tipo do tema para tema claro (light)
        const themeType = isSunset || config === 0 ? PoThemeTypeEnum.light : PoThemeTypeEnum.dark;
        let theme;
        if (isDeprecated) {
            theme = isSunset ? poThemeSunsetDeprecated : poThemeTotvsDeprecated;
        }
        else {
            theme = isSunset ? poThemeSunset : poThemeTotvs;
        }
        theme.name = themeConfig?.Description || 'Tema Totvs Classic Light';
        return {
            theme,
            themeType
        };
    }
    /**
     * @description
     * Valida e sanitiza o tipo de tema retornado pelo ProSessionInfoService
     *
     * @param {string | null | undefined} rawType tipo de tema. Se inválido retorna THF.
     * @returns {ProThemeTHFOption} tipo de tema
     * @private
     */
    resolveThemeType(rawType) {
        if (isValidProThemeType(rawType)) {
            return rawType;
        }
        return PRO_THEME_TYPE.THF; // Fallback padrão
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeThfService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeThfService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProThemeThfService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ProtheusLibTHFModule {
    constructor() {
        this.proThemeThf = inject(ProThemeThfService);
        this.proThemeThf.setTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibTHFModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibTHFModule, imports: [ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule], exports: [ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibTHFModule, imports: [ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule, ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.9", ngImport: i0, type: ProtheusLibTHFModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule],
                    exports: [ProtheusLibCoreModule, ThfModule, PoModule, PoTemplatesModule]
                }]
        }], ctorParameters: () => [] });

/*
 * Public API Surface of protheus-lib-thf
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ProtheusLibTHFModule };
//# sourceMappingURL=framesp-protheus-lib-thf.mjs.map
